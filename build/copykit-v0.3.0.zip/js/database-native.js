/**
 * 原生IndexedDB数据库服务层
 * 专为Chrome扩展Service Worker优化
 */

class CopyKitDB {
  constructor() {
    this.name = 'CopyKitDB';
    this.version = 1;
    this.db = null;
  }

  async open() {
    return new Promise((resolve, reject) => {
      try {
        const request = indexedDB.open(this.name, this.version);
        
        request.onerror = () => {
          console.error('IndexedDB打开失败:', request.error);
          reject(request.error || new Error('数据库打开失败'));
        };
        
        request.onsuccess = () => {
          this.db = request.result;
          console.log('IndexedDB连接成功');
          resolve(this.db);
        };
        
        request.onupgradeneeded = (event) => {
          try {
            const db = event.target.result;
            console.log('正在升级数据库...');
            
            // 创建notes表
            if (!db.objectStoreNames.contains('notes')) {
              const notesStore = db.createObjectStore('notes', { keyPath: 'id', autoIncrement: false });
              notesStore.createIndex('timestamp', 'timestamp', { unique: false });
              notesStore.createIndex('folderId', 'folderId', { unique: false });
              notesStore.createIndex('deleted', 'deleted', { unique: false });
              console.log('notes表创建成功');
            }
            
            // 创建folders表
            if (!db.objectStoreNames.contains('folders')) {
              const foldersStore = db.createObjectStore('folders', { keyPath: 'id', autoIncrement: false });
              foldersStore.createIndex('name', 'name', { unique: false });
              foldersStore.createIndex('deleted', 'deleted', { unique: false });
              console.log('folders表创建成功');
            }
            
            // 创建settings表
            if (!db.objectStoreNames.contains('settings')) {
              db.createObjectStore('settings', { keyPath: 'key' });
              console.log('settings表创建成功');
            }
            
            console.log('数据库升级完成');
          } catch (upgradeError) {
            console.error('数据库升级失败:', upgradeError);
            reject(upgradeError);
          }
        };
        
      } catch (error) {
        console.error('数据库打开过程出错:', error);
        reject(error);
      }
    });
  }

  isOpen() {
    return this.db !== null;
  }

  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  addSyncMeta(obj, isUpdate = false) {
    if (!isUpdate) {
      obj.syncStatus = 'pending';
      obj.lastModified = Date.now();
      obj.deleted = false;
      if (!obj.id) {
        obj.id = this.generateUUID();
      }
    } else {
      obj.syncStatus = 'pending';
      obj.lastModified = Date.now();
    }
    return obj;
  }

  // 通用的数据库操作方法
  async add(storeName, data) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.add(data);
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async put(storeName, data) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.put(data);
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async get(storeName, key) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.get(key);
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getAll(storeName) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();
      
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  async delete(storeName, key) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.delete(key);
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async clear(storeName) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.clear();
      
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async count(storeName, indexName = null, key = null) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      
      let request;
      if (indexName && key !== null && key !== undefined) {
        try {
          const index = store.index(indexName);
          request = index.count(key);
        } catch (error) {
          // 如果索引不存在或key无效，回退到全表计数
          request = store.count();
        }
      } else {
        request = store.count();
      }
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getAllByIndex(storeName, indexName, key) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const index = store.index(indexName);
      const request = index.getAll(key);
      
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }
}

// 数据服务类
class DataService {
  constructor() {
    this.db = new CopyKitDB();
    this.migrationService = new MigrationService(this.db);
  }

  async initialize() {
    try {
      await this.db.open();
      console.log('数据库初始化成功');
      
      // 尝试数据迁移
      try {
        await this.migrationService.migrateFromChromeStorage();
        console.log('数据迁移完成');
      } catch (migrationError) {
        console.warn('数据迁移失败，但不影响正常使用:', migrationError);
      }
      
      return true;
    } catch (error) {
      console.error('数据库初始化失败:', error);
      
      // 提供更详细的错误信息
      if (error.name === 'QuotaExceededError') {
        throw new Error('存储空间不足，请清理浏览器数据后重试');
      } else if (error.name === 'InvalidStateError') {
        throw new Error('数据库状态异常，请刷新页面重试');
      } else if (error.name === 'VersionError') {
        throw new Error('数据库版本冲突，请清空浏览器数据后重试');
      } else {
        throw new Error(`数据库初始化失败: ${error.message || error.name || '未知错误'}`);
      }
    }
  }

  // 笔记相关操作
  async addNote(note) {
    try {
      const noteWithMeta = this.db.addSyncMeta({ ...note });
      const result = await this.db.add('notes', noteWithMeta);
      console.log('笔记添加成功:', noteWithMeta.id);
      return result;
    } catch (error) {
      console.error('添加笔记失败:', error);
      throw new Error(`添加笔记失败: ${error.message || '未知错误'}`);
    }
  }

  async getNotes() {
    const allNotes = await this.db.getAll('notes');
    const activeNotes = allNotes.filter(note => !note.deleted);
    return activeNotes.sort((a, b) => b.timestamp - a.timestamp);
  }

  async updateNote(id, updates) {
    const existing = await this.db.get('notes', id);
    if (!existing) throw new Error('Note not found');
    
    const updatedNote = { ...existing, ...updates };
    this.db.addSyncMeta(updatedNote, true);
    
    return await this.db.put('notes', updatedNote);
  }

  async deleteNote(id) {
    const existing = await this.db.get('notes', id);
    if (!existing) throw new Error('Note not found');
    
    existing.deleted = true;
    existing.lastModified = Date.now();
    
    return await this.db.put('notes', existing);
  }

  async searchNotes(query) {
    const allNotes = await this.getNotes();
    const lowerQuery = String(query || '').toLowerCase();

    return allNotes.filter((note) => {
      const content = String(note.content || '').toLowerCase();
      const sourceTitle = String(note.sourceTitle || '').toLowerCase();
      const customTitle = String(note.customTitle || '').toLowerCase();
      const hasTagMatch = Array.isArray(note.tags)
        && note.tags.some((tag) => String(tag || '').toLowerCase().includes(lowerQuery));

      return content.includes(lowerQuery)
        || sourceTitle.includes(lowerQuery)
        || customTitle.includes(lowerQuery)
        || hasTagMatch;
    });
  }

  // 文件夹相关操作
  async addFolder(folder) {
    const folderWithMeta = this.db.addSyncMeta({ ...folder });
    return await this.db.add('folders', folderWithMeta);
  }

  async getFolders() {
    const allFolders = await this.db.getAll('folders');
    return allFolders.filter(folder => !folder.deleted);
  }

  async updateFolder(id, updates) {
    const existing = await this.db.get('folders', id);
    if (!existing) throw new Error('Folder not found');

    const updatedFolder = { ...existing, ...updates };
    this.db.addSyncMeta(updatedFolder, true);

    return await this.db.put('folders', updatedFolder);
  }

  async deleteFolder(id, options = {}) {
    const existing = await this.db.get('folders', id);
    if (!existing) throw new Error('Folder not found');

    let movedNotes = 0;
    const shouldMoveNotesToDefault = options.moveNotesToDefault !== false;
    if (shouldMoveNotesToDefault) {
      const notesInFolder = await this.db.getAllByIndex('notes', 'folderId', id);
      const activeNotes = notesInFolder.filter((note) => !note.deleted);

      for (const note of activeNotes) {
        const nextNote = { ...note, folderId: null };
        this.db.addSyncMeta(nextNote, true);
        await this.db.put('notes', nextNote);
      }

      movedNotes = activeNotes.length;
    }

    existing.deleted = true;
    existing.lastModified = Date.now();

    await this.db.put('folders', existing);
    return { movedNotes };
  }

  // 统计信息
  async getStats() {
    try {
      // 通过获取所有数据然后过滤来统计，避免索引问题
      const [allNotes, allFolders] = await Promise.all([
        this.db.getAll('notes'),
        this.db.getAll('folders')
      ]);

      const activeNotes = allNotes.filter(note => !note.deleted).length;
      const activeFolders = allFolders.filter(folder => !folder.deleted).length;

      return {
        notes: activeNotes,
        folders: activeFolders,
        tags: 0,
        lastUpdated: Date.now()
      };
    } catch (error) {
      console.error('获取统计信息失败:', error);
      // 返回默认统计
      return {
        notes: 0,
        folders: 0,
        tags: 0,
        lastUpdated: Date.now()
      };
    }
  }

  // 导出数据
  async exportData() {
    const [notes, folders] = await Promise.all([
      this.getNotes(),
      this.getFolders()
    ]);

    return {
      version: '1.0',
      exportTime: Date.now(),
      data: {
        notes,
        folders
      }
    };
  }

  // 导入数据
  async importData(importData) {
    const { data } = importData;
    let imported = { notes: 0, folders: 0 };

    if (data.folders && data.folders.length > 0) {
      for (const folder of data.folders) {
        try {
          await this.addFolder(folder);
          imported.folders++;
        } catch (error) {
          console.warn('导入文件夹失败:', error);
        }
      }
    }

    if (data.notes && data.notes.length > 0) {
      for (const note of data.notes) {
        try {
          await this.addNote(note);
          imported.notes++;
        } catch (error) {
          console.warn('导入笔记失败:', error);
        }
      }
    }

    return imported;
  }
}

// 数据迁移服务
class MigrationService {
  constructor(db) {
    this.db = db;
  }

  async migrateFromChromeStorage() {
    try {
      console.log('检查是否需要数据迁移...');
      
      // 检查是否已经有数据
      const existingNotes = await this.db.count('notes');
      if (existingNotes > 0) {
        console.log('数据库已有数据，跳过迁移');
        return { success: true, migratedNotes: 0, migratedFolders: 0 };
      }

      // 获取Chrome Storage数据
      const chromeData = await new Promise((resolve) => {
        if (typeof chrome !== 'undefined' && chrome.storage) {
          chrome.storage.local.get(['notes', 'folders'], resolve);
        } else {
          resolve({});
        }
      });

      const { notes = [], folders = [] } = chromeData;

      if (notes.length === 0 && folders.length === 0) {
        console.log('没有需要迁移的数据');
        return { success: true, migratedNotes: 0, migratedFolders: 0 };
      }

      let migratedNotes = 0;
      let migratedFolders = 0;

      // 迁移文件夹
      if (folders.length > 0) {
        for (const folder of folders) {
          try {
            const folderWithMeta = this.db.addSyncMeta({ ...folder });
            await this.db.add('folders', folderWithMeta);
            migratedFolders++;
          } catch (error) {
            console.warn('迁移文件夹失败:', error);
          }
        }
      }

      // 迁移笔记
      if (notes.length > 0) {
        for (const note of notes) {
          try {
            const noteWithMeta = this.db.addSyncMeta({ ...note });
            await this.db.add('notes', noteWithMeta);
            migratedNotes++;
          } catch (error) {
            console.warn('迁移笔记失败:', error);
          }
        }
      }

      console.log(`数据迁移完成: ${migratedNotes} 条笔记, ${migratedFolders} 个文件夹`);
      
      return {
        success: true,
        migratedNotes,
        migratedFolders
      };

    } catch (error) {
      console.error('数据迁移失败:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
}

// 全局数据服务实例
let globalDataService = null;

function getDataService() {
  if (!globalDataService) {
    globalDataService = new DataService();
  }
  return globalDataService;
}

// 导出到全局作用域 (用于Service Worker)
if (typeof self !== 'undefined') {
  self.getDataService = getDataService;
  self.DataService = DataService;
  self.CopyKitDB = CopyKitDB;
  self.MigrationService = MigrationService;
}
