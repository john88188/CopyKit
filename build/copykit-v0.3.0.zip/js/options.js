// 设置页面的JavaScript逻辑

document.addEventListener('DOMContentLoaded', async () => {
  try {
    initializeTranslateLanguageSelectors();

    // 加载当前设置
    await loadSettings();
    
    // 设置事件监听器
    document.getElementById('save-btn').addEventListener('click', saveSettings);
    document.getElementById('cancel-btn').addEventListener('click', async () => {
      try {
        const tab = await new Promise((resolve) => chrome.tabs.getCurrent(resolve));
        if (tab && typeof tab.id === 'number') {
          chrome.tabs.remove(tab.id);
          return;
        }
      } catch (error) {
        // ignore
      }

      window.close();
    });
    document.getElementById('export-btn').addEventListener('click', exportData);
    document.getElementById('import-btn').addEventListener('click', () => {
      document.getElementById('import-file').click();
    });
    document.getElementById('import-file').addEventListener('change', importData);
    document.getElementById('clear-btn').addEventListener('click', clearData);
    document.getElementById('llm-gateway-enabled').addEventListener('change', updateLlmProviderFieldStates);
    
    // 添加高级功能的事件监听器
    document.getElementById('clipboard-monitor').addEventListener('change', async (e) => {
      // 如果启用剪贴板监听，显示权限解释
      if (e.target.checked) {
        if (!confirm('剪贴板监听功能需要读取您的剪贴板内容以提供保存功能。继续启用此功能？')) {
          e.target.checked = false;
          return;
        }

        const granted = await ensureClipboardReadPermission();
        if (!granted) {
          e.target.checked = false;
          showError('未授予剪贴板读取权限，无法启用剪贴板监听');
        }
      }
    });

    // 加载统计信息
    await loadStatistics();
    
  } catch (error) {
    console.error('设置页面初始化失败:', error);
    showError('页面加载失败: ' + error.message);
  }
});

function normalizeGatewayBaseUrlForOptions(rawValue) {
  const raw = String(rawValue || '').trim();
  if (!raw) {
    return '';
  }

  let url = null;
  try {
    url = new URL(raw);
  } catch (error) {
    throw new Error('网关地址格式不正确');
  }

  const isLocalhost = /^(localhost|127\.0\.0\.1|::1)$/i.test(url.hostname || '');
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && isLocalhost)) {
    throw new Error('网关地址必须使用 https://（localhost 调试可使用 http://）');
  }

  url.username = '';
  url.password = '';
  url.search = '';
  url.hash = '';
  url.pathname = (url.pathname || '/').replace(/\/+$/, '');
  return url.toString().replace(/\/+$/, '');
}

function updateLlmProviderFieldStates() {
  const gatewayEnabled = document.getElementById('llm-gateway-enabled').checked;
  const directFieldIds = ['llm-base-url', 'llm-api-key'];
  directFieldIds.forEach((id) => {
    const element = document.getElementById(id);
    if (!element) {
      return;
    }
    element.disabled = gatewayEnabled;
    element.style.opacity = gatewayEnabled ? '0.65' : '';
  });

  const gatewayFieldIds = ['llm-gateway-base-url', 'llm-gateway-access-token'];
  gatewayFieldIds.forEach((id) => {
    const element = document.getElementById(id);
    if (!element) {
      return;
    }
    element.disabled = !gatewayEnabled;
    element.style.opacity = gatewayEnabled ? '' : '0.65';
  });
}

function parseModelListInput(rawValue) {
  return String(rawValue || '')
    .split(',')
    .map((item) => item.trim())
    .filter((item) => item);
}

async function ensureClipboardReadPermission() {
  return new Promise((resolve, reject) => {
    if (!chrome.permissions || typeof chrome.permissions.contains !== 'function') {
      resolve(true);
      return;
    }

    chrome.permissions.contains({ permissions: ['clipboardRead'] }, (hasPermission) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      if (hasPermission === true) {
        resolve(true);
        return;
      }

      chrome.permissions.request({ permissions: ['clipboardRead'] }, (granted) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(granted === true);
      });
    });
  });
}

const FALLBACK_TRANSLATE_LANGUAGE_OPTIONS = [
  { value: 'auto', label: '自动检测 / Auto Detect' },
  { value: 'zh-CN', label: 'Chinese (Simplified) / 中文(简体)' },
  { value: 'zh-TW', label: 'Chinese (Traditional) / 中文(繁體)' },
  { value: 'en', label: 'English' },
  { value: 'ja', label: 'Japanese / 日本語' },
  { value: 'ko', label: 'Korean / 한국어' },
  { value: 'fr', label: 'French / Français' },
  { value: 'de', label: 'German / Deutsch' },
  { value: 'es', label: 'Spanish / Español' },
  { value: 'pt-BR', label: 'Portuguese (Brazil) / Português (Brasil)' },
  { value: 'ru', label: 'Russian / Русский' },
  { value: 'ar', label: 'Arabic' },
  { value: 'hi', label: 'Hindi / हिन्दी' }
];
const TRANSLATE_LANGUAGE_OPTIONS = Array.isArray(globalThis.COPYKIT_TRANSLATE_LANGUAGE_OPTIONS)
  && globalThis.COPYKIT_TRANSLATE_LANGUAGE_OPTIONS.length > 0
  ? globalThis.COPYKIT_TRANSLATE_LANGUAGE_OPTIONS
  : FALLBACK_TRANSLATE_LANGUAGE_OPTIONS;
const TRANSLATE_LANGUAGE_ALIASES = globalThis.COPYKIT_TRANSLATE_LANGUAGE_ALIASES
  && typeof globalThis.COPYKIT_TRANSLATE_LANGUAGE_ALIASES === 'object'
  ? globalThis.COPYKIT_TRANSLATE_LANGUAGE_ALIASES
  : {};
const TRANSLATE_LANGUAGE_VALUE_LOOKUP = new Map(
  TRANSLATE_LANGUAGE_OPTIONS
    .filter((item) => item && typeof item.value === 'string' && item.value.trim())
    .map((item) => [item.value.toLowerCase(), item.value])
);

function normalizeTranslateLanguageCandidate(value) {
  const raw = typeof value === 'string' ? value.trim() : '';
  if (!raw) {
    return '';
  }

  const lowered = raw.toLowerCase();
  if (Object.prototype.hasOwnProperty.call(TRANSLATE_LANGUAGE_ALIASES, lowered)) {
    return TRANSLATE_LANGUAGE_ALIASES[lowered];
  }

  return TRANSLATE_LANGUAGE_VALUE_LOOKUP.get(lowered) || raw;
}

function getTranslateLanguageFallback(allowAuto, fallbackValue) {
  const fallbackCandidate = normalizeTranslateLanguageCandidate(fallbackValue);
  const normalizedFallback = TRANSLATE_LANGUAGE_VALUE_LOOKUP.get(String(fallbackCandidate || '').toLowerCase()) || '';
  if (normalizedFallback && (allowAuto || normalizedFallback !== 'auto')) {
    return normalizedFallback;
  }

  const defaultCandidate = allowAuto ? 'auto' : 'zh-CN';
  const normalizedDefault = TRANSLATE_LANGUAGE_VALUE_LOOKUP.get(defaultCandidate.toLowerCase()) || '';
  if (normalizedDefault && (allowAuto || normalizedDefault !== 'auto')) {
    return normalizedDefault;
  }

  const firstAllowed = TRANSLATE_LANGUAGE_OPTIONS.find((item) => {
    if (!item || typeof item.value !== 'string') {
      return false;
    }
    if (!allowAuto && item.value === 'auto') {
      return false;
    }
    return true;
  });
  return firstAllowed?.value || '';
}

function normalizeTranslateLanguageValue(value, fallbackValue, allowAuto) {
  const fallback = getTranslateLanguageFallback(allowAuto, fallbackValue);
  const candidate = normalizeTranslateLanguageCandidate(value);
  const normalized = TRANSLATE_LANGUAGE_VALUE_LOOKUP.get(String(candidate || '').toLowerCase()) || '';
  if (!normalized) {
    return fallback;
  }
  if (!allowAuto && normalized === 'auto') {
    return fallback;
  }
  return normalized;
}

function rebuildTranslateLanguageSelectOptions(selectId, includeAuto) {
  const select = document.getElementById(selectId);
  if (!(select instanceof HTMLSelectElement)) {
    return;
  }

  const currentValue = select.value;
  const fallbackValue = includeAuto ? 'auto' : 'zh-CN';
  select.textContent = '';
  TRANSLATE_LANGUAGE_OPTIONS.forEach((item) => {
    if (!item || typeof item.value !== 'string' || typeof item.label !== 'string') {
      return;
    }
    if (!includeAuto && item.value === 'auto') {
      return;
    }
    const option = document.createElement('option');
    option.value = item.value;
    option.textContent = item.label;
    select.appendChild(option);
  });

  select.value = normalizeTranslateLanguageValue(currentValue, fallbackValue, includeAuto);
}

function initializeTranslateLanguageSelectors() {
  rebuildTranslateLanguageSelectOptions('translate-source-lang', true);
  rebuildTranslateLanguageSelectOptions('translate-target-lang', false);
}

const VALID_TEXT_VERBOSITY_OPTIONS = new Set(['low', 'medium', 'high']);
const VALID_REASONING_EFFORT_OPTIONS = new Set(['none', 'minimal', 'low', 'medium', 'high', 'xhigh']);

function parseModelCapabilityOverridesInput(rawValue) {
  const raw = String(rawValue || '').trim();
  if (!raw) {
    return '';
  }

  let parsed = null;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    throw new Error(`模型参数能力覆盖 JSON 格式错误: ${error.message || String(error)}`);
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('模型参数能力覆盖必须是 JSON 对象');
  }

  Object.entries(parsed).forEach(([rawKey, rawValue]) => {
    const key = String(rawKey || '').trim();
    if (!key) {
      throw new Error('模型参数能力覆盖中存在空 key');
    }

    const matchKey = key.endsWith('*') ? key.slice(0, -1).trim() : key;
    if (!matchKey) {
      throw new Error(`模型参数能力覆盖 key 无效: ${rawKey}`);
    }

    if (!rawValue || typeof rawValue !== 'object' || Array.isArray(rawValue)) {
      throw new Error(`模型参数能力覆盖项必须是对象: ${rawKey}`);
    }

    const hasTextVerbosity = Object.prototype.hasOwnProperty.call(rawValue, 'textVerbosity');
    const hasReasoningEffort = Object.prototype.hasOwnProperty.call(rawValue, 'reasoningEffort');
    if (!hasTextVerbosity && !hasReasoningEffort) {
      throw new Error(`模型参数能力覆盖项至少包含一个字段(textVerbosity/reasoningEffort): ${rawKey}`);
    }

    if (hasTextVerbosity && rawValue.textVerbosity !== null) {
      const textVerbosity = String(rawValue.textVerbosity).trim().toLowerCase();
      if (!VALID_TEXT_VERBOSITY_OPTIONS.has(textVerbosity)) {
        throw new Error(`textVerbosity 无效(${rawKey}): ${rawValue.textVerbosity}`);
      }
    }

    if (hasReasoningEffort && rawValue.reasoningEffort !== null) {
      const reasoningEffort = String(rawValue.reasoningEffort).trim().toLowerCase();
      if (!VALID_REASONING_EFFORT_OPTIONS.has(reasoningEffort)) {
        throw new Error(`reasoningEffort 无效(${rawKey}): ${rawValue.reasoningEffort}`);
      }
    }
  });

  return JSON.stringify(parsed, null, 2);
}

// 发送消息到背景脚本
async function sendMessageToBackground(action, data = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action, ...data }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (response && response.success) {
        if (Object.prototype.hasOwnProperty.call(response, 'data')) {
          resolve(response.data);
        } else if (Object.prototype.hasOwnProperty.call(response, 'result')) {
          resolve(response.result);
        } else if (Object.prototype.hasOwnProperty.call(response, 'folderId')) {
          resolve(response.folderId);
        } else if (Object.prototype.hasOwnProperty.call(response, 'noteId')) {
          resolve(response.noteId);
        } else if (Object.prototype.hasOwnProperty.call(response, 'message')) {
          resolve(response.message);
        } else {
          resolve(null);
        }
      } else {
        reject(new Error(response?.error || '操作失败'));
      }
    });
  });
}

// 加载设置
async function loadSettings() {
  try {
    // 从Chrome Storage获取设置（保持设置在Chrome Storage中）
    const chromeSettings = await new Promise((resolve) => {
      chrome.storage.local.get({
        defaultSavePath: 'CopyKit笔记',
        defaultFormat: 'markdown',
        autoSync: false,
        theme: 'system',
        imageFolder: 'images',
        clipboardMonitor: false,
        pageAnalyzer: false,
        aiSummary: false,
        llmBaseUrl: 'https://api.openai.com',
        llmApiKey: '',
        llmModel: 'gpt-4o-mini',
        llmTemperature: '',
        llmGatewayEnabled: false,
        llmGatewayBaseUrl: '',
        llmGatewayAccessToken: '',
        llmModelCapabilityOverrides: '',
        translateSourceLang: 'auto',
        translateTargetLang: 'zh-CN',
        translateStyle: 'literal',
        translatePopupPreferred: true
      }, resolve);
    });

    // 更新表单
    document.getElementById('default-format').value = chromeSettings.defaultFormat;
    document.getElementById('auto-sync').checked = chromeSettings.autoSync;
    document.getElementById('theme').value = chromeSettings.theme;
    document.getElementById('image-folder').value = chromeSettings.imageFolder;
    document.getElementById('clipboard-monitor').checked = chromeSettings.clipboardMonitor;
    document.getElementById('page-analyzer').checked = chromeSettings.pageAnalyzer;
    document.getElementById('ai-summary').checked = chromeSettings.aiSummary;
    document.getElementById('llm-base-url').value = chromeSettings.llmBaseUrl || '';
    document.getElementById('llm-api-key').value = chromeSettings.llmApiKey || '';
    document.getElementById('llm-model').value = chromeSettings.llmModel || '';
    document.getElementById('llm-temperature').value = chromeSettings.llmTemperature === undefined ? '' : String(chromeSettings.llmTemperature);
    document.getElementById('llm-gateway-enabled').checked = chromeSettings.llmGatewayEnabled === true;
    document.getElementById('llm-gateway-base-url').value = chromeSettings.llmGatewayBaseUrl || '';
    document.getElementById('llm-gateway-access-token').value = chromeSettings.llmGatewayAccessToken || '';
    document.getElementById('llm-model-capability-overrides').value = chromeSettings.llmModelCapabilityOverrides || '';
    document.getElementById('translate-source-lang').value = normalizeTranslateLanguageValue(
      chromeSettings.translateSourceLang,
      'auto',
      true
    );
    document.getElementById('translate-target-lang').value = normalizeTranslateLanguageValue(
      chromeSettings.translateTargetLang,
      'zh-CN',
      false
    );
    document.getElementById('translate-popup-preferred').checked = chromeSettings.translatePopupPreferred !== false;
    updateLlmProviderFieldStates();
    applyTheme(chromeSettings.theme);
    
    console.log('设置加载完成');
    
  } catch (error) {
    console.error('加载设置失败:', error);
    showError('加载设置失败: ' + error.message);
  }
}

// 保存设置
async function saveSettings() {
  try {
    showLoading('正在保存设置...');

    const llmTemperatureRaw = document.getElementById('llm-temperature').value.trim();
    if (llmTemperatureRaw && !Number.isFinite(Number(llmTemperatureRaw))) {
      throw new Error('TEMPERATURE 必须是数字，或留空');
    }

    const llmModelRaw = document.getElementById('llm-model').value.trim();
    const modelList = parseModelListInput(llmModelRaw);
    if (llmModelRaw && modelList.length === 0) {
      throw new Error('MODEL 配置无效，请使用英文逗号分隔模型名');
    }
    const llmModelCapabilityOverrides = parseModelCapabilityOverridesInput(
      document.getElementById('llm-model-capability-overrides').value
    );
    const gatewayEnabled = document.getElementById('llm-gateway-enabled').checked;
    const gatewayBaseUrlRaw = document.getElementById('llm-gateway-base-url').value;
    const llmGatewayBaseUrl = gatewayEnabled
      ? normalizeGatewayBaseUrlForOptions(gatewayBaseUrlRaw)
      : String(gatewayBaseUrlRaw || '').trim();
    const llmGatewayAccessToken = document.getElementById('llm-gateway-access-token').value.trim();
    if (gatewayEnabled) {
      if (!llmGatewayBaseUrl) {
        throw new Error('启用网关模式时必须填写网关地址');
      }
      if (!llmGatewayAccessToken) {
        throw new Error('启用网关模式时必须填写网关访问令牌');
      }
    }

    const clipboardMonitorEnabled = document.getElementById('clipboard-monitor').checked;
    if (clipboardMonitorEnabled) {
      const granted = await ensureClipboardReadPermission();
      if (!granted) {
        throw new Error('启用剪贴板监听前需要授予 clipboardRead 权限');
      }
    }

    // 获取表单数据
    const settings = {
      defaultFormat: document.getElementById('default-format').value,
      autoSync: document.getElementById('auto-sync').checked,
      theme: document.getElementById('theme').value,
      imageFolder: document.getElementById('image-folder').value,
      clipboardMonitor: clipboardMonitorEnabled,
      pageAnalyzer: document.getElementById('page-analyzer').checked,
      aiSummary: document.getElementById('ai-summary').checked,
      llmBaseUrl: document.getElementById('llm-base-url').value.trim() || 'https://api.openai.com',
      llmApiKey: document.getElementById('llm-api-key').value.trim(),
      llmModel: modelList.length > 0 ? modelList.join(', ') : 'gpt-4o-mini',
      llmTemperature: llmTemperatureRaw,
      llmGatewayEnabled: gatewayEnabled,
      llmGatewayBaseUrl,
      llmGatewayAccessToken,
      llmModelCapabilityOverrides,
      translateSourceLang: normalizeTranslateLanguageValue(
        document.getElementById('translate-source-lang').value,
        'auto',
        true
      ),
      translateTargetLang: normalizeTranslateLanguageValue(
        document.getElementById('translate-target-lang').value,
        'zh-CN',
        false
      ),
      translatePopupPreferred: document.getElementById('translate-popup-preferred').checked
    };

    // 保存到Chrome Storage
    await new Promise((resolve) => {
      chrome.storage.local.set(settings, resolve);
    });

    // 通知背景脚本更新运行时开关
    await sendMessageToBackground('updateClipboardMonitor', {
      enabled: settings.clipboardMonitor
    });

    hideLoading();
    showSuccess('设置已保存');
    
    // 更新按钮状态
    const saveBtn = document.getElementById('save-btn');
    const originalText = saveBtn.textContent;
    saveBtn.textContent = '已保存';
    saveBtn.style.background = '#4caf50';
    
    setTimeout(() => {
      saveBtn.textContent = originalText;
      saveBtn.style.background = '';
    }, 2000);
    
  } catch (error) {
    hideLoading();
    console.error('保存设置失败:', error);
    showError('保存设置失败: ' + error.message);
  }
}

// 加载统计信息
async function loadStatistics() {
  try {
    const stats = await sendMessageToBackground('getStats');
    
    document.getElementById('notes-count').textContent = stats.notes || 0;
    document.getElementById('folders-count').textContent = stats.folders || 0;
    document.getElementById('tags-count').textContent = stats.tags || 0;
    
    const lastUpdated = stats.lastUpdated ? new Date(stats.lastUpdated).toLocaleString('zh-CN') : '未知';
    document.getElementById('last-updated').textContent = lastUpdated;
    
  } catch (error) {
    console.error('加载统计信息失败:', error);
    // 统计信息加载失败不影响主要功能，只显示控制台错误
  }
}

// 导出数据
async function exportData() {
  try {
    showLoading('正在导出数据...');
    
    // 从背景脚本获取完整的数据
    const exportData = await sendMessageToBackground('exportData');
    
    hideLoading();
    
    // 创建下载链接
    const dataStr = JSON.stringify(exportData, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const now = new Date();
    const dateStr = now.getFullYear() + 
      String(now.getMonth() + 1).padStart(2, '0') + 
      String(now.getDate()).padStart(2, '0') + '_' +
      String(now.getHours()).padStart(2, '0') +
      String(now.getMinutes()).padStart(2, '0');
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `copykit-backup-${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showSuccess('数据导出成功');
    
  } catch (error) {
    hideLoading();
    console.error('导出数据失败:', error);
    showError('导出数据失败: ' + error.message);
  }
}

// 导入数据
async function importData(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  if (!file.name.endsWith('.json')) {
    showError('请选择JSON格式的备份文件');
    return;
  }
  
  try {
    showLoading('正在导入数据...');
    
    const fileText = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (e) => reject(new Error('文件读取失败'));
      reader.readAsText(file);
    });
    
    const importData = JSON.parse(fileText);
    
    // 验证数据格式
    if (!importData.version || !importData.data) {
      throw new Error('备份文件格式不正确');
    }
    
    if (!confirm('导入数据将覆盖现有的所有笔记和文件夹。确定要继续吗？')) {
      hideLoading();
      return;
    }
    
    // 通过背景脚本导入数据
    await sendMessageToBackground('importData', { importData });
    
    hideLoading();
    showSuccess('数据导入成功');
    
    // 重新加载统计信息
    await loadStatistics();
    
  } catch (error) {
    hideLoading();
    console.error('导入数据失败:', error);
    showError('导入数据失败: ' + error.message);
  } finally {
    // 清空文件选择
    event.target.value = '';
  }
}

// 清除所有数据
async function clearData() {
  const confirmText = '确定要删除所有数据吗？这个操作无法撤销。\n\n请输入 "DELETE" 来确认：';
  const userInput = prompt(confirmText);
  
  if (userInput !== 'DELETE') {
    if (userInput !== null) {
      alert('输入不正确，操作已取消');
    }
    return;
  }
  
  try {
    showLoading('正在清除数据...');
    
    // 清除IndexedDB数据
    await sendMessageToBackground('clearAllData');
    
    // 清除Chrome Storage中的设置（除了基本设置）
    const basicSettings = {
      defaultSavePath: 'CopyKit笔记',
      defaultFormat: 'markdown',
      autoSync: false,
      theme: 'system',
      imageFolder: 'images',
      lastUsedFolderId: 'default',
      clipboardMonitor: false,
      pageAnalyzer: false,
      aiSummary: false,
      llmBaseUrl: 'https://api.openai.com',
      llmApiKey: '',
      llmModel: 'gpt-4o-mini',
      llmTemperature: '',
      llmGatewayEnabled: false,
      llmGatewayBaseUrl: '',
      llmGatewayAccessToken: '',
      llmModelCapabilityOverrides: '',
      translateSourceLang: 'auto',
      translateTargetLang: 'zh-CN',
      translateStyle: 'literal',
      translatePopupPreferred: true
    };
    
    await new Promise((resolve) => {
      chrome.storage.local.clear(() => {
        chrome.storage.local.set(basicSettings, resolve);
      });
    });
    
    hideLoading();
    showSuccess('所有数据已清除');
    
    // 重新加载页面
    setTimeout(() => {
      window.location.reload();
    }, 2000);
    
  } catch (error) {
    hideLoading();
    console.error('清除数据失败:', error);
    showError('清除数据失败: ' + error.message);
  }
}

// 显示加载状态
function showLoading(message = '加载中...') {
  let loadingDiv = document.getElementById('loading-overlay');
  
  if (!loadingDiv) {
    loadingDiv = document.createElement('div');
    loadingDiv.id = 'loading-overlay';
    loadingDiv.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, 0.9);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      font-size: 16px;
      color: #666;
    `;
    document.body.appendChild(loadingDiv);
  }
  
  loadingDiv.textContent = message;
  loadingDiv.style.display = 'flex';
}

// 隐藏加载状态
function hideLoading() {
  const loadingDiv = document.getElementById('loading-overlay');
  if (loadingDiv) {
    loadingDiv.style.display = 'none';
  }
}

// 显示成功消息
function showSuccess(message) {
  showNotification(message, '#4caf50');
}

// 显示错误消息
function showError(message) {
  showNotification(message, '#f44336');
}

// 显示通知
function showNotification(message, color) {
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${color};
    color: white;
    padding: 12px 16px;
    border-radius: 6px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    z-index: 10000;
    font-size: 14px;
    font-weight: 500;
    opacity: 0;
    transform: translateX(100%);
    transition: all 0.3s ease;
    max-width: 300px;
    word-wrap: break-word;
  `;
  notification.textContent = message;
  
  document.body.appendChild(notification);
  
  // 动画显示
  requestAnimationFrame(() => {
    notification.style.opacity = '1';
    notification.style.transform = 'translateX(0)';
  });
  
  // 4秒后自动移除
  setTimeout(() => {
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 300);
  }, 4000);
}

// 添加一些实用的工具函数
function formatFileSize(bytes) {
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  if (bytes === 0) return '0 Bytes';
  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
  return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
}

function applyTheme(theme) {
  const body = document.body;
  body.classList.remove('light-theme', 'dark-theme');

  if (theme === 'light') {
    body.classList.add('light-theme');
    return;
  }

  if (theme === 'dark') {
    body.classList.add('dark-theme');
    return;
  }

  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    body.classList.add('dark-theme');
  } else {
    body.classList.add('light-theme');
  }
}

// 主题切换处理
const themeSelect = document.getElementById('theme');
if (themeSelect) {
  themeSelect.addEventListener('change', function(e) {
    applyTheme(e.target.value);
  });
}

// 监听系统主题变化
if (window.matchMedia) {
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  const handleSystemThemeChange = function() {
    const currentTheme = document.getElementById('theme')?.value;
    if (currentTheme === 'system') {
      applyTheme('system');
    }
  };

  if (typeof mediaQuery.addEventListener === 'function') {
    mediaQuery.addEventListener('change', handleSystemThemeChange);
  } else if (typeof mediaQuery.addListener === 'function') {
    mediaQuery.addListener(handleSystemThemeChange);
  }
}
