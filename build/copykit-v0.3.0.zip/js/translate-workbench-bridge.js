(function () {
  const bootNode = document.getElementById('copykit-workbench-boot');

  function removeBootNode() {
    if (bootNode && bootNode.parentNode) {
      bootNode.parentNode.removeChild(bootNode);
    }
  }

  function updateBootText(text) {
    if (bootNode) {
      bootNode.textContent = text;
    }
  }

  function asObject(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  }

  function parsePayloadId() {
    const hashValue = typeof location.hash === 'string' ? location.hash.slice(1).trim() : '';
    if (hashValue) {
      try {
        return decodeURIComponent(hashValue);
      } catch {
        return hashValue;
      }
    }

    const params = new URLSearchParams(location.search);
    const payloadId = params.get('payloadId');
    return payloadId ? payloadId.trim() : '';
  }

  function shouldOfferOptions(errorMessage) {
    const msg = (errorMessage || '').toString();
    return /API_KEY|BASE_URL|MODEL|鉴权|网关|令牌|token|401|403/i.test(msg);
  }

  function sendMessageToBackground(action, data = {}) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action, ...data }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        if (!response || response.success !== true) {
          reject(new Error(response && response.error ? response.error : '操作失败'));
          return;
        }

        if (Object.prototype.hasOwnProperty.call(response, 'data')) {
          resolve(response.data);
          return;
        }

        if (Object.prototype.hasOwnProperty.call(response, 'result')) {
          resolve(response.result);
          return;
        }

        resolve(null);
      });
    });
  }

  async function getInitialPayload() {
    const payloadId = parsePayloadId();
    if (!payloadId) {
      return {};
    }

    const payload = await sendMessageToBackground('consumeTranslateWorkbenchPayload', { id: payloadId });
    return asObject(payload);
  }

  async function getDefaults(overridePayload) {
    const defaults = await sendMessageToBackground('getTranslateWorkbenchDefaults', {
      sourceLang: overridePayload.sourceLang,
      targetLang: overridePayload.targetLang,
      model: overridePayload.model,
      translationStyle: overridePayload.translationStyle
    });
    return asObject(defaults);
  }

  function normalizeTranslationStyle(value, fallback = 'literal') {
    const raw = typeof value === 'string' ? value.trim().toLowerCase() : '';
    if (!raw) {
      return fallback;
    }
    if (raw === 'paraphrase' || raw === 'free' || raw === 'idiomatic' || raw === '意译') {
      return 'paraphrase';
    }
    return 'literal';
  }

  function buildDialogPayload(initialPayload, defaults) {
    const payload = asObject(initialPayload);
    const normalizedModelOptions = [];

    const payloadOptions = Array.isArray(payload.modelOptions) ? payload.modelOptions : [];
    const defaultOptions = Array.isArray(defaults.modelOptions) ? defaults.modelOptions : [];
    [...payloadOptions, ...defaultOptions].forEach((item) => {
      const value = typeof item === 'string' ? item.trim() : '';
      if (!value || normalizedModelOptions.includes(value)) {
        return;
      }
      normalizedModelOptions.push(value);
    });

    return {
      state: typeof payload.state === 'string' && payload.state.trim() ? payload.state.trim() : 'editor',
      originalText: typeof payload.originalText === 'string' ? payload.originalText : '',
      translation: typeof payload.translation === 'string' ? payload.translation : '',
      sourceLang: typeof payload.sourceLang === 'string' && payload.sourceLang.trim()
        ? payload.sourceLang.trim()
        : (defaults.sourceLang || 'auto'),
      targetLang: typeof payload.targetLang === 'string' && payload.targetLang.trim()
        ? payload.targetLang.trim()
        : (defaults.targetLang || 'zh-CN'),
      model: typeof payload.model === 'string' && payload.model.trim()
        ? payload.model.trim()
        : (defaults.model || ''),
      modelOptions: normalizedModelOptions,
      translationStyle: normalizeTranslationStyle(
        payload.translationStyle,
        normalizeTranslationStyle(defaults.translationStyle, 'literal')
      ),
      sourceUrl: typeof payload.sourceUrl === 'string' ? payload.sourceUrl : '',
      sourceTitle: typeof payload.sourceTitle === 'string' ? payload.sourceTitle : '',
      error: typeof payload.error === 'string' ? payload.error : '',
      canOpenOptions: payload.canOpenOptions === true,
      autoTranslate: payload.autoTranslate === true
    };
  }

  async function runDirectTranslate(dialogPayload) {
    const originalText = (dialogPayload.originalText || '').trim();
    if (!originalText) {
      return;
    }

    const requestPayload = {
      text: originalText,
      sourceLang: dialogPayload.sourceLang,
      targetLang: dialogPayload.targetLang,
      translationStyle: normalizeTranslationStyle(dialogPayload.translationStyle, 'literal')
    };
    if (dialogPayload.model) {
      requestPayload.model = dialogPayload.model;
    }

    showTranslationDialog({
      ...dialogPayload,
      state: 'loading',
      originalText
    });

    const result = await sendMessageToBackground('translateTextDirect', requestPayload);
    const resolved = asObject(result);

    const nextPayload = {
      ...dialogPayload,
      originalText,
      sourceLang: typeof resolved.sourceLang === 'string' && resolved.sourceLang.trim()
        ? resolved.sourceLang.trim()
        : dialogPayload.sourceLang,
      targetLang: typeof resolved.targetLang === 'string' && resolved.targetLang.trim()
        ? resolved.targetLang.trim()
        : dialogPayload.targetLang,
      model: typeof resolved.model === 'string' && resolved.model.trim()
        ? resolved.model.trim()
        : dialogPayload.model,
      modelOptions: Array.isArray(resolved.modelOptions) && resolved.modelOptions.length > 0
        ? resolved.modelOptions
        : dialogPayload.modelOptions,
      translationStyle: normalizeTranslationStyle(
        resolved.translationStyle,
        requestPayload.translationStyle
      ),
      debugInfo: resolved.debugInfo || null
    };

    if (resolved.ok === true) {
      showTranslationDialog({
        ...nextPayload,
        state: 'done',
        translation: typeof resolved.translation === 'string' ? resolved.translation : ''
      });
      return;
    }

    const message = typeof resolved.error === 'string' && resolved.error.trim()
      ? resolved.error.trim()
      : '翻译失败';

    showTranslationDialog({
      ...nextPayload,
      state: 'error',
      error: message,
      canOpenOptions: shouldOfferOptions(message)
    });
  }

  async function initialize() {
    if (typeof showTranslationDialog !== 'function') {
      throw new Error('翻译弹窗模块未加载');
    }

    const initialPayload = await getInitialPayload();
    const defaults = await getDefaults(initialPayload);
    const dialogPayload = buildDialogPayload(initialPayload, defaults);

    showTranslationDialog(dialogPayload);
    removeBootNode();

    if (dialogPayload.autoTranslate) {
      await runDirectTranslate(dialogPayload);
    }
  }

  initialize().catch((error) => {
    const message = error && error.message ? error.message : String(error);
    updateBootText(`翻译工具初始化失败：${message}`);
    console.error('translate workbench bridge init failed:', error);
  });
})();
