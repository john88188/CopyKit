// 弹出窗口的JavaScript逻辑

document.addEventListener('DOMContentLoaded', async () => {
  try {
    document.getElementById('settings-btn').addEventListener('click', openSettings);
    document.getElementById('add-folder-btn').addEventListener('click', addFolder);
    document.getElementById('search-input').addEventListener('input', handleSearch);
    document.getElementById('folder-sort').addEventListener('change', handleSortChange);
    document.getElementById('note-sort').addEventListener('change', handleSortChange);

    await initializePopupSizing();
    await initializeSortControls();
    await loadData();

    // 添加剪贴板监听按钮
    addClipboardMonitorControls();
  } catch (error) {
    console.error('弹出窗口初始化失败:', error);
    showError('加载数据失败，请刷新重试');
  }
});

const LAST_USED_FOLDER_KEY = 'lastUsedFolderId';
const FOLDER_SORT_KEY = 'popupFolderSort';
const NOTE_SORT_KEY = 'popupNoteSort';
const POPUP_SIZE_KEY = 'popupWindowSize';
const DEFAULT_FOLDER_SORT = 'name-asc';
const DEFAULT_NOTE_SORT = 'time-desc';
const DEFAULT_POPUP_SIZE = { width: 420, height: 560 };
const MIN_POPUP_WIDTH = 360;
const MIN_POPUP_HEIGHT = 480;
const MAX_POPUP_WIDTH = 960;
const MAX_POPUP_HEIGHT = 960;
async function openTranslateWorkbenchInActiveTab() {
  await sendMessageToBackground('openTranslateWorkbench');
}

function clampPopupSize(width, height) {
  const safeWidth = Number.isFinite(width) ? width : DEFAULT_POPUP_SIZE.width;
  const safeHeight = Number.isFinite(height) ? height : DEFAULT_POPUP_SIZE.height;
  return {
    width: Math.min(Math.max(Math.round(safeWidth), MIN_POPUP_WIDTH), MAX_POPUP_WIDTH),
    height: Math.min(Math.max(Math.round(safeHeight), MIN_POPUP_HEIGHT), MAX_POPUP_HEIGHT)
  };
}

function applyPopupSize(width, height) {
  const normalized = clampPopupSize(width, height);
  document.documentElement.style.setProperty('--popup-width', `${normalized.width}px`);
  document.documentElement.style.setProperty('--popup-height', `${normalized.height}px`);
  return normalized;
}

async function loadPopupSizePreference() {
  return new Promise((resolve) => {
    chrome.storage.local.get({
      [POPUP_SIZE_KEY]: DEFAULT_POPUP_SIZE
    }, (result) => {
      const stored = result[POPUP_SIZE_KEY];
      if (!stored || typeof stored !== 'object') {
        resolve(DEFAULT_POPUP_SIZE);
        return;
      }

      resolve(clampPopupSize(stored.width, stored.height));
    });
  });
}

async function savePopupSizePreference(size) {
  return new Promise((resolve) => {
    chrome.storage.local.set({
      [POPUP_SIZE_KEY]: clampPopupSize(size.width, size.height)
    }, resolve);
  });
}

function setupPopupResizeHandle() {
  const handle = document.getElementById('popup-resize-handle');
  if (!handle) {
    return;
  }

  let dragging = false;
  let startX = 0;
  let startY = 0;
  let startWidth = 0;
  let startHeight = 0;
  let lastSize = null;

  const stopDrag = async () => {
    if (!dragging) {
      return;
    }

    dragging = false;
    document.body.style.userSelect = '';
    window.removeEventListener('mousemove', handleMouseMove, true);
    window.removeEventListener('mouseup', stopDrag, true);
    if (lastSize) {
      await savePopupSizePreference(lastSize);
    }
  };

  const handleMouseMove = (event) => {
    if (!dragging) {
      return;
    }

    const nextWidth = startWidth + (event.clientX - startX);
    const nextHeight = startHeight + (event.clientY - startY);
    lastSize = applyPopupSize(nextWidth, nextHeight);
  };

  handle.addEventListener('mousedown', (event) => {
    if (event.button !== 0) {
      return;
    }

    dragging = true;
    startX = event.clientX;
    startY = event.clientY;
    startWidth = window.innerWidth;
    startHeight = window.innerHeight;
    lastSize = { width: startWidth, height: startHeight };
    document.body.style.userSelect = 'none';
    window.addEventListener('mousemove', handleMouseMove, true);
    window.addEventListener('mouseup', stopDrag, true);
    event.preventDefault();
  });

  handle.addEventListener('dblclick', async (event) => {
    event.preventDefault();
    const resetSize = applyPopupSize(DEFAULT_POPUP_SIZE.width, DEFAULT_POPUP_SIZE.height);
    await savePopupSizePreference(resetSize);
    showQuickTip('已恢复默认窗口尺寸');
  });
}

async function initializePopupSizing() {
  const size = await loadPopupSizePreference();
  applyPopupSize(size.width, size.height);
  setupPopupResizeHandle();
}

function normalizeFolderId(folderId) {
  return folderId == null || folderId === '' ? 'default' : String(folderId);
}

function normalizeFolderSort(value) {
  const validValues = new Set(['name-asc', 'name-desc', 'latest']);
  return validValues.has(value) ? value : DEFAULT_FOLDER_SORT;
}

function normalizeNoteSort(value) {
  const validValues = new Set(['time-desc', 'time-asc', 'title-asc', 'title-desc']);
  return validValues.has(value) ? value : DEFAULT_NOTE_SORT;
}

function getCurrentFolderSort() {
  const select = document.getElementById('folder-sort');
  return normalizeFolderSort(select ? select.value : DEFAULT_FOLDER_SORT);
}

function getCurrentNoteSort() {
  const select = document.getElementById('note-sort');
  return normalizeNoteSort(select ? select.value : DEFAULT_NOTE_SORT);
}

function getSearchQuery() {
  const input = document.getElementById('search-input');
  return input ? input.value.trim() : '';
}

function noteBelongsToFolder(note, folderId) {
  return normalizeFolderId(note.folderId) === normalizeFolderId(folderId);
}

function getNoteDisplayTitle(note) {
  const customTitle = typeof note.customTitle === 'string' ? note.customTitle.trim() : '';
  if (customTitle) {
    return customTitle;
  }

  const sourceTitle = typeof note.sourceTitle === 'string' ? note.sourceTitle.trim() : '';
  if (sourceTitle) {
    return sourceTitle;
  }

  return note.type === 'image' ? '图片笔记' : '文本笔记';
}

function sortFolders(folders, sortType) {
  const normalized = normalizeFolderSort(sortType);
  const sorted = [...folders];

  if (normalized === 'latest') {
    sorted.sort((a, b) => {
      const aTime = Number(a.lastModified || 0);
      const bTime = Number(b.lastModified || 0);
      return bTime - aTime;
    });
    return sorted;
  }

  sorted.sort((a, b) => {
    const aName = String(a.name || '');
    const bName = String(b.name || '');
    return aName.localeCompare(bName, 'zh-CN', { sensitivity: 'base' });
  });

  if (normalized === 'name-desc') {
    sorted.reverse();
  }

  return sorted;
}

function sortNotes(notes, sortType) {
  const normalized = normalizeNoteSort(sortType);
  const sorted = [...notes];

  if (normalized === 'time-asc') {
    sorted.sort((a, b) => Number(a.timestamp || 0) - Number(b.timestamp || 0));
    return sorted;
  }

  if (normalized === 'title-asc' || normalized === 'title-desc') {
    sorted.sort((a, b) => {
      const aTitle = getNoteDisplayTitle(a);
      const bTitle = getNoteDisplayTitle(b);
      return aTitle.localeCompare(bTitle, 'zh-CN', { sensitivity: 'base' });
    });
    if (normalized === 'title-desc') {
      sorted.reverse();
    }
    return sorted;
  }

  sorted.sort((a, b) => Number(b.timestamp || 0) - Number(a.timestamp || 0));
  return sorted;
}

async function getSortPreferences() {
  return new Promise((resolve) => {
    chrome.storage.local.get({
      [FOLDER_SORT_KEY]: DEFAULT_FOLDER_SORT,
      [NOTE_SORT_KEY]: DEFAULT_NOTE_SORT
    }, resolve);
  });
}

async function saveSortPreferences(preferences) {
  return new Promise((resolve) => {
    chrome.storage.local.set(preferences, resolve);
  });
}

async function initializeSortControls() {
  const preferences = await getSortPreferences();
  const folderSortSelect = document.getElementById('folder-sort');
  const noteSortSelect = document.getElementById('note-sort');

  if (folderSortSelect) {
    folderSortSelect.value = normalizeFolderSort(preferences[FOLDER_SORT_KEY]);
  }

  if (noteSortSelect) {
    noteSortSelect.value = normalizeNoteSort(preferences[NOTE_SORT_KEY]);
  }
}

async function handleSortChange() {
  try {
    await saveSortPreferences({
      [FOLDER_SORT_KEY]: getCurrentFolderSort(),
      [NOTE_SORT_KEY]: getCurrentNoteSort()
    });
    await refreshCurrentView();
  } catch (error) {
    console.error('更新排序失败:', error);
    showError('更新排序失败: ' + error.message);
  }
}

async function getLastUsedFolderId() {
  return new Promise((resolve) => {
    chrome.storage.local.get([LAST_USED_FOLDER_KEY], (result) => {
      const value = result[LAST_USED_FOLDER_KEY];
      resolve(typeof value === 'string' && value.trim() ? value : 'default');
    });
  });
}

async function setLastUsedFolderId(folderId) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [LAST_USED_FOLDER_KEY]: normalizeFolderId(folderId) }, resolve);
  });
}

// 显示错误信息
function showError(message) {
  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-message';
  errorDiv.textContent = message;
  errorDiv.style.cssText = `
    background: #ffebee;
    color: #c62828;
    padding: 8px 12px;
    border-radius: 4px;
    margin: 8px;
    font-size: 12px;
  `;
  document.body.insertBefore(errorDiv, document.body.firstChild);
  
  setTimeout(() => errorDiv.remove(), 3000);
}

// 显示加载状态
function showLoading(message = '加载中...') {
  const loadingDiv = document.createElement('div');
  loadingDiv.id = 'loading-indicator';
  loadingDiv.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 12px 16px;
    border-radius: 4px;
    z-index: 9999;
    font-size: 12px;
  `;
  loadingDiv.textContent = message;
  document.body.appendChild(loadingDiv);
}

// 隐藏加载状态
function hideLoading() {
  const loadingDiv = document.getElementById('loading-indicator');
  if (loadingDiv) {
    loadingDiv.remove();
  }
}

// 发送消息到背景脚本
async function sendMessageToBackground(action, data = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action, ...data }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (response && response.success) {
        if (Object.prototype.hasOwnProperty.call(response, 'data')) {
          resolve(response.data);
        } else if (Object.prototype.hasOwnProperty.call(response, 'result')) {
          resolve(response.result);
        } else if (Object.prototype.hasOwnProperty.call(response, 'folderId')) {
          resolve(response.folderId);
        } else if (Object.prototype.hasOwnProperty.call(response, 'noteId')) {
          resolve(response.noteId);
        } else if (Object.prototype.hasOwnProperty.call(response, 'message')) {
          resolve(response.message);
        } else {
          resolve(null);
        }
      } else {
        reject(new Error(response?.error || '操作失败'));
      }
    });
  });
}

// 加载数据
async function loadData() {
  try {
    showLoading('正在加载数据...');
    
    // 从背景脚本获取数据
    const [notes, folders, lastUsedFolderId] = await Promise.all([
      sendMessageToBackground('getNotes'),
      sendMessageToBackground('getFolders'),
      getLastUsedFolderId()
    ]);

    hideLoading();

    // 打开弹窗时默认定位到上次选择的文件夹
    updateFolderTree(folders || [], notes || [], lastUsedFolderId, {
      folderSort: getCurrentFolderSort(),
      noteSort: getCurrentNoteSort()
    });
    
  } catch (error) {
    hideLoading();
    console.error('加载数据失败:', error);
    showError('加载数据失败: ' + error.message);
  }
}

// 显示空状态
function showEmptyState() {
  const notesList = document.getElementById('notes-list');
  notesList.innerHTML = `
    <div class="empty-state" style="
      text-align: center;
      padding: 40px 20px;
      color: #666;
      font-size: 14px;
    ">
      <div style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;">📝</div>
      <p>还没有笔记</p>
      <p style="font-size: 12px; margin-top: 8px;">
        选择网页内容后右键选择"保存到摘抄猫"开始使用
      </p>
    </div>
  `;
}

function createActionButton(className, title, text, onClick) {
  const button = document.createElement('button');
  button.className = className;
  button.type = 'button';
  button.title = title;
  button.textContent = text;
  button.addEventListener('click', async (event) => {
    event.stopPropagation();
    try {
      await onClick();
    } catch (error) {
      console.error(`${title}失败:`, error);
      showError(`${title}失败: ${error.message}`);
    }
  });
  return button;
}

// 创建笔记元素
function createNoteElement(note) {
  const noteDiv = document.createElement('div');
  noteDiv.className = 'note-item';
  noteDiv.style.cssText = `
    padding: 12px;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    margin-bottom: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    background: white;
  `;
  
  // 鼠标悬停效果
  noteDiv.addEventListener('mouseenter', () => {
    noteDiv.style.backgroundColor = '#f5f5f5';
    noteDiv.style.borderColor = '#ccc';
  });
  
  noteDiv.addEventListener('mouseleave', () => {
    noteDiv.style.backgroundColor = 'white';
    noteDiv.style.borderColor = '#e0e0e0';
  });

  const headerRow = document.createElement('div');
  headerRow.className = 'note-header-row';

  const titleDiv = document.createElement('div');
  titleDiv.className = 'note-title-text';
  titleDiv.textContent = getNoteDisplayTitle(note);

  const actionsDiv = document.createElement('div');
  actionsDiv.className = 'note-actions';
  actionsDiv.appendChild(createActionButton('note-action-btn', '重命名内容', '✏', async () => {
    await renameNote(note);
  }));
  actionsDiv.appendChild(createActionButton('note-action-btn danger', '删除内容', '🗑', async () => {
    await deleteNoteItem(note);
  }));

  headerRow.appendChild(titleDiv);
  headerRow.appendChild(actionsDiv);
  noteDiv.appendChild(headerRow);

  const contentDiv = document.createElement('div');
  contentDiv.className = 'note-content';
  contentDiv.style.marginBottom = '4px';
  const rawContent = String(note.content || '');
  const preview = rawContent.length > 100 ? `${rawContent.substring(0, 100)}...` : rawContent;
  contentDiv.textContent = note.type === 'image' ? '🖼️ 图片内容' : preview || '(空内容)';
  noteDiv.appendChild(contentDiv);

  const metaDiv = document.createElement('div');
  metaDiv.style.cssText = 'font-size: 11px; color: #999;';
  metaDiv.textContent = `${note.sourceTitle || '未知来源'} • ${formatDate(note.timestamp)}`;
  noteDiv.appendChild(metaDiv);

  if (note.tags && note.tags.length > 0) {
    const tagsDiv = document.createElement('div');
    tagsDiv.style.cssText = 'margin-top: 6px; display: flex; gap: 4px; flex-wrap: wrap;';
    note.tags.forEach((tag) => {
      const tagSpan = document.createElement('span');
      tagSpan.textContent = tag;
      tagSpan.style.cssText = `
        background: #e3f2fd;
        color: #1976d2;
        font-size: 10px;
        padding: 2px 6px;
        border-radius: 10px;
        white-space: nowrap;
      `;
      tagsDiv.appendChild(tagSpan);
    });
    noteDiv.appendChild(tagsDiv);
  }
  
  // 点击事件 - 打开笔记详情
  noteDiv.addEventListener('click', () => {
    openNoteDetails(note.id);
  });
  
  return noteDiv;
}

// 转义HTML
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text == null ? '' : String(text);
  return div.innerHTML;
}

// 格式化日期
function formatDate(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 1) {
    return '今天';
  } else if (diffDays === 2) {
    return '昨天';
  } else if (diffDays <= 7) {
    return `${diffDays}天前`;
  } else {
    return date.toLocaleDateString('zh-CN');
  }
}

// 搜索处理
let searchTimeout;
async function handleSearch(event) {
  clearTimeout(searchTimeout);
  
  searchTimeout = setTimeout(async () => {
    const query = event.target.value.trim();
    
    if (!query) {
      await loadData();
      return;
    }

    await renderSearchResults(query);
  }, 300); // 防抖
}

async function renderSearchResults(query) {
  try {
    showLoading('搜索中...');
    const noteSort = getCurrentNoteSort();
    const results = await sendMessageToBackground('searchNotes', { query });
    const sortedResults = sortNotes(results || [], noteSort);
    hideLoading();

    const notesList = document.getElementById('notes-list');
    notesList.innerHTML = '';

    if (sortedResults.length === 0) {
      notesList.innerHTML = `
        <div class="search-empty" style="
          text-align: center;
          padding: 20px;
          color: #666;
          font-size: 12px;
        ">
          没有找到匹配的笔记
        </div>
      `;
      document.getElementById('note-count').textContent = 0;
      return;
    }

    document.getElementById('note-count').textContent = sortedResults.length;
    sortedResults.forEach((note) => {
      notesList.appendChild(createNoteElement(note));
    });
  } catch (error) {
    hideLoading();
    console.error('搜索失败:', error);
    showError('搜索失败: ' + error.message);
  }
}

async function refreshCurrentView() {
  const query = getSearchQuery();
  if (query) {
    await renderSearchResults(query);
    return;
  }
  await loadData();
}

async function renameNote(note) {
  const currentTitle = getNoteDisplayTitle(note);
  const nextTitle = prompt('请输入新的内容标题（留空则恢复默认标题）:', currentTitle);
  if (nextTitle === null) {
    return;
  }

  const trimmedTitle = nextTitle.trim();
  if (trimmedTitle === (typeof note.customTitle === 'string' ? note.customTitle.trim() : '')) {
    return;
  }

  try {
    showLoading('正在重命名...');
    await sendMessageToBackground('updateNote', {
      id: note.id,
      data: { customTitle: trimmedTitle }
    });
    hideLoading();
    showQuickTip('内容已重命名');
    await refreshCurrentView();
  } catch (error) {
    hideLoading();
    console.error('重命名内容失败:', error);
    showError('重命名内容失败: ' + error.message);
  }
}

async function deleteNoteItem(note) {
  const title = getNoteDisplayTitle(note);
  if (!confirm(`确定删除“${title}”吗？删除后无法恢复。`)) {
    return;
  }

  try {
    showLoading('正在删除内容...');
    await sendMessageToBackground('deleteNote', { id: note.id });
    hideLoading();
    showQuickTip('内容已删除');
    await refreshCurrentView();
  } catch (error) {
    hideLoading();
    console.error('删除内容失败:', error);
    showError('删除内容失败: ' + error.message);
  }
}

async function renameFolder(folder) {
  const currentName = String(folder.name || '').trim();
  const nextName = prompt('请输入新的文件夹名称:', currentName);
  if (nextName === null) {
    return;
  }

  const trimmedName = nextName.trim();
  if (!trimmedName) {
    showError('文件夹名称不能为空');
    return;
  }

  if (trimmedName === currentName) {
    return;
  }

  try {
    showLoading('正在重命名文件夹...');
    const allFolders = await sendMessageToBackground('getFolders');
    const duplicated = (allFolders || []).some((item) => {
      if (String(item.id) === String(folder.id)) {
        return false;
      }
      return String(item.name || '').trim().toLowerCase() === trimmedName.toLowerCase();
    });

    if (duplicated) {
      hideLoading();
      showError('已存在同名文件夹');
      return;
    }

    await sendMessageToBackground('updateFolder', {
      id: folder.id,
      data: { name: trimmedName, path: `/${trimmedName}` }
    });
    hideLoading();
    showQuickTip('文件夹已重命名');
    await refreshCurrentView();
  } catch (error) {
    hideLoading();
    console.error('重命名文件夹失败:', error);
    showError('重命名文件夹失败: ' + error.message);
  }
}

async function deleteFolder(folder, notes) {
  const folderId = normalizeFolderId(folder.id);
  if (folderId === 'default') {
    showError('默认文件夹不支持删除');
    return;
  }

  const noteCount = notes.filter((note) => noteBelongsToFolder(note, folderId)).length;
  const confirmed = confirm(`确定删除文件夹“${folder.name}”吗？\n\n该文件夹下 ${noteCount} 条内容将移动到默认文件夹。`);
  if (!confirmed) {
    return;
  }

  try {
    showLoading('正在删除文件夹...');
    const result = await sendMessageToBackground('deleteFolder', {
      id: folder.id,
      moveNotesToDefault: true
    });

    const lastUsedFolderId = await getLastUsedFolderId();
    if (normalizeFolderId(lastUsedFolderId) === folderId) {
      await setLastUsedFolderId('default');
    }

    hideLoading();
    const movedCount = Number(result?.movedNotes || 0);
    showQuickTip(`文件夹已删除，已迁移 ${movedCount} 条内容`);
    await refreshCurrentView();
  } catch (error) {
    hideLoading();
    console.error('删除文件夹失败:', error);
    showError('删除文件夹失败: ' + error.message);
  }
}

// 更新文件夹树
function updateFolderTree(folders, notes, preferredFolderId = 'default', options = {}) {
  const folderTree = document.getElementById('folder-tree');
  if (!folderTree) return;

  const folderSort = normalizeFolderSort(options.folderSort || getCurrentFolderSort());
  const noteSort = normalizeNoteSort(options.noteSort || getCurrentNoteSort());
  const folderList = [...folders];
  folderTree.innerHTML = '';

  // 添加默认文件夹
  if (!folderList.some(f => normalizeFolderId(f.id) === 'default')) {
    folderList.unshift({ id: 'default', name: '默认文件夹', path: '/默认文件夹' });
  }

  const defaultFolder = folderList.find((folder) => normalizeFolderId(folder.id) === 'default');
  const nonDefaultFolders = folderList.filter((folder) => normalizeFolderId(folder.id) !== 'default');
  const sortedFolders = [
    defaultFolder || { id: 'default', name: '默认文件夹', path: '/默认文件夹' },
    ...sortFolders(nonDefaultFolders, folderSort)
  ];

  const folderItemMap = new Map();
  const availableFolderIds = new Set(sortedFolders.map((folder) => normalizeFolderId(folder.id)));

  const notesList = document.getElementById('notes-list');
  const noteCountElement = document.getElementById('note-count');

  const renderFolderNotes = (folderId) => {
    const normalizedFolderId = normalizeFolderId(folderId);
    const folderNotes = notes.filter((note) => noteBelongsToFolder(note, normalizedFolderId));
    const sortedFolderNotes = sortNotes(folderNotes, noteSort);
    notesList.innerHTML = '';

    if (notes.length === 0) {
      showEmptyState();
      noteCountElement.textContent = 0;
      return;
    }

    if (sortedFolderNotes.length === 0) {
      notesList.innerHTML = `
        <div class="folder-empty" style="
          text-align: center;
          padding: 20px;
          color: #666;
          font-size: 12px;
        ">
          该文件夹暂无笔记
        </div>
      `;
      noteCountElement.textContent = 0;
      return;
    }

    noteCountElement.textContent = sortedFolderNotes.length;
    sortedFolderNotes.forEach((note) => {
      const noteElement = createNoteElement(note);
      notesList.appendChild(noteElement);
    });
  };

  const setActiveFolderStyle = (activeFolderId) => {
    folderItemMap.forEach((folderDiv, folderId) => {
      if (folderId === activeFolderId) {
        folderDiv.style.backgroundColor = '#e8f0fe';
        folderDiv.style.color = '#174ea6';
        folderDiv.dataset.active = '1';
      } else {
        folderDiv.style.backgroundColor = 'transparent';
        folderDiv.style.color = '';
        folderDiv.dataset.active = '0';
      }
    });
  };

  sortedFolders.forEach((folder) => {
    const folderId = normalizeFolderId(folder.id);
    const folderDiv = document.createElement('div');
    folderDiv.className = 'folder-item';
    folderDiv.style.cssText = `
      padding: 8px 12px;
      cursor: pointer;
      border-radius: 4px;
      font-size: 12px;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: background-color 0.2s ease;
    `;

    // 统计文件夹中的笔记数量
    const count = notes.filter((note) => noteBelongsToFolder(note, folderId)).length;

    const iconSpan = document.createElement('span');
    iconSpan.textContent = '📁';
    const nameSpan = document.createElement('span');
    nameSpan.className = 'folder-name';
    nameSpan.textContent = folder.name;
    const countSpan = document.createElement('span');
    countSpan.style.cssText = 'margin-left: auto; color: #999; font-size: 10px;';
    countSpan.textContent = String(count);

    folderDiv.appendChild(iconSpan);
    folderDiv.appendChild(nameSpan);
    folderDiv.appendChild(countSpan);

    if (folderId !== 'default') {
      const actionsDiv = document.createElement('div');
      actionsDiv.className = 'folder-item-actions';

      const renameBtn = createActionButton('folder-action-btn', '重命名文件夹', '✏', async () => {
        await renameFolder(folder);
      });

      const deleteBtn = createActionButton('folder-action-btn danger', '删除文件夹', '🗑', async () => {
        await deleteFolder(folder, notes);
      });

      actionsDiv.appendChild(renameBtn);
      actionsDiv.appendChild(deleteBtn);
      folderDiv.appendChild(actionsDiv);
    }

    folderDiv.addEventListener('mouseenter', () => {
      if (folderDiv.dataset.active !== '1') {
        folderDiv.style.backgroundColor = '#f0f0f0';
      }
    });

    folderDiv.addEventListener('mouseleave', () => {
      if (folderDiv.dataset.active !== '1') {
        folderDiv.style.backgroundColor = 'transparent';
      }
    });

    // 点击事件 - 过滤显示该文件夹的笔记，并持久化“最后使用文件夹”
    folderDiv.addEventListener('click', async () => {
      try {
        setActiveFolderStyle(folderId);
        renderFolderNotes(folderId);
        await setLastUsedFolderId(folderId);
      } catch (error) {
        console.error('加载文件夹失败:', error);
        showError('加载文件夹失败: ' + error.message);
      }
    });

    folderItemMap.set(folderId, folderDiv);
    folderTree.appendChild(folderDiv);
  });

  const initialFolderId = availableFolderIds.has(normalizeFolderId(preferredFolderId))
    ? normalizeFolderId(preferredFolderId)
    : 'default';

  setActiveFolderStyle(initialFolderId);
  renderFolderNotes(initialFolderId);

  if (initialFolderId !== normalizeFolderId(preferredFolderId)) {
    setLastUsedFolderId(initialFolderId).catch((error) => {
      console.log('更新默认文件夹失败:', error.message);
    });
  }
}

// 添加文件夹
async function addFolder() {
  const folderName = prompt('请输入文件夹名称:');
  if (!folderName || !folderName.trim()) return;

  const trimmedName = folderName.trim();
  try {
    showLoading('创建文件夹...');

    const folders = await sendMessageToBackground('getFolders');
    const duplicated = (folders || []).some((folder) =>
      String(folder.name || '').trim().toLowerCase() === trimmedName.toLowerCase()
    );

    if (duplicated) {
      hideLoading();
      showError('已存在同名文件夹');
      return;
    }

    const folderData = {
      name: trimmedName,
      parentId: null,
      path: `/${trimmedName}`
    };

    const createdFolderId = await sendMessageToBackground('addFolder', { data: folderData });
    hideLoading();

    if (createdFolderId) {
      await setLastUsedFolderId(createdFolderId);
    }
    await refreshCurrentView();
  } catch (error) {
    hideLoading();
    console.error('创建文件夹失败:', error);
    showError('创建文件夹失败: ' + error.message);
  }
}

// 打开设置页面
function openSettings() {
  chrome.tabs.create({ url: chrome.runtime.getURL('options.html') });
}

// 打开笔记详情
function openNoteDetails(noteId) {
  const url = chrome.runtime.getURL(`note-details.html?id=${encodeURIComponent(noteId)}`);
  chrome.tabs.create({ url });
}

function showQuickTip(message, duration = 1500) {
  const tip = document.createElement('div');
  tip.textContent = message;
  tip.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 8px 12px;
    border-radius: 4px;
    font-size: 12px;
    z-index: 9999;
  `;
  document.body.appendChild(tip);
  setTimeout(() => tip.remove(), duration);
}

// 添加剪贴板监听控制按钮
function addClipboardMonitorControls() {
  const controlsContainer = document.getElementById('quick-controls');
  if (!controlsContainer) {
    return;
  }

  controlsContainer.innerHTML = '';

  chrome.storage.local.get(['clipboardMonitor'], function(result) {
    let clipboardEnabled = result.clipboardMonitor === true;

    const translateBtn = document.createElement('button');
    translateBtn.className = 'quick-control-btn';
    translateBtn.textContent = '翻译工具';
    translateBtn.title = '打开文本翻译工具';

    const checkBtn = document.createElement('button');
    checkBtn.className = 'quick-control-btn';
    checkBtn.textContent = '剪贴板检查';
    checkBtn.title = '手动检查剪贴板';

    const clipboardToggleBtn = document.createElement('button');
    clipboardToggleBtn.className = 'quick-control-btn';

    function updateClipboardButtons() {
      clipboardToggleBtn.textContent = clipboardEnabled ? '剪贴板:开' : '剪贴板:关';
      clipboardToggleBtn.title = clipboardEnabled ? '剪贴板监听已启用' : '剪贴板监听已禁用';
      clipboardToggleBtn.classList.toggle('active', clipboardEnabled);

      checkBtn.disabled = !clipboardEnabled;
      checkBtn.classList.toggle('active', clipboardEnabled);
      checkBtn.title = clipboardEnabled ? '手动检查剪贴板' : '请先启用剪贴板监听';
    }

    updateClipboardButtons();

    clipboardToggleBtn.addEventListener('click', async () => {
      try {
        const newStatus = !clipboardEnabled;
        if (newStatus) {
          const granted = await ensureClipboardReadPermission();
          if (!granted) {
            showError('未授予剪贴板读取权限，无法启用监听');
            return;
          }
        }

        chrome.storage.local.set({ clipboardMonitor: newStatus }, function() {
          console.log(`剪贴板监听已${newStatus ? '启用' : '禁用'}`);
        });

        await sendMessageToBackground('updateClipboardMonitor', { enabled: newStatus });
        clipboardEnabled = newStatus;
        updateClipboardButtons();
        showQuickTip(newStatus ? '剪贴板监听已启用' : '剪贴板监听已禁用');
      } catch (error) {
        console.error('切换剪贴板监听状态失败:', error);
        showError('操作失败: ' + error.message);
      }
    });

    checkBtn.addEventListener('click', async () => {
      if (!clipboardEnabled) {
        return;
      }

      try {
        await sendMessageToBackground('manualCheckClipboard');
        showQuickTip('正在检查剪贴板...', 1000);
      } catch (error) {
        console.error('手动检查剪贴板失败:', error);
        showError('操作失败: ' + error.message);
      }
    });

    translateBtn.addEventListener('click', async () => {
      try {
        await openTranslateWorkbenchInActiveTab();
        window.close();
      } catch (error) {
        console.error('打开翻译工具失败:', error);
        showError('打开翻译工具失败: ' + error.message);
      }
    });

    controlsContainer.appendChild(translateBtn);
    controlsContainer.appendChild(checkBtn);
    controlsContainer.appendChild(clipboardToggleBtn);
  });
}

async function ensureClipboardReadPermission() {
  return new Promise((resolve, reject) => {
    if (!chrome.permissions || typeof chrome.permissions.contains !== 'function') {
      resolve(true);
      return;
    }

    chrome.permissions.contains({ permissions: ['clipboardRead'] }, (hasPermission) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      if (hasPermission === true) {
        resolve(true);
        return;
      }

      chrome.permissions.request({ permissions: ['clipboardRead'] }, (granted) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(granted === true);
      });
    });
  });
}
