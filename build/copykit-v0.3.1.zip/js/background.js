// 背景脚本 - 处理扩展的核心逻辑 (基于原生 IndexedDB)

// 导入数据服务
importScripts('database-native.js');

// 用于存储内容脚本就绪的标记
let contentScriptsReady = {};

// 添加剪贴板相关变量
let lastClipboardContent = '';
let clipboardMonitorEnabled = false;
const CLIPBOARD_ALARM_NAME = 'copykit-check-clipboard';
const CLIPBOARD_ALARM_PERIOD_MINUTES = 1;
const TRANSLATE_WORKBENCH_PAYLOADS_KEY = 'translateWorkbenchPayloads';
const TRANSLATE_WORKBENCH_PAYLOAD_TTL_MS = 10 * 60 * 1000;
const TRANSLATE_WORKBENCH_PAYLOAD_LIMIT = 20;
const TRANSLATE_WORKBENCH_POPUP_WIDTH = 980;
const TRANSLATE_WORKBENCH_POPUP_HEIGHT = 760;
const TRANSLATE_GATEWAY_INSTALL_ID_KEY = 'translateGatewayInstallId';
const TRANSLATE_GATEWAY_SESSION_SKEW_MS = 12 * 1000;
const TRANSLATE_GATEWAY_SESSION_TIMEOUT_MS = 12000;
const TRANSLATE_GATEWAY_TRANSLATE_TIMEOUT_MS = 30000;
const TRANSLATE_RESPONSES_TIMEOUT_MS = 30000;
const TRANSLATE_RESPONSES_MAX_ATTEMPTS = 3;
const gatewaySessionCacheByKey = new Map();

const DEFAULT_SETTINGS = {
  defaultSavePath: 'CopyKit笔记',
  defaultFormat: 'markdown',
  autoSync: false,
  theme: 'system',
  imageFolder: 'images',
  lastUsedFolderId: 'default',
  clipboardMonitor: false,
  pageAnalyzer: false,
  aiSummary: false,
  llmBaseUrl: 'https://api.openai.com',
  llmApiKey: '',
  llmModel: 'gpt-4o-mini',
  llmTemperature: '',
  translateSourceLang: 'auto',
  translateTargetLang: 'zh-CN',
  translateStyle: 'literal',
  translatePopupPreferred: true,
  llmModelCapabilityOverrides: '',
  llmGatewayEnabled: false,
  llmGatewayBaseUrl: '',
  llmGatewayAccessToken: ''
};

// 数据服务实例
let dataService = null;
const DATA_ACTIONS = new Set([
  'saveNote',
  'getNotes',
  'getFolders',
  'addFolder',
  'updateFolder',
  'deleteFolder',
  'deleteNote',
  'updateNote',
  'searchNotes',
  'getStats',
  'exportData',
  'importData',
  'clearAllData'
]);

// 初始化数据服务
async function initializeDataService() {
  if (!dataService) {
    dataService = getDataService();
    await dataService.initialize();
  }
  return dataService;
}

function storageGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, resolve);
  });
}

function storageSet(data) {
  return new Promise((resolve) => {
    chrome.storage.local.set(data, resolve);
  });
}

async function ensureDefaultSettings() {
  const existingSettings = await storageGet(Object.keys(DEFAULT_SETTINGS));
  const mergedSettings = { ...DEFAULT_SETTINGS, ...existingSettings };
  await storageSet(mergedSettings);
}

function tabsCreate(createProperties) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create(createProperties, (tab) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(tab || null);
    });
  });
}

function windowsCreate(createData) {
  return new Promise((resolve, reject) => {
    if (!chrome.windows || typeof chrome.windows.create !== 'function') {
      reject(new Error('windows API 不可用'));
      return;
    }

    chrome.windows.create(createData, (createdWindow) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(createdWindow || null);
    });
  });
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function normalizeWorkbenchPayloadMap(rawMap) {
  return isPlainObject(rawMap) ? rawMap : {};
}

function cleanupWorkbenchPayloadMap(rawMap, nowTs = Date.now()) {
  const map = normalizeWorkbenchPayloadMap(rawMap);
  const entries = Object.entries(map).filter(([payloadId, entry]) => {
    if (!payloadId || !isPlainObject(entry)) {
      return false;
    }
    const timestamp = Number(entry.ts);
    if (!Number.isFinite(timestamp)) {
      return false;
    }
    return nowTs - timestamp <= TRANSLATE_WORKBENCH_PAYLOAD_TTL_MS;
  });

  entries.sort((a, b) => Number(a[1].ts) - Number(b[1].ts));

  while (entries.length > TRANSLATE_WORKBENCH_PAYLOAD_LIMIT) {
    entries.shift();
  }

  return Object.fromEntries(entries);
}

function buildWorkbenchPayloadId() {
  const randomPart = Math.random().toString(36).slice(2, 10);
  return `twb-${Date.now()}-${randomPart}`;
}

async function storeWorkbenchPayload(payload) {
  const payloadId = buildWorkbenchPayloadId();
  const nowTs = Date.now();
  const stored = await storageGet([TRANSLATE_WORKBENCH_PAYLOADS_KEY]);
  const payloadMap = cleanupWorkbenchPayloadMap(stored[TRANSLATE_WORKBENCH_PAYLOADS_KEY], nowTs);
  payloadMap[payloadId] = {
    ts: nowTs,
    payload: isPlainObject(payload) ? payload : {}
  };
  await storageSet({ [TRANSLATE_WORKBENCH_PAYLOADS_KEY]: payloadMap });
  return payloadId;
}

async function consumeWorkbenchPayload(payloadId) {
  if (typeof payloadId !== 'string' || !payloadId.trim()) {
    return null;
  }

  const stored = await storageGet([TRANSLATE_WORKBENCH_PAYLOADS_KEY]);
  const payloadMap = cleanupWorkbenchPayloadMap(stored[TRANSLATE_WORKBENCH_PAYLOADS_KEY], Date.now());
  const entry = payloadMap[payloadId];
  if (Object.prototype.hasOwnProperty.call(payloadMap, payloadId)) {
    delete payloadMap[payloadId];
    await storageSet({ [TRANSLATE_WORKBENCH_PAYLOADS_KEY]: payloadMap });
  }

  if (!isPlainObject(entry)) {
    return null;
  }

  return isPlainObject(entry.payload) ? entry.payload : null;
}

async function openTranslateWorkbenchPage(initialPayload = {}) {
  const payloadId = await storeWorkbenchPayload(initialPayload);
  const pageUrl = `${chrome.runtime.getURL('translate-workbench.html')}#${encodeURIComponent(payloadId)}`;

  const openModeSettings = await storageGet(['translatePopupPreferred']);
  const preferPopup = openModeSettings.translatePopupPreferred !== false;

  if (preferPopup) {
    try {
      await windowsCreate({
        url: pageUrl,
        type: 'popup',
        focused: true,
        width: TRANSLATE_WORKBENCH_POPUP_WIDTH,
        height: TRANSLATE_WORKBENCH_POPUP_HEIGHT
      });
      return payloadId;
    } catch (error) {
      console.log('打开翻译弹窗失败，回退到标签页:', error?.message || String(error));
    }
  }

  await tabsCreate({ url: pageUrl, active: true });
  return payloadId;
}

function contextMenusRemoveAll() {
  return new Promise((resolve) => {
    chrome.contextMenus.removeAll(() => resolve());
  });
}

function createContextMenu(menuConfig) {
  return new Promise((resolve, reject) => {
    chrome.contextMenus.create(menuConfig, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}

let contextMenusInitPromise = null;

async function ensureContextMenus() {
  if (contextMenusInitPromise) {
    return contextMenusInitPromise;
  }

  contextMenusInitPromise = (async () => {
    await contextMenusRemoveAll();
    await createContextMenu({
      id: 'save-text',
      title: '保存文本到摘抄猫',
      contexts: ['selection']
    });
    await createContextMenu({
      id: 'save-image',
      title: '保存图片到摘抄猫',
      contexts: ['image']
    });
    await createContextMenu({
      id: 'translate-text',
      title: '翻译选中文本',
      contexts: ['selection']
    });
  })();

  try {
    await contextMenusInitPromise;
  } finally {
    contextMenusInitPromise = null;
  }
}

const TRANSLATION_MAX_CHARS = 12000;
const TRANSLATION_DEBUG_MAX_EVENTS = 120;
const ENABLE_TRANSLATION_DEBUG = false;
const VALID_TEXT_VERBOSITY = new Set(['low', 'medium', 'high']);
const VALID_REASONING_EFFORT = new Set(['none', 'minimal', 'low', 'medium', 'high', 'xhigh']);
const DEFAULT_MODEL_CAPABILITY_RULES = [
  {
    id: 'gpt-5-pro',
    matchType: 'exact',
    pattern: 'gpt-5-pro',
    textVerbosity: 'low',
    reasoningEffort: null
  },
  {
    id: 'gpt-5-nano',
    matchType: 'exact',
    pattern: 'gpt-5-nano',
    textVerbosity: 'low',
    reasoningEffort: 'minimal'
  },
  {
    id: 'gpt-4.1-nano',
    matchType: 'exact',
    pattern: 'gpt-4.1-nano',
    textVerbosity: 'medium'
  },
  {
    id: 'gpt-5-family',
    matchType: 'prefix',
    pattern: 'gpt-5',
    textVerbosity: 'low',
    reasoningEffort: 'low'
  },
  {
    id: 'o1-family',
    matchType: 'prefix',
    pattern: 'o1',
    textVerbosity: 'low',
    reasoningEffort: 'low'
  },
  {
    id: 'o3-family',
    matchType: 'prefix',
    pattern: 'o3',
    textVerbosity: 'low',
    reasoningEffort: 'low'
  },
  {
    id: 'o4-family',
    matchType: 'prefix',
    pattern: 'o4',
    textVerbosity: 'low',
    reasoningEffort: 'low'
  }
];

function normalizeBaseUrlToV1(baseUrl) {
  const raw = typeof baseUrl === 'string' ? baseUrl.trim() : '';
  if (!raw) {
    throw new Error('BASE_URL 不能为空');
  }

  let url;
  try {
    url = new URL(raw);
  } catch (error) {
    throw new Error('BASE_URL 不是合法的 URL');
  }

  if (url.protocol !== 'https:') {
    throw new Error('BASE_URL 必须使用 https://（发布版不支持明文 http）');
  }

  url.username = '';
  url.password = '';
  url.search = '';
  url.hash = '';

  let path = url.pathname || '/';
  path = path.replace(/\/+$/, '');
  path = path.replace(/\/(chat\/completions|responses)$/i, '');
  if (!path.endsWith('/v1')) {
    path = `${path}/v1`;
  }
  url.pathname = path;

  return url.toString().replace(/\/+$/, '');
}

function buildResponsesUrl(baseUrl) {
  return `${normalizeBaseUrlToV1(baseUrl)}/responses`;
}

async function fetchJsonWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const text = await response.text();
    let data = null;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = null;
      }
    }

    if (!response.ok) {
      const message = data?.error?.message || `HTTP ${response.status}`;
      const error = new Error(message);
      error.status = response.status;
      error.data = data;
      throw error;
    }

    return data;
  } finally {
    clearTimeout(timeoutId);
  }
}

function normalizeGatewayBaseUrl(baseUrl) {
  const raw = typeof baseUrl === 'string' ? baseUrl.trim() : '';
  if (!raw) {
    throw new Error('网关地址不能为空');
  }

  let url;
  try {
    url = new URL(raw);
  } catch (error) {
    throw new Error('网关地址不是合法的 URL');
  }

  const isLocalhost = /^(localhost|127\.0\.0\.1|::1)$/i.test(url.hostname || '');
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && isLocalhost)) {
    throw new Error('网关地址必须使用 https://（localhost 调试可使用 http://）');
  }

  url.username = '';
  url.password = '';
  url.search = '';
  url.hash = '';
  url.pathname = (url.pathname || '/').replace(/\/+$/, '');
  return url.toString().replace(/\/+$/, '');
}

function buildGatewaySessionUrl(baseUrl) {
  return `${normalizeGatewayBaseUrl(baseUrl)}/v1/ext/session`;
}

function buildGatewayTranslateUrl(baseUrl) {
  return `${normalizeGatewayBaseUrl(baseUrl)}/v1/ext/translate`;
}

function buildGatewaySessionCacheKey(gatewayBaseUrl, gatewayAccessToken, installId) {
  return `${gatewayBaseUrl}::${gatewayAccessToken}::${installId}`;
}

function buildGatewayNonce() {
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('');
}

async function getOrCreateGatewayInstallId() {
  const stored = await storageGet([TRANSLATE_GATEWAY_INSTALL_ID_KEY]);
  const candidate = typeof stored[TRANSLATE_GATEWAY_INSTALL_ID_KEY] === 'string'
    ? stored[TRANSLATE_GATEWAY_INSTALL_ID_KEY].trim()
    : '';
  if (candidate) {
    return candidate;
  }

  const generated = typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : `copykit-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  await storageSet({ [TRANSLATE_GATEWAY_INSTALL_ID_KEY]: generated });
  return generated;
}

function getExtensionVersion() {
  try {
    return chrome.runtime.getManifest()?.version || '';
  } catch (error) {
    return '';
  }
}

function parseGatewaySessionExpiry(data) {
  const expiresAtMs = Number(data?.expiresAtMs);
  if (Number.isFinite(expiresAtMs) && expiresAtMs > Date.now()) {
    return Math.floor(expiresAtMs);
  }

  const expiresInSec = Number(data?.expiresInSec || data?.expiresIn);
  if (Number.isFinite(expiresInSec) && expiresInSec > 0) {
    return Date.now() + Math.floor(expiresInSec * 1000);
  }

  return Date.now() + 20 * 60 * 1000;
}

function isGatewaySessionValid(entry) {
  if (!entry || typeof entry.token !== 'string' || !entry.token.trim()) {
    return false;
  }
  const expiresAtMs = Number(entry.expiresAtMs);
  if (!Number.isFinite(expiresAtMs)) {
    return false;
  }
  return Date.now() + TRANSLATE_GATEWAY_SESSION_SKEW_MS < expiresAtMs;
}

async function requestGatewaySession(settings, installId, debugTrace = null) {
  const sessionUrl = buildGatewaySessionUrl(settings.llmGatewayBaseUrl);
  const payload = {
    installId,
    extensionId: chrome.runtime.id,
    extensionVersion: getExtensionVersion()
  };

  addTranslationDebugEvent(debugTrace, 'api_attempt_start', {
    attempt: 1,
    endpoint: '/v1/ext/session'
  });
  const startTs = Date.now();
  let data = null;
  try {
    data = await fetchJsonWithTimeout(sessionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${settings.llmGatewayAccessToken}`
      },
      body: JSON.stringify(payload)
    }, TRANSLATE_GATEWAY_SESSION_TIMEOUT_MS);
    addTranslationDebugEvent(debugTrace, 'api_attempt_success', {
      attempt: 1,
      endpoint: '/v1/ext/session',
      durationMs: Date.now() - startTs
    });
  } catch (error) {
    addTranslationDebugEvent(debugTrace, 'api_attempt_error', {
      attempt: 1,
      endpoint: '/v1/ext/session',
      durationMs: Date.now() - startTs,
      status: Number(error?.status) || null,
      message: formatTranslateError(error)
    });
    throw error;
  }

  const token = typeof data?.sessionToken === 'string' ? data.sessionToken.trim() : '';
  if (!token) {
    throw new Error('网关会话创建失败：响应中缺少 sessionToken');
  }

  return {
    token,
    expiresAtMs: parseGatewaySessionExpiry(data)
  };
}

async function getGatewaySessionToken(settings, installId, debugTrace = null, forceRefresh = false) {
  const cacheKey = buildGatewaySessionCacheKey(
    settings.llmGatewayBaseUrl,
    settings.llmGatewayAccessToken,
    installId
  );

  if (!forceRefresh) {
    const cached = gatewaySessionCacheByKey.get(cacheKey);
    if (isGatewaySessionValid(cached)) {
      return cached.token;
    }
  }

  const sessionData = await requestGatewaySession(settings, installId, debugTrace);
  gatewaySessionCacheByKey.set(cacheKey, sessionData);
  return sessionData.token;
}

function normalizeTranslationStyle(value, fallback = 'literal') {
  const raw = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (!raw) {
    return fallback;
  }

  if (raw === 'paraphrase' || raw === 'free' || raw === 'idiomatic' || raw === '意译') {
    return 'paraphrase';
  }

  return 'literal';
}

async function setTranslateStylePreference(value) {
  const normalized = normalizeTranslationStyle(value, DEFAULT_SETTINGS.translateStyle);
  await storageSet({ translateStyle: normalized });
  return normalized;
}

function buildTranslationInstructions(sourceLang, targetLang, translationStyle = 'literal') {
  const from = typeof sourceLang === 'string' && sourceLang.trim() ? sourceLang.trim() : 'auto';
  const to = typeof targetLang === 'string' && targetLang.trim() ? targetLang.trim() : 'zh-CN';
  const normalizedStyle = normalizeTranslationStyle(translationStyle, 'literal');

  const styleHints = normalizedStyle === 'paraphrase'
    ? [
      'Prefer natural, fluent, and idiomatic wording in the target language.',
      'Preserve intent, tone, and key facts, but avoid rigid word-by-word translation.'
    ]
    : [
      'Keep the translation faithful and close to the original wording when possible.'
    ];

  if (from === 'auto') {
    return [
      'You are a professional translation engine.',
      `Detect the source language, then translate the user text into ${to}.`,
      ...styleHints,
      `Always output only the translated result in ${to}.`,
      'Do not add explanations.'
    ].join(' ');
  }

  return [
    'You are a professional translation engine.',
    `Translate user text from ${from} into ${to}.`,
    ...styleHints,
    `Always output only the translated result in ${to}.`,
    'Do not add explanations.'
  ].join(' ');
}

function estimateTranslationMaxOutputTokens(text, model = '', modelCapabilities = null) {
  const length = typeof text === 'string' ? text.length : 0;
  if (!Number.isFinite(length) || length <= 0) {
    return 256;
  }

  let estimatedTokens = 2048;
  if (length <= 80) estimatedTokens = 96;
  else if (length <= 240) estimatedTokens = 192;
  else if (length <= 800) estimatedTokens = 512;
  else if (length <= 2400) estimatedTokens = 1024;

  const normalizedModel = normalizeModelForCapabilityMatching(model);
  const isReasoningFamily = normalizedModel.startsWith('gpt-5') || normalizedModel.startsWith('o');
  if (isReasoningFamily) {
    estimatedTokens = Math.ceil(estimatedTokens * 1.5);
  }

  if (modelCapabilities?.reasoningEffort && modelCapabilities.reasoningEffort !== 'none') {
    estimatedTokens = Math.ceil(estimatedTokens * 1.35);
  }

  if (isReasoningFamily) {
    estimatedTokens = Math.max(256, estimatedTokens);
  }

  return Math.min(4096, estimatedTokens);
}

function normalizeModelForCapabilityMatching(model) {
  return typeof model === 'string' ? model.trim().toLowerCase() : '';
}

function isModelCapabilityRuleMatch(rule, normalizedModel) {
  if (!rule || !normalizedModel) {
    return false;
  }

  if (rule.matchType === 'prefix') {
    return typeof rule.pattern === 'string' && normalizedModel.startsWith(rule.pattern);
  }

  return normalizedModel === rule.pattern;
}

function normalizeTextVerbosityValue(value) {
  if (value === null || value === undefined) {
    return null;
  }

  const normalized = String(value).trim().toLowerCase();
  if (!normalized || normalized === 'omit' || normalized === 'none' || normalized === 'null') {
    return null;
  }

  return VALID_TEXT_VERBOSITY.has(normalized) ? normalized : undefined;
}

function normalizeReasoningEffortValue(value) {
  if (value === null || value === undefined) {
    return null;
  }

  const normalized = String(value).trim().toLowerCase();
  if (!normalized || normalized === 'omit' || normalized === 'null') {
    return null;
  }

  return VALID_REASONING_EFFORT.has(normalized) ? normalized : undefined;
}

function parseModelCapabilityOverrideRules(rawConfig) {
  const raw = typeof rawConfig === 'string' ? rawConfig.trim() : '';
  if (!raw) {
    return { rules: [], error: null };
  }

  let parsed = null;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    return { rules: [], error: `模型能力覆盖配置 JSON 解析失败: ${error.message || String(error)}` };
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { rules: [], error: '模型能力覆盖配置必须是 JSON 对象' };
  }

  const rules = [];
  Object.entries(parsed).forEach(([rawKey, rawValue], index) => {
    if (typeof rawKey !== 'string') {
      return;
    }

    const candidateKey = rawKey.trim().toLowerCase();
    if (!candidateKey) {
      return;
    }

    const value = rawValue && typeof rawValue === 'object' && !Array.isArray(rawValue) ? rawValue : null;
    if (!value) {
      return;
    }

    const hasTextVerbosity = Object.prototype.hasOwnProperty.call(value, 'textVerbosity');
    const hasReasoningEffort = Object.prototype.hasOwnProperty.call(value, 'reasoningEffort');
    if (!hasTextVerbosity && !hasReasoningEffort) {
      return;
    }

    const textVerbosity = hasTextVerbosity ? normalizeTextVerbosityValue(value.textVerbosity) : null;
    const reasoningEffort = hasReasoningEffort ? normalizeReasoningEffortValue(value.reasoningEffort) : null;
    if (hasTextVerbosity && textVerbosity === undefined) {
      return;
    }
    if (hasReasoningEffort && reasoningEffort === undefined) {
      return;
    }

    let matchType = 'exact';
    let pattern = candidateKey;
    if (candidateKey.endsWith('*')) {
      matchType = 'prefix';
      pattern = candidateKey.slice(0, -1).trim();
    }
    if (!pattern) {
      return;
    }

    rules.push({
      id: `override-${index + 1}:${rawKey}`,
      matchType,
      pattern,
      hasTextVerbosity,
      hasReasoningEffort,
      textVerbosity,
      reasoningEffort
    });
  });

  return { rules, error: null };
}

function resolveModelCapabilities(model, overrideRules = []) {
  const normalizedModel = normalizeModelForCapabilityMatching(model);
  const resolved = {
    textVerbosity: null,
    reasoningEffort: null,
    defaultRuleId: '',
    overrideRuleIds: []
  };
  if (!normalizedModel) {
    return resolved;
  }

  const defaultRule = DEFAULT_MODEL_CAPABILITY_RULES.find((rule) => isModelCapabilityRuleMatch(rule, normalizedModel));
  if (defaultRule) {
    resolved.defaultRuleId = defaultRule.id || '';
    if (Object.prototype.hasOwnProperty.call(defaultRule, 'textVerbosity')) {
      const value = normalizeTextVerbosityValue(defaultRule.textVerbosity);
      resolved.textVerbosity = value === undefined ? null : value;
    }
    if (Object.prototype.hasOwnProperty.call(defaultRule, 'reasoningEffort')) {
      const value = normalizeReasoningEffortValue(defaultRule.reasoningEffort);
      resolved.reasoningEffort = value === undefined ? null : value;
    }
  }

  if (!Array.isArray(overrideRules) || overrideRules.length === 0) {
    return resolved;
  }

  overrideRules.forEach((rule) => {
    if (!isModelCapabilityRuleMatch(rule, normalizedModel)) {
      return;
    }

    if (rule.id) {
      resolved.overrideRuleIds.push(rule.id);
    }

    if (rule.hasTextVerbosity) {
      resolved.textVerbosity = rule.textVerbosity;
    }
    if (rule.hasReasoningEffort) {
      resolved.reasoningEffort = rule.reasoningEffort;
    }
  });

  return resolved;
}

function buildTranslationInput(text) {
  return typeof text === 'string' ? text : '';
}

function formatTranslateError(error) {
  if (!error) {
    return '未知错误';
  }

  if (error.name === 'AbortError') {
    return '请求超时，请稍后重试';
  }

  const status = typeof error.status === 'number' ? error.status : null;
  if (status === 401) return '鉴权失败：请检查 API_KEY 是否正确';
  if (status === 403) return '没有权限访问该接口或模型：请检查 API_KEY / MODEL';
  if (status === 404) return '接口地址无效或服务端不支持 Responses API：请检查 BASE_URL 与服务兼容性';
  if (status === 409) return '请求被服务端拒绝：可能触发了重复请求防护，请重试';
  if (status === 429) return '请求过于频繁或额度不足：请稍后重试';

  const message = typeof error.message === 'string' ? error.message.trim() : '';
  if (message) {
    return message;
  }

  return String(error);
}

function buildTranslationTraceId() {
  return `tx-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function createTranslationDebugTrace(textLength) {
  if (!ENABLE_TRANSLATION_DEBUG) {
    return null;
  }

  return {
    traceId: buildTranslationTraceId(),
    startTs: Date.now(),
    textLength: Number.isFinite(textLength) ? textLength : 0,
    events: []
  };
}

function sanitizeTranslationDebugValue(value) {
  if (typeof value === 'string') {
    const compact = value.replace(/\s+/g, ' ').trim();
    if (!compact) {
      return '';
    }
    return compact.length > 180 ? `${compact.slice(0, 180)}…` : compact;
  }

  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }

  if (typeof value === 'boolean' || value === null) {
    return value;
  }

  return undefined;
}

function addTranslationDebugEvent(trace, stage, detail = null) {
  if (!ENABLE_TRANSLATION_DEBUG || !trace || typeof stage !== 'string' || !stage) {
    return;
  }

  const event = { stage, ts: Date.now() };
  if (detail && typeof detail === 'object') {
    Object.entries(detail).forEach(([key, rawValue]) => {
      const safeValue = sanitizeTranslationDebugValue(rawValue);
      if (safeValue !== undefined) {
        event[key] = safeValue;
      }
    });
  }

  trace.events.push(event);
  if (trace.events.length > TRANSLATION_DEBUG_MAX_EVENTS) {
    trace.events.splice(0, trace.events.length - TRANSLATION_DEBUG_MAX_EVENTS);
  }
}

function buildTranslationDebugInfo(trace, state = 'loading') {
  if (!ENABLE_TRANSLATION_DEBUG || !trace) {
    return null;
  }

  const startTs = typeof trace.startTs === 'number' ? trace.startTs : Date.now();
  const events = Array.isArray(trace.events) ? trace.events : [];
  let previousTs = startTs;

  const normalizedEvents = events.map((event, index) => {
    const ts = typeof event.ts === 'number' ? event.ts : startTs;
    const sinceStartMs = Math.max(0, ts - startTs);
    const deltaMs = index === 0 ? 0 : Math.max(0, ts - previousTs);
    previousTs = ts;

    const detail = {};
    Object.entries(event).forEach(([key, value]) => {
      if (key === 'stage' || key === 'ts') {
        return;
      }
      detail[key] = value;
    });

    return {
      stage: event.stage || 'unknown',
      ts,
      sinceStartMs,
      deltaMs,
      detail
    };
  });

  const endTs = normalizedEvents.length > 0 ? normalizedEvents[normalizedEvents.length - 1].ts : Date.now();
  return {
    traceId: trace.traceId || 'unknown',
    state,
    startTs,
    endTs,
    totalMs: Math.max(0, endTs - startTs),
    textLength: Number.isFinite(trace.textLength) ? trace.textLength : 0,
    events: normalizedEvents
  };
}

function printTranslationDebugInfo(debugInfo) {
  if (!ENABLE_TRANSLATION_DEBUG || !debugInfo || !Array.isArray(debugInfo.events) || debugInfo.events.length === 0) {
    return;
  }

  const traceId = debugInfo.traceId || 'unknown';
  const state = debugInfo.state || 'unknown';
  const totalMs = Number.isFinite(debugInfo.totalMs) ? debugInfo.totalMs : 0;

  console.groupCollapsed(`[CopyKit][Translate][${traceId}] ${state} total=${totalMs}ms`);
  console.table(debugInfo.events.map((event) => {
    const detailText = Object.entries(event.detail || {})
      .map(([key, value]) => `${key}=${String(value)}`)
      .join(' | ');
    return {
      stage: event.stage,
      deltaMs: event.deltaMs,
      elapsedMs: event.sinceStartMs,
      detail: detailText
    };
  }));
  console.groupEnd();
}

async function safeSendMessageToTab(tabId, message) {
  if (typeof tabId !== 'number') {
    return false;
  }

  try {
    await chrome.tabs.sendMessage(tabId, message);
    return true;
  } catch (error) {
    if (shouldAttemptContentScriptInjection(error)) {
      const injected = await ensureContentScriptInjected(tabId);
      if (injected) {
        try {
          await chrome.tabs.sendMessage(tabId, message);
          return true;
        } catch (retryError) {
          console.log('重试发送消息到页面失败:', retryError?.message || String(retryError));
          return false;
        }
      }
    }

    // 可能是特殊页面（chrome:// 等）无法注入内容脚本
    console.log('发送消息到页面失败:', error?.message || String(error));
    return false;
  }
}

function shouldAttemptContentScriptInjection(error) {
  const message = typeof error?.message === 'string' ? error.message : String(error || '');
  if (!message) {
    return false;
  }

  return /Receiving end does not exist|Could not establish connection|message port closed/i.test(message);
}

function executeScriptInTab(tabId, files) {
  return new Promise((resolve, reject) => {
    if (!chrome.scripting || typeof chrome.scripting.executeScript !== 'function') {
      reject(new Error('scripting API 不可用'));
      return;
    }

    chrome.scripting.executeScript({
      target: { tabId },
      files
    }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}

async function ensureContentScriptInjected(tabId) {
  if (typeof tabId !== 'number') {
    return false;
  }

  try {
    await executeScriptInTab(tabId, ['js/translate-languages.js', 'js/content-script.js']);
    return true;
  } catch (error) {
    console.log('补注入内容脚本失败:', error?.message || String(error));
    return false;
  }
}

async function getSelectionTextFromTab(tabId) {
  if (typeof tabId !== 'number') {
    return '';
  }

  const requestPayload = { action: 'getSelectionTextForTranslate' };
  const extractText = (response) => {
    if (!response || response.success !== true) {
      return '';
    }
    return typeof response.text === 'string' ? response.text.trim() : '';
  };

  try {
    const response = await chrome.tabs.sendMessage(tabId, requestPayload);
    return extractText(response);
  } catch (error) {
    if (shouldAttemptContentScriptInjection(error)) {
      const injected = await ensureContentScriptInjected(tabId);
      if (injected) {
        try {
          const retryResponse = await chrome.tabs.sendMessage(tabId, requestPayload);
          return extractText(retryResponse);
        } catch (retryError) {
          console.log('重试获取选中文本失败:', retryError?.message || String(retryError));
          return '';
        }
      }
    }

    console.log('获取页面选中文本失败:', error?.message || String(error));
    return '';
  }
}

async function getActiveTabInCurrentWindow() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!Array.isArray(tabs) || tabs.length === 0) {
      return null;
    }
    return tabs[0] || null;
  } catch (error) {
    console.log('获取当前活动标签页失败:', error?.message || String(error));
    return null;
  }
}

async function resolveTranslateWorkbenchState(overrideOptions = {}) {
  const settings = await getTranslateSettings();
  const sourceLang = normalizeSourceLanguage(
    overrideOptions.sourceLang,
    settings.translateSourceLang
  );
  const targetLang = normalizeTargetLanguage(
    overrideOptions.targetLang,
    settings.translateTargetLang
  );
  const model = resolveModelSelection(
    overrideOptions.model,
    settings.llmModels,
    settings.llmModel
  );
  const modelOptions = buildModelOptions(settings.llmModels, model);
  const translationStyle = normalizeTranslationStyle(
    overrideOptions.translationStyle,
    settings.translateStyle || 'literal'
  );

  return {
    sourceLang,
    targetLang,
    model,
    modelOptions,
    translationStyle
  };
}

async function isTabDialogSupported(tabId) {
  if (typeof tabId !== 'number') {
    return false;
  }

  return safeSendMessageToTab(tabId, { action: 'copykitPing' });
}

async function openTranslateWorkbenchForActiveTab() {
  const activeTab = await getActiveTabInCurrentWindow();
  if (!activeTab || typeof activeTab.id !== 'number') {
    return {
      ok: false,
      error: '未找到可用的活动标签页'
    };
  }

  const workbenchState = await resolveTranslateWorkbenchState();
  const originalText = await getSelectionTextFromTab(activeTab.id);

  const sent = await safeSendMessageToTab(activeTab.id, {
    action: 'showTranslationDialog',
    state: 'editor',
    originalText,
    translation: '',
    sourceLang: workbenchState.sourceLang,
    targetLang: workbenchState.targetLang,
    model: workbenchState.model,
    modelOptions: workbenchState.modelOptions,
    translationStyle: workbenchState.translationStyle,
    sourceUrl: activeTab.url,
    sourceTitle: activeTab.title
  });

  if (!sent) {
    await openTranslateWorkbenchPage({
      state: 'editor',
      originalText,
      translation: '',
      sourceLang: workbenchState.sourceLang,
      targetLang: workbenchState.targetLang,
      model: workbenchState.model,
      modelOptions: workbenchState.modelOptions,
      translationStyle: workbenchState.translationStyle,
      sourceUrl: activeTab.url,
      sourceTitle: activeTab.title,
      canOpenOptions: false,
      autoTranslate: false
    });
    return {
      ok: true,
      tabId: activeTab.id,
      hasSelection: Boolean(originalText),
      fallbackToExtensionPage: true
    };
  }

  return {
    ok: true,
    tabId: activeTab.id,
    hasSelection: Boolean(originalText)
  };
}

async function getTranslateSettings() {
  const stored = await storageGet([
    'llmBaseUrl',
    'llmApiKey',
    'llmModel',
    'llmTemperature',
    'llmGatewayEnabled',
    'llmGatewayBaseUrl',
    'llmGatewayAccessToken',
    'translateSourceLang',
    'translateTargetLang',
    'translateStyle',
    'llmModelCapabilityOverrides'
  ]);

  const llmBaseUrl = typeof stored.llmBaseUrl === 'string' && stored.llmBaseUrl.trim()
    ? stored.llmBaseUrl.trim()
    : DEFAULT_SETTINGS.llmBaseUrl;

  const llmApiKey = typeof stored.llmApiKey === 'string' ? stored.llmApiKey.trim() : '';

  const rawModelValue = typeof stored.llmModel === 'string' ? stored.llmModel.trim() : '';
  const parsedModelList = parseModelList(rawModelValue);
  const llmModels = parsedModelList.length > 0
    ? parsedModelList
    : parseModelList(DEFAULT_SETTINGS.llmModel);
  const llmModel = llmModels[0] || DEFAULT_SETTINGS.llmModel;

  const llmTemperature = normalizeTemperatureSetting(stored.llmTemperature);

  const llmGatewayEnabled = stored.llmGatewayEnabled === true;
  const llmGatewayBaseUrl = typeof stored.llmGatewayBaseUrl === 'string'
    ? stored.llmGatewayBaseUrl.trim()
    : '';
  const llmGatewayAccessToken = typeof stored.llmGatewayAccessToken === 'string'
    ? stored.llmGatewayAccessToken.trim()
    : '';

  const translateSourceLang = typeof stored.translateSourceLang === 'string' && stored.translateSourceLang.trim()
    ? stored.translateSourceLang.trim()
    : DEFAULT_SETTINGS.translateSourceLang;

  const translateTargetLang = typeof stored.translateTargetLang === 'string' && stored.translateTargetLang.trim()
    ? stored.translateTargetLang.trim()
    : DEFAULT_SETTINGS.translateTargetLang;
  const translateStyle = normalizeTranslationStyle(
    stored.translateStyle,
    DEFAULT_SETTINGS.translateStyle
  );

  const llmModelCapabilityOverridesRaw = typeof stored.llmModelCapabilityOverrides === 'string'
    ? stored.llmModelCapabilityOverrides.trim()
    : '';
  const overrideParseResult = parseModelCapabilityOverrideRules(llmModelCapabilityOverridesRaw);
  if (overrideParseResult.error) {
    console.warn(overrideParseResult.error);
  }

  return {
    llmBaseUrl,
    llmApiKey,
    llmModel,
    llmModels,
    llmTemperature,
    llmGatewayEnabled,
    llmGatewayBaseUrl,
    llmGatewayAccessToken,
    translateSourceLang,
    translateTargetLang,
    translateStyle,
    llmModelCapabilityOverridesRaw,
    modelCapabilityOverrideRules: overrideParseResult.rules
  };
}

function normalizeSourceLanguage(value, fallback = 'auto') {
  const normalized = typeof value === 'string' ? value.trim() : '';
  return normalized || fallback;
}

function normalizeTargetLanguage(value, fallback = 'zh-CN') {
  const normalized = typeof value === 'string' ? value.trim() : '';
  if (!normalized || normalized.toLowerCase() === 'auto') {
    return fallback;
  }
  return normalized;
}

function parseModelList(value) {
  const raw = typeof value === 'string' ? value : '';
  return raw
    .split(',')
    .map((item) => item.trim())
    .filter((item) => item);
}

function resolveModelSelection(overrideModel, modelList, fallbackModel) {
  const candidate = typeof overrideModel === 'string' ? overrideModel.trim() : '';
  if (candidate) {
    return candidate;
  }

  if (Array.isArray(modelList) && modelList.length > 0) {
    return modelList[0];
  }

  return fallbackModel;
}

function buildModelOptions(modelList, selectedModel) {
  const options = Array.isArray(modelList) ? [...modelList] : [];
  if (selectedModel && !options.includes(selectedModel)) {
    options.unshift(selectedModel);
  }
  return options;
}

function normalizeTemperatureSetting(value) {
  if (value === null || value === undefined) {
    return null;
  }

  const raw = typeof value === 'string' ? value.trim() : String(value);
  if (!raw) {
    return null;
  }

  const parsed = Number(raw);
  if (!Number.isFinite(parsed)) {
    return null;
  }

  return parsed;
}

function buildTranslatePayload(model, input, instructions, maxOutputTokens = null, modelCapabilities = null) {
  const reasoningEffort = modelCapabilities?.reasoningEffort || null;
  const textVerbosity = modelCapabilities?.textVerbosity || null;
  const payload = {
    model,
    instructions,
    input
  };

  if (Number.isFinite(maxOutputTokens) && maxOutputTokens > 0) {
    payload.max_output_tokens = Math.max(16, Math.floor(maxOutputTokens));
  }

  if (reasoningEffort) {
    payload.reasoning = { effort: reasoningEffort };
  }

  if (textVerbosity) {
    payload.text = { verbosity: textVerbosity };
  }

  return payload;
}

function extractTranslateApiErrorMessage(error) {
  const providerMessage = typeof error?.data?.error?.message === 'string'
    ? error.data.error.message.trim()
    : '';
  if (providerMessage) {
    return providerMessage;
  }

  return typeof error?.message === 'string' ? error.message.trim() : '';
}

function parseSupportedValuesFromErrorMessage(message) {
  const source = typeof message === 'string' ? message.trim() : '';
  if (!source) {
    return [];
  }

  const match = source.match(/supported values are:\s*([^\n\r]+)/i);
  if (!match || !match[1]) {
    return [];
  }

  const quotedValues = Array.from(match[1].matchAll(/["'`“”‘’]([^"'`“”‘’]+)["'`“”‘’]/g))
    .map((item) => (item[1] || '').trim().toLowerCase())
    .filter((item) => item);
  if (quotedValues.length > 0) {
    return quotedValues;
  }

  return match[1]
    .split(/[,\s|/]+/)
    .map((item) => item
      .replace(/^[\s"'`“”‘’]+|[\s"'`“”‘’。，.]+$/g, '')
      .trim()
      .toLowerCase())
    .filter((item) => item);
}

function inferResponsesErrorParam(error, message) {
  const providerParam = typeof error?.data?.error?.param === 'string'
    ? error.data.error.param.trim().toLowerCase()
    : '';
  if (providerParam) {
    return providerParam;
  }

  const source = typeof message === 'string' ? message : '';
  const explicitParamMatch = source.match(/\b(?:unsupported|unknown)\s+parameter:\s*['"]([^'"]+)['"]/i)
    || source.match(/\binvalid\s+['"]([^'"]+)['"]/i);
  if (explicitParamMatch && explicitParamMatch[1]) {
    return explicitParamMatch[1].trim().toLowerCase();
  }

  if (/\breasoning(?:\.effort)?\b/i.test(source)) {
    return 'reasoning.effort';
  }
  if (/\btext\.verbosity\b/i.test(source) || /\bverbosity\b/i.test(source)) {
    return 'text.verbosity';
  }
  if (/\bmax_output_tokens\b/i.test(source)) {
    return 'max_output_tokens';
  }

  return '';
}

function buildResponsesRetryAdjustment(error, requestState) {
  const status = Number(error?.status);
  if ((status !== 400 && status !== 422) || !requestState || typeof requestState !== 'object') {
    return null;
  }

  const message = extractTranslateApiErrorMessage(error);
  const normalizedMessage = message.toLowerCase();
  const errorParam = inferResponsesErrorParam(error, message);
  const looksLikeCapabilityConstraint = /\b(unsupported|not supported|unknown parameter|invalid|supported values are|max_output_tokens|reasoning|verbosity)\b/.test(normalizedMessage);
  if (!errorParam && !looksLikeCapabilityConstraint) {
    return null;
  }

  const supportedValues = parseSupportedValuesFromErrorMessage(message);
  const supportedValuesText = supportedValues.join(', ');
  const supportedReasoningValues = supportedValues.filter((value) => VALID_REASONING_EFFORT.has(value));
  const supportedVerbosityValues = supportedValues.filter((value) => VALID_TEXT_VERBOSITY.has(value));

  const pickDifferentSupportedValue = (currentValue, candidates) => {
    if (!Array.isArray(candidates) || candidates.length === 0) {
      return '';
    }
    for (const candidate of candidates) {
      if (candidate !== currentValue) {
        return candidate;
      }
    }
    return '';
  };

  const buildReasoningSupportedAdjustment = () => {
    const nextValue = pickDifferentSupportedValue(requestState.reasoningEffort || '', supportedReasoningValues);
    if (!nextValue) {
      return null;
    }
    return {
      field: 'reasoningEffort',
      strategy: 'set_supported',
      currentValue: requestState.reasoningEffort || '',
      nextValue,
      errorParam,
      supportedValues: supportedValuesText
    };
  };

  const buildReasoningOmitAdjustment = () => {
    if (!requestState.reasoningEffort) {
      return null;
    }
    return {
      field: 'reasoningEffort',
      strategy: 'omit',
      currentValue: requestState.reasoningEffort,
      nextValue: null,
      errorParam,
      supportedValues: supportedValuesText
    };
  };

  const buildVerbositySupportedAdjustment = () => {
    const nextValue = pickDifferentSupportedValue(requestState.textVerbosity || '', supportedVerbosityValues);
    if (!nextValue) {
      return null;
    }
    return {
      field: 'textVerbosity',
      strategy: 'set_supported',
      currentValue: requestState.textVerbosity || '',
      nextValue,
      errorParam,
      supportedValues: supportedValuesText
    };
  };

  const buildVerbosityOmitAdjustment = () => {
    if (!requestState.textVerbosity) {
      return null;
    }
    return {
      field: 'textVerbosity',
      strategy: 'omit',
      currentValue: requestState.textVerbosity,
      nextValue: null,
      errorParam,
      supportedValues: supportedValuesText
    };
  };

  const buildMaxOutputTokensOmitAdjustment = () => {
    if (!requestState.includeMaxOutputTokens) {
      return null;
    }
    return {
      field: 'maxOutputTokens',
      strategy: 'omit',
      currentValue: 'enabled',
      nextValue: 'omit',
      errorParam,
      supportedValues: supportedValuesText
    };
  };

  const isReasoningHint = errorParam.startsWith('reasoning') || /\breasoning\b/.test(normalizedMessage);
  const isVerbosityHint = errorParam.includes('verbosity')
    || errorParam.startsWith('text')
    || /\btext\.verbosity\b/.test(normalizedMessage)
    || /\bverbosity\b/.test(normalizedMessage);
  const isMaxOutputHint = errorParam === 'max_output_tokens' || /\bmax_output_tokens\b/.test(normalizedMessage);

  if (isMaxOutputHint) {
    return buildMaxOutputTokensOmitAdjustment();
  }

  if (isReasoningHint) {
    return buildReasoningSupportedAdjustment()
      || buildReasoningOmitAdjustment()
      || buildVerbositySupportedAdjustment()
      || buildVerbosityOmitAdjustment();
  }

  if (isVerbosityHint) {
    return buildVerbositySupportedAdjustment()
      || buildVerbosityOmitAdjustment()
      || buildReasoningSupportedAdjustment()
      || buildReasoningOmitAdjustment();
  }

  if (supportedReasoningValues.length > 0
    && requestState.reasoningEffort
    && !supportedReasoningValues.includes(requestState.reasoningEffort)) {
    return buildReasoningSupportedAdjustment() || buildReasoningOmitAdjustment();
  }

  if (supportedVerbosityValues.length > 0
    && requestState.textVerbosity
    && !supportedVerbosityValues.includes(requestState.textVerbosity)) {
    return buildVerbositySupportedAdjustment() || buildVerbosityOmitAdjustment();
  }

  return buildReasoningOmitAdjustment()
    || buildVerbosityOmitAdjustment()
    || buildMaxOutputTokensOmitAdjustment();
}

function applyResponsesRetryAdjustment(requestState, adjustment) {
  if (!requestState || !adjustment || typeof adjustment !== 'object') {
    return false;
  }

  if (adjustment.field === 'reasoningEffort') {
    const nextValue = typeof adjustment.nextValue === 'string' && adjustment.nextValue.trim()
      ? adjustment.nextValue.trim()
      : null;
    if (requestState.reasoningEffort === nextValue) {
      return false;
    }
    requestState.reasoningEffort = nextValue;
    return true;
  }

  if (adjustment.field === 'textVerbosity') {
    const nextValue = typeof adjustment.nextValue === 'string' && adjustment.nextValue.trim()
      ? adjustment.nextValue.trim()
      : null;
    if (requestState.textVerbosity === nextValue) {
      return false;
    }
    requestState.textVerbosity = nextValue;
    return true;
  }

  if (adjustment.field === 'maxOutputTokens') {
    if (!requestState.includeMaxOutputTokens) {
      return false;
    }
    requestState.includeMaxOutputTokens = false;
    return true;
  }

  return false;
}

function normalizeResponseTextCandidate(candidate) {
  if (typeof candidate === 'string') {
    return candidate.trim();
  }

  if (Array.isArray(candidate)) {
    const chunks = candidate
      .map((item) => normalizeResponseTextCandidate(item))
      .filter((item) => item);
    return chunks.join('\n').trim();
  }

  if (!candidate || typeof candidate !== 'object') {
    return '';
  }

  const objectCandidateKeys = ['value', 'text', 'content', 'output_text'];
  for (const key of objectCandidateKeys) {
    if (!Object.prototype.hasOwnProperty.call(candidate, key)) {
      continue;
    }
    const text = normalizeResponseTextCandidate(candidate[key]);
    if (text) {
      return text;
    }
  }

  return '';
}

function extractTextFromResponsesApi(data) {
  const directText = normalizeResponseTextCandidate(data?.output_text);
  if (directText) {
    return directText;
  }

  const output = Array.isArray(data?.output) ? data.output : [];
  const chunks = [];
  output.forEach((item) => {
    const content = Array.isArray(item?.content)
      ? item.content
      : (item?.content ? [item.content] : []);
    content.forEach((part) => {
      const candidate = normalizeResponseTextCandidate(part?.text)
        || normalizeResponseTextCandidate(part?.output_text)
        || normalizeResponseTextCandidate(part?.content);
      if (!candidate) {
        return;
      }
      if (!part?.type || part?.type === 'output_text' || part?.type === 'text' || part?.type === 'message') {
        chunks.push(candidate);
      }
    });

    const itemLevelText = normalizeResponseTextCandidate(item?.text)
      || normalizeResponseTextCandidate(item?.output_text);
    if (itemLevelText) {
      chunks.push(itemLevelText);
    }
  });
  if (chunks.length > 0) {
    return chunks.join('\n').trim();
  }

  const chatContent = normalizeResponseTextCandidate(data?.choices?.[0]?.message?.content);
  if (chatContent) {
    return chatContent;
  }

  const messageContent = normalizeResponseTextCandidate(data?.message?.content);
  if (messageContent) {
    return messageContent;
  }

  return '';
}

function buildMissingTranslationReason(data) {
  const status = typeof data?.status === 'string' ? data.status : '';
  const incompleteReason = typeof data?.incomplete_details?.reason === 'string'
    ? data.incomplete_details.reason
    : '';
  const finishReason = typeof data?.choices?.[0]?.finish_reason === 'string'
    ? data.choices[0].finish_reason
    : '';
  const providerMessage = typeof data?.error?.message === 'string' ? data.error.message.trim() : '';

  if (incompleteReason === 'max_output_tokens' || finishReason === 'length') {
    return '模型输出被 max_output_tokens 截断，请提高输出上限或降低推理强度后重试';
  }

  if (status === 'incomplete') {
    return `模型返回不完整（${incompleteReason || 'unknown'}），请重试或切换模型`;
  }

  if (providerMessage) {
    return providerMessage;
  }

  return '模型未返回翻译结果';
}

async function translateTextViaGatewayApi(text, settings, debugTrace = null) {
  const installId = await getOrCreateGatewayInstallId();
  const translateUrl = buildGatewayTranslateUrl(settings.llmGatewayBaseUrl);
  const input = buildTranslationInput(text);
  const translationStyle = normalizeTranslationStyle(settings.translationStyle, 'literal');
  const modelCapabilities = resolveModelCapabilities(settings.llmModel, settings.modelCapabilityOverrideRules);
  const maxOutputTokens = estimateTranslationMaxOutputTokens(text, settings.llmModel, modelCapabilities);
  const payload = {
    text: input,
    sourceLang: settings.translateSourceLang,
    targetLang: settings.translateTargetLang,
    translationStyle,
    model: settings.llmModel,
    maxOutputTokens,
    timestampMs: Date.now(),
    nonce: buildGatewayNonce(),
    extensionId: chrome.runtime.id,
    extensionVersion: getExtensionVersion()
  };

  addTranslationDebugEvent(debugTrace, 'api_prepare', {
    model: settings.llmModel,
    sourceLang: settings.translateSourceLang,
    targetLang: settings.translateTargetLang,
    translationStyle,
    endpoint: '/v1/ext/translate',
    requestShape: 'gateway(text+langs+model+nonce)',
    inputLength: input.length,
    maxOutputTokens,
    gateway: 'enabled'
  });

  let sessionToken = await getGatewaySessionToken(settings, installId, debugTrace, false);
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    const attemptStart = Date.now();
    addTranslationDebugEvent(debugTrace, 'api_attempt_start', {
      attempt,
      endpoint: '/v1/ext/translate',
      sessionRefresh: attempt === 2 ? 'forced' : 'cached_or_new'
    });

    try {
      const data = await fetchJsonWithTimeout(translateUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionToken}`
        },
        body: JSON.stringify(payload)
      }, TRANSLATE_GATEWAY_TRANSLATE_TIMEOUT_MS);
      addTranslationDebugEvent(debugTrace, 'api_attempt_success', {
        attempt,
        endpoint: '/v1/ext/translate',
        durationMs: Date.now() - attemptStart
      });

      const content = normalizeResponseTextCandidate(data?.translation)
        || extractTextFromResponsesApi(data);
      if (!content) {
        addTranslationDebugEvent(debugTrace, 'api_result_invalid', {
          endpoint: '/v1/ext/translate',
          message: 'gateway_empty_translation'
        });
        throw new Error('网关未返回翻译结果');
      }

      addTranslationDebugEvent(debugTrace, 'api_result_ready', {
        translationLength: content.length
      });
      return content;
    } catch (error) {
      addTranslationDebugEvent(debugTrace, 'api_attempt_error', {
        attempt,
        endpoint: '/v1/ext/translate',
        durationMs: Date.now() - attemptStart,
        status: Number(error?.status) || null,
        message: formatTranslateError(error)
      });

      if (attempt === 1 && (error?.status === 401 || error?.status === 403)) {
        sessionToken = await getGatewaySessionToken(settings, installId, debugTrace, true);
        payload.nonce = buildGatewayNonce();
        payload.timestampMs = Date.now();
        continue;
      }

      throw error;
    }
  }

  throw new Error('网关翻译请求失败');
}

async function translateTextViaOpenAICompatibleApi(text, settings, debugTrace = null) {
  const url = buildResponsesUrl(settings.llmBaseUrl);
  const input = buildTranslationInput(text);
  const instructions = buildTranslationInstructions(
    settings.translateSourceLang,
    settings.translateTargetLang,
    settings.translationStyle
  );
  const modelCapabilities = resolveModelCapabilities(settings.llmModel, settings.modelCapabilityOverrideRules);
  const maxOutputTokens = estimateTranslationMaxOutputTokens(text, settings.llmModel, modelCapabilities);
  const requestState = {
    reasoningEffort: modelCapabilities.reasoningEffort || null,
    textVerbosity: modelCapabilities.textVerbosity || null,
    includeMaxOutputTokens: Number.isFinite(maxOutputTokens) && maxOutputTokens > 0
  };

  addTranslationDebugEvent(debugTrace, 'api_prepare', {
    model: settings.llmModel,
    sourceLang: settings.translateSourceLang,
    targetLang: settings.translateTargetLang,
    translationStyle: settings.translationStyle || 'literal',
    endpoint: '/v1/responses',
    requestShape: 'model+instructions+input',
    inputLength: input.length,
    instructionsLength: instructions.length,
    maxOutputTokens,
    maxOutputTokensEnabled: requestState.includeMaxOutputTokens,
    textVerbosity: requestState.textVerbosity || '',
    reasoningEffort: requestState.reasoningEffort || '',
    capabilityDefaultRule: modelCapabilities.defaultRuleId || '',
    capabilityOverrideRules: modelCapabilities.overrideRuleIds.join(', '),
    adaptiveRetryMaxAttempts: TRANSLATE_RESPONSES_MAX_ATTEMPTS
  });

  for (let attempt = 1; attempt <= TRANSLATE_RESPONSES_MAX_ATTEMPTS; attempt += 1) {
    const payload = buildTranslatePayload(
      settings.llmModel,
      input,
      instructions,
      requestState.includeMaxOutputTokens ? maxOutputTokens : null,
      requestState
    );
    const attemptStart = Date.now();
    addTranslationDebugEvent(debugTrace, 'api_attempt_start', {
      attempt,
      endpoint: '/v1/responses',
      reasoningEffort: requestState.reasoningEffort || '',
      textVerbosity: requestState.textVerbosity || '',
      maxOutputTokens: requestState.includeMaxOutputTokens ? maxOutputTokens : 'omit'
    });

    let data = null;
    try {
      data = await fetchJsonWithTimeout(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${settings.llmApiKey}`
        },
        body: JSON.stringify(payload)
      }, TRANSLATE_RESPONSES_TIMEOUT_MS);
      addTranslationDebugEvent(debugTrace, 'api_attempt_success', {
        attempt,
        durationMs: Date.now() - attemptStart
      });
    } catch (error) {
      addTranslationDebugEvent(debugTrace, 'api_attempt_error', {
        attempt,
        durationMs: Date.now() - attemptStart,
        status: Number(error?.status) || null,
        message: formatTranslateError(error)
      });

      if (attempt < TRANSLATE_RESPONSES_MAX_ATTEMPTS) {
        const adjustment = buildResponsesRetryAdjustment(error, requestState);
        if (adjustment && applyResponsesRetryAdjustment(requestState, adjustment)) {
          addTranslationDebugEvent(debugTrace, 'api_retry_adjust', {
            attempt,
            nextAttempt: attempt + 1,
            field: adjustment.field,
            strategy: adjustment.strategy,
            from: adjustment.currentValue === null ? 'omit' : String(adjustment.currentValue || 'omit'),
            to: adjustment.nextValue === null ? 'omit' : String(adjustment.nextValue || 'omit'),
            errorParam: adjustment.errorParam || '',
            supportedValues: adjustment.supportedValues || ''
          });
          continue;
        }
      }

      throw error;
    }

    const content = extractTextFromResponsesApi(data);
    if (!content) {
      addTranslationDebugEvent(debugTrace, 'api_result_invalid', {
        status: typeof data?.status === 'string' ? data.status : '',
        incompleteReason: typeof data?.incomplete_details?.reason === 'string'
          ? data.incomplete_details.reason
          : '',
        finishReason: typeof data?.choices?.[0]?.finish_reason === 'string'
          ? data.choices[0].finish_reason
          : '',
        outputCount: Array.isArray(data?.output) ? data.output.length : 0
      });
      throw new Error(buildMissingTranslationReason(data));
    }

    addTranslationDebugEvent(debugTrace, 'api_result_ready', {
      translationLength: content.length
    });
    return content;
  }

  throw new Error('翻译请求失败，请稍后重试');
}

async function translateTextDirect(textInput, overrideOptions = {}) {
  const text = typeof textInput === 'string' ? textInput.trim() : '';
  const debugTrace = createTranslationDebugTrace(text.length);
  const buildDebugInfo = (state) => buildTranslationDebugInfo(debugTrace, state);
  addTranslationDebugEvent(debugTrace, 'request_received', {
    tabId: null,
    mode: 'direct',
    overrideSourceLang: typeof overrideOptions.sourceLang === 'string' ? overrideOptions.sourceLang : '',
    overrideTargetLang: typeof overrideOptions.targetLang === 'string' ? overrideOptions.targetLang : '',
    overrideModel: typeof overrideOptions.model === 'string' ? overrideOptions.model : '',
    overrideTranslationStyle: typeof overrideOptions.translationStyle === 'string'
      ? overrideOptions.translationStyle
      : ''
  });

  if (!text) {
    addTranslationDebugEvent(debugTrace, 'validation_failed_text_too_long', {
      textLength: 0,
      maxLength: TRANSLATION_MAX_CHARS
    });
    return {
      ok: false,
      error: '请输入要翻译的文本',
      debugInfo: buildDebugInfo('error')
    };
  }

  if (text.length > TRANSLATION_MAX_CHARS) {
    const requestedStyle = normalizeTranslationStyle(overrideOptions.translationStyle, 'literal');
    addTranslationDebugEvent(debugTrace, 'validation_failed_text_too_long', {
      textLength: text.length,
      maxLength: TRANSLATION_MAX_CHARS
    });
    return {
      ok: false,
      error: `文本过长（${text.length} 字符），请控制在 ${TRANSLATION_MAX_CHARS} 字符以内`,
      debugInfo: buildDebugInfo('error')
    };
  }

  addTranslationDebugEvent(debugTrace, 'settings_load_start');
  const settings = await getTranslateSettings();
  addTranslationDebugEvent(debugTrace, 'settings_load_done', {
    modelCount: Array.isArray(settings.llmModels) ? settings.llmModels.length : 0,
    temperatureSettingPresent: Number.isFinite(settings.llmTemperature),
    temperatureIgnored: true,
    gatewayEnabled: settings.llmGatewayEnabled === true,
    capabilityOverrideCount: Array.isArray(settings.modelCapabilityOverrideRules)
      ? settings.modelCapabilityOverrideRules.length
      : 0
  });

  const effectiveSourceLang = normalizeSourceLanguage(
    overrideOptions.sourceLang,
    settings.translateSourceLang
  );
  const effectiveTargetLang = normalizeTargetLanguage(
    overrideOptions.targetLang,
    settings.translateTargetLang
  );
  const effectiveModel = resolveModelSelection(
    overrideOptions.model,
    settings.llmModels,
    settings.llmModel
  );
  const effectiveTranslationStyle = normalizeTranslationStyle(
    overrideOptions.translationStyle,
    settings.translateStyle || 'literal'
  );
  const effectiveModelOptions = buildModelOptions(settings.llmModels, effectiveModel);
  const effectiveSettings = {
    ...settings,
    llmModel: effectiveModel,
    translateSourceLang: effectiveSourceLang,
    translateTargetLang: effectiveTargetLang,
    translationStyle: effectiveTranslationStyle
  };
  addTranslationDebugEvent(debugTrace, 'settings_resolved', {
    model: effectiveSettings.llmModel,
    sourceLang: effectiveSettings.translateSourceLang,
    targetLang: effectiveSettings.translateTargetLang,
    translationStyle: effectiveSettings.translationStyle,
    gatewayEnabled: effectiveSettings.llmGatewayEnabled === true
  });

  if (!effectiveSettings.llmModel) {
    addTranslationDebugEvent(debugTrace, 'validation_failed_missing_model');
    return {
      ok: false,
      error: '未配置 MODEL：请先到设置页填写 MODEL。',
      model: effectiveSettings.llmModel,
      modelOptions: effectiveModelOptions,
      translationStyle: effectiveSettings.translationStyle,
      sourceLang: effectiveSettings.translateSourceLang,
      targetLang: effectiveSettings.translateTargetLang,
      debugInfo: buildDebugInfo('error')
    };
  }

  if (effectiveSettings.llmGatewayEnabled) {
    if (!effectiveSettings.llmGatewayAccessToken) {
      addTranslationDebugEvent(debugTrace, 'validation_failed_missing_api_key', {
        gateway: 'enabled'
      });
      return {
        ok: false,
        error: '未配置网关访问令牌：请在设置页填写“网关访问令牌”。',
        model: effectiveSettings.llmModel,
        modelOptions: effectiveModelOptions,
        translationStyle: effectiveSettings.translationStyle,
        sourceLang: effectiveSettings.translateSourceLang,
        targetLang: effectiveSettings.translateTargetLang,
        debugInfo: buildDebugInfo('error')
      };
    }

    try {
      normalizeGatewayBaseUrl(effectiveSettings.llmGatewayBaseUrl);
      addTranslationDebugEvent(debugTrace, 'base_url_validated', {
        endpoint: '/v1/ext/*'
      });
    } catch (error) {
      const message = `网关地址配置错误：${formatTranslateError(error)}`;
      addTranslationDebugEvent(debugTrace, 'validation_failed_base_url', { message });
      return {
        ok: false,
        error: message,
        model: effectiveSettings.llmModel,
        modelOptions: effectiveModelOptions,
        translationStyle: effectiveSettings.translationStyle,
        sourceLang: effectiveSettings.translateSourceLang,
        targetLang: effectiveSettings.translateTargetLang,
        debugInfo: buildDebugInfo('error')
      };
    }
  } else {
    if (!effectiveSettings.llmApiKey) {
      addTranslationDebugEvent(debugTrace, 'validation_failed_missing_api_key');
      return {
        ok: false,
        error: '未配置 API_KEY：请先到设置页填写 BASE_URL / API_KEY / MODEL。',
        model: effectiveSettings.llmModel,
        modelOptions: effectiveModelOptions,
        translationStyle: effectiveSettings.translationStyle,
        sourceLang: effectiveSettings.translateSourceLang,
        targetLang: effectiveSettings.translateTargetLang,
        debugInfo: buildDebugInfo('error')
      };
    }

    try {
      normalizeBaseUrlToV1(effectiveSettings.llmBaseUrl);
      addTranslationDebugEvent(debugTrace, 'base_url_validated');
    } catch (error) {
      const message = `BASE_URL 配置错误：${formatTranslateError(error)}`;
      addTranslationDebugEvent(debugTrace, 'validation_failed_base_url', { message });
      return {
        ok: false,
        error: message,
        model: effectiveSettings.llmModel,
        modelOptions: effectiveModelOptions,
        translationStyle: effectiveSettings.translationStyle,
        sourceLang: effectiveSettings.translateSourceLang,
        targetLang: effectiveSettings.translateTargetLang,
        debugInfo: buildDebugInfo('error')
      };
    }
  }

  try {
    addTranslationDebugEvent(debugTrace, 'translate_call_start');
    const translation = effectiveSettings.llmGatewayEnabled
      ? await translateTextViaGatewayApi(text, effectiveSettings, debugTrace)
      : await translateTextViaOpenAICompatibleApi(text, effectiveSettings, debugTrace);
    addTranslationDebugEvent(debugTrace, 'translate_call_done', {
      translationLength: translation.length
    });
    return {
      ok: true,
      originalText: text,
      translation,
      model: effectiveSettings.llmModel,
      modelOptions: effectiveModelOptions,
      translationStyle: effectiveSettings.translationStyle,
      sourceLang: effectiveSettings.translateSourceLang,
      targetLang: effectiveSettings.translateTargetLang,
      debugInfo: buildDebugInfo('done')
    };
  } catch (error) {
    const message = formatTranslateError(error);
    addTranslationDebugEvent(debugTrace, 'translate_call_error', {
      status: Number(error?.status) || null,
      message
    });
    return {
      ok: false,
      error: message,
      model: effectiveSettings.llmModel,
      modelOptions: effectiveModelOptions,
      translationStyle: effectiveSettings.translationStyle,
      sourceLang: effectiveSettings.translateSourceLang,
      targetLang: effectiveSettings.translateTargetLang,
      debugInfo: buildDebugInfo('error')
    };
  }
}

async function handleTranslateSelection(selectionText, tab, overrideOptions = {}) {
  const tabId = tab?.id;
  const sourceUrl = tab?.url;
  const sourceTitle = tab?.title;

  const text = typeof selectionText === 'string' ? selectionText.trim() : '';
  if (!text) {
    return;
  }

  const canUseInPageDialog = await isTabDialogSupported(tabId);
  if (!canUseInPageDialog) {
    const workbenchState = await resolveTranslateWorkbenchState(overrideOptions);
    await openTranslateWorkbenchPage({
      state: 'editor',
      originalText: text,
      translation: '',
      sourceLang: workbenchState.sourceLang,
      targetLang: workbenchState.targetLang,
      model: workbenchState.model,
      modelOptions: workbenchState.modelOptions,
      translationStyle: workbenchState.translationStyle,
      sourceUrl,
      sourceTitle,
      canOpenOptions: false,
      autoTranslate: true
    });
    return;
  }

  const debugTrace = createTranslationDebugTrace(text.length);
  const buildDebugInfo = (state) => buildTranslationDebugInfo(debugTrace, state);
  addTranslationDebugEvent(debugTrace, 'request_received', {
    tabId: Number.isFinite(tabId) ? tabId : null,
    overrideSourceLang: typeof overrideOptions.sourceLang === 'string' ? overrideOptions.sourceLang : '',
    overrideTargetLang: typeof overrideOptions.targetLang === 'string' ? overrideOptions.targetLang : '',
    overrideModel: typeof overrideOptions.model === 'string' ? overrideOptions.model : '',
    overrideTranslationStyle: typeof overrideOptions.translationStyle === 'string'
      ? overrideOptions.translationStyle
      : ''
  });

  if (text.length > TRANSLATION_MAX_CHARS) {
    addTranslationDebugEvent(debugTrace, 'validation_failed_text_too_long', {
      textLength: text.length,
      maxLength: TRANSLATION_MAX_CHARS
    });
    const debugInfo = buildDebugInfo('error');
    await safeSendMessageToTab(tabId, {
      action: 'showTranslationDialog',
      state: 'error',
      originalText: text,
      sourceLang: overrideOptions.sourceLang,
      targetLang: overrideOptions.targetLang,
      translationStyle: requestedStyle,
      error: `选中文本过长（${text.length} 字符），请减少后再翻译。`,
      canOpenOptions: false,
      debugInfo
    });
    printTranslationDebugInfo(debugInfo);
    return;
  }

  addTranslationDebugEvent(debugTrace, 'settings_load_start');
  const settings = await getTranslateSettings();
  addTranslationDebugEvent(debugTrace, 'settings_load_done', {
    modelCount: Array.isArray(settings.llmModels) ? settings.llmModels.length : 0,
    temperatureSettingPresent: Number.isFinite(settings.llmTemperature),
    temperatureIgnored: true,
    gatewayEnabled: settings.llmGatewayEnabled === true,
    capabilityOverrideCount: Array.isArray(settings.modelCapabilityOverrideRules)
      ? settings.modelCapabilityOverrideRules.length
      : 0
  });
  const effectiveSourceLang = normalizeSourceLanguage(
    overrideOptions.sourceLang,
    settings.translateSourceLang
  );
  const effectiveTargetLang = normalizeTargetLanguage(
    overrideOptions.targetLang,
    settings.translateTargetLang
  );
  const effectiveModel = resolveModelSelection(
    overrideOptions.model,
    settings.llmModels,
    settings.llmModel
  );
  const effectiveTranslationStyle = normalizeTranslationStyle(
    overrideOptions.translationStyle,
    settings.translateStyle || 'literal'
  );
  const effectiveModelOptions = buildModelOptions(settings.llmModels, effectiveModel);

  const effectiveSettings = {
    ...settings,
    llmModel: effectiveModel,
    translateSourceLang: effectiveSourceLang,
    translateTargetLang: effectiveTargetLang,
    translationStyle: effectiveTranslationStyle
  };
  addTranslationDebugEvent(debugTrace, 'settings_resolved', {
    model: effectiveSettings.llmModel,
    sourceLang: effectiveSettings.translateSourceLang,
    targetLang: effectiveSettings.translateTargetLang,
    translationStyle: effectiveSettings.translationStyle,
    gatewayEnabled: effectiveSettings.llmGatewayEnabled === true
  });

  if (!effectiveSettings.llmModel) {
    addTranslationDebugEvent(debugTrace, 'validation_failed_missing_model');
    const debugInfo = buildDebugInfo('error');
    await safeSendMessageToTab(tabId, {
      action: 'showTranslationDialog',
      state: 'error',
      originalText: text,
      sourceLang: effectiveSettings.translateSourceLang,
      targetLang: effectiveSettings.translateTargetLang,
      model: effectiveSettings.llmModel,
      modelOptions: effectiveModelOptions,
      translationStyle: effectiveSettings.translationStyle,
      error: '未配置 MODEL：请先到设置页填写 MODEL。',
      canOpenOptions: true,
      debugInfo
    });
    printTranslationDebugInfo(debugInfo);
    return;
  }

  if (effectiveSettings.llmGatewayEnabled) {
    if (!effectiveSettings.llmGatewayAccessToken) {
      addTranslationDebugEvent(debugTrace, 'validation_failed_missing_api_key', {
        gateway: 'enabled'
      });
      const debugInfo = buildDebugInfo('error');
      await safeSendMessageToTab(tabId, {
        action: 'showTranslationDialog',
        state: 'error',
        originalText: text,
        sourceLang: effectiveSettings.translateSourceLang,
        targetLang: effectiveSettings.translateTargetLang,
        model: effectiveSettings.llmModel,
        modelOptions: effectiveModelOptions,
        translationStyle: effectiveSettings.translationStyle,
        error: '未配置网关访问令牌：请在设置页填写“网关访问令牌”。',
        canOpenOptions: true,
        debugInfo
      });
      printTranslationDebugInfo(debugInfo);
      return;
    }

    try {
      normalizeGatewayBaseUrl(effectiveSettings.llmGatewayBaseUrl);
      addTranslationDebugEvent(debugTrace, 'base_url_validated', {
        endpoint: '/v1/ext/*'
      });
    } catch (error) {
      addTranslationDebugEvent(debugTrace, 'validation_failed_base_url', {
        message: formatTranslateError(error)
      });
      const debugInfo = buildDebugInfo('error');
      await safeSendMessageToTab(tabId, {
        action: 'showTranslationDialog',
        state: 'error',
        originalText: text,
        sourceLang: effectiveSettings.translateSourceLang,
        targetLang: effectiveSettings.translateTargetLang,
        model: effectiveSettings.llmModel,
        modelOptions: effectiveModelOptions,
        translationStyle: effectiveSettings.translationStyle,
        error: `网关地址配置错误：${formatTranslateError(error)}`,
        canOpenOptions: true,
        debugInfo
      });
      printTranslationDebugInfo(debugInfo);
      return;
    }
  } else {
    if (!effectiveSettings.llmApiKey) {
      addTranslationDebugEvent(debugTrace, 'validation_failed_missing_api_key');
      const debugInfo = buildDebugInfo('error');
      await safeSendMessageToTab(tabId, {
        action: 'showTranslationDialog',
        state: 'error',
        originalText: text,
        sourceLang: effectiveSettings.translateSourceLang,
        targetLang: effectiveSettings.translateTargetLang,
        model: effectiveSettings.llmModel,
        modelOptions: effectiveModelOptions,
        translationStyle: effectiveSettings.translationStyle,
        error: '未配置 API_KEY：请先到设置页填写 BASE_URL / API_KEY / MODEL。',
        canOpenOptions: true,
        debugInfo
      });
      printTranslationDebugInfo(debugInfo);
      return;
    }

    try {
      // Validate base URL early to show a friendly error.
      normalizeBaseUrlToV1(effectiveSettings.llmBaseUrl);
      addTranslationDebugEvent(debugTrace, 'base_url_validated');
    } catch (error) {
      addTranslationDebugEvent(debugTrace, 'validation_failed_base_url', {
        message: formatTranslateError(error)
      });
      const debugInfo = buildDebugInfo('error');
      await safeSendMessageToTab(tabId, {
        action: 'showTranslationDialog',
        state: 'error',
        originalText: text,
        sourceLang: effectiveSettings.translateSourceLang,
        targetLang: effectiveSettings.translateTargetLang,
        model: effectiveSettings.llmModel,
        modelOptions: effectiveModelOptions,
        translationStyle: effectiveSettings.translationStyle,
        error: `BASE_URL 配置错误：${formatTranslateError(error)}`,
        canOpenOptions: true,
        debugInfo
      });
      printTranslationDebugInfo(debugInfo);
      return;
    }
  }

  addTranslationDebugEvent(debugTrace, 'dialog_loading_send_start');
  await safeSendMessageToTab(tabId, {
    action: 'showTranslationDialog',
    state: 'loading',
    originalText: text,
    sourceLang: effectiveSettings.translateSourceLang,
    targetLang: effectiveSettings.translateTargetLang,
    model: effectiveSettings.llmModel,
    modelOptions: effectiveModelOptions,
    translationStyle: effectiveSettings.translationStyle,
    debugInfo: buildDebugInfo('loading')
  });
  addTranslationDebugEvent(debugTrace, 'dialog_loading_sent');

  try {
    addTranslationDebugEvent(debugTrace, 'translate_call_start');
    const translation = effectiveSettings.llmGatewayEnabled
      ? await translateTextViaGatewayApi(text, effectiveSettings, debugTrace)
      : await translateTextViaOpenAICompatibleApi(text, effectiveSettings, debugTrace);
    addTranslationDebugEvent(debugTrace, 'translate_call_done', {
      translationLength: translation.length
    });
    addTranslationDebugEvent(debugTrace, 'dialog_done_send_start');
    const doneDebugInfo = buildDebugInfo('done');
    await safeSendMessageToTab(tabId, {
      action: 'showTranslationDialog',
      state: 'done',
      originalText: text,
      translation,
      sourceLang: effectiveSettings.translateSourceLang,
      targetLang: effectiveSettings.translateTargetLang,
      model: effectiveSettings.llmModel,
      modelOptions: effectiveModelOptions,
      translationStyle: effectiveSettings.translationStyle,
      debugInfo: doneDebugInfo,
      sourceUrl,
      sourceTitle
    });
    addTranslationDebugEvent(debugTrace, 'dialog_done_sent');
    printTranslationDebugInfo(buildDebugInfo('done'));
  } catch (error) {
    const message = formatTranslateError(error);
    const canOpenOptions = effectiveSettings.llmGatewayEnabled
      ? (/网关|令牌|token|鉴权/i.test(message) || error?.status === 401 || error?.status === 403)
      : (!effectiveSettings.llmApiKey || /API_KEY|鉴权|BASE_URL|MODEL/i.test(message) || error?.status === 401);
    addTranslationDebugEvent(debugTrace, 'translate_call_error', {
      status: Number(error?.status) || null,
      message
    });
    addTranslationDebugEvent(debugTrace, 'dialog_error_send_start');
    const errorDebugInfo = buildDebugInfo('error');
    await safeSendMessageToTab(tabId, {
      action: 'showTranslationDialog',
      state: 'error',
      originalText: text,
      sourceLang: effectiveSettings.translateSourceLang,
      targetLang: effectiveSettings.translateTargetLang,
      model: effectiveSettings.llmModel,
      modelOptions: effectiveModelOptions,
      translationStyle: effectiveSettings.translationStyle,
      error: message,
      canOpenOptions,
      debugInfo: errorDebugInfo
    });
    addTranslationDebugEvent(debugTrace, 'dialog_error_sent');
    printTranslationDebugInfo(buildDebugInfo('error'));
  }
}

// 监听内容脚本就绪消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // 所有异步操作都需要返回Promise
  const handleAsync = async () => {
    try {
      if (DATA_ACTIONS.has(request.action)) {
        await initializeDataService();
      }

      if (request.action === "contentScriptReady" && sender.tab) {
        contentScriptsReady[sender.tab.id] = true;
        console.log(`内容脚本已在标签页 ${sender.tab.id} 中加载`);
        return { success: true };
        
      } else if (request.action === "saveNote") {
        const result = await saveNote(request.data);
        return { success: true, result };
        
      } else if (request.action === "updateClipboardMonitor") {
        await updateClipboardMonitoring(request.enabled === true);
        return { success: true };
        
      } else if (request.action === "updateTheme") {
        // 处理主题更新 - 保持Chrome Storage存储
        return { success: true };

      } else if (request.action === 'translateSelectedText') {
        if (!sender.tab || typeof sender.tab.id !== 'number') {
          return { success: false, error: '当前标签页不可用，无法翻译' };
        }

        await handleTranslateSelection(request.text, sender.tab, {
          sourceLang: request.sourceLang,
          targetLang: request.targetLang,
          model: request.model,
          translationStyle: request.translationStyle
        });
        return { success: true };

      } else if (request.action === 'translateTextDirect') {
        const result = await translateTextDirect(request.text, {
          sourceLang: request.sourceLang,
          targetLang: request.targetLang,
          model: request.model,
          translationStyle: request.translationStyle
        });
        return { success: true, data: result };

      } else if (request.action === 'openTranslateWorkbench') {
        const openResult = await openTranslateWorkbenchForActiveTab();
        if (!openResult.ok) {
          return { success: false, error: openResult.error || '打开翻译窗口失败' };
        }
        return { success: true, data: openResult };

      } else if (request.action === 'consumeTranslateWorkbenchPayload') {
        const payload = await consumeWorkbenchPayload(request.id);
        return { success: true, data: payload };

      } else if (request.action === 'getTranslateWorkbenchDefaults') {
        const defaults = await resolveTranslateWorkbenchState({
          sourceLang: request.sourceLang,
          targetLang: request.targetLang,
          model: request.model,
          translationStyle: request.translationStyle
        });
        return { success: true, data: defaults };

      } else if (request.action === 'setTranslateStylePreference') {
        const style = await setTranslateStylePreference(request.translationStyle);
        return { success: true, data: { translationStyle: style } };

      } else if (request.action === "openOptionsPage") {
        chrome.runtime.openOptionsPage();
        return { success: true };
        
      } else if (request.action === "testImageDownload") {
        downloadImage(request.imageUrl, {url: "about:blank", title: "测试图片"});
        return { success: true };
        
      } else if (request.action === "manualCheckClipboard") {
        console.log("收到手动检查剪贴板请求");
        checkClipboard(true);
        return { success: true, message: "正在检查剪贴板" };

      } else if (request.action === "clipboardPermissionGranted") {
        if (request.content) {
          lastClipboardContent = request.content;
        }
        return { success: true };

      } else if (request.action === "clipboardCaptured") {
        if (!clipboardMonitorEnabled) {
          return { success: true, skipped: 'disabled' };
        }

        if (!sender.tab || typeof sender.tab.id !== 'number') {
          return { success: true, skipped: 'no-tab' };
        }

        const content = typeof request.content === 'string' ? request.content.trim() : '';
        if (!shouldCaptureClipboardContent(content)) {
          return { success: true, skipped: 'filtered' };
        }

        lastClipboardContent = content;
        const noteData = buildClipboardNoteData(content, sender.tab);
        await showClipboardSaveDialog(sender.tab.id, noteData);
        return { success: true, detected: true };
        
      } else if (request.action === "getNotes") {
        const notes = await dataService.getNotes();
        return { success: true, data: notes };
        
      } else if (request.action === "getFolders") {
        const folders = await dataService.getFolders();
        return { success: true, data: folders };
        
      } else if (request.action === "addFolder") {
        const folderId = await dataService.addFolder(request.data);
        return { success: true, folderId };

      } else if (request.action === "updateFolder") {
        await dataService.updateFolder(request.id, request.data || {});
        return { success: true };

      } else if (request.action === "deleteFolder") {
        const folderId = request.id;
        if (!folderId || folderId === 'default') {
          return { success: false, error: '默认文件夹不支持删除' };
        }
        const result = await dataService.deleteFolder(folderId, {
          moveNotesToDefault: request.moveNotesToDefault !== false
        });
        return { success: true, data: result };
        
      } else if (request.action === "deleteNote") {
        await dataService.deleteNote(request.id);
        return { success: true };
        
      } else if (request.action === "updateNote") {
        await dataService.updateNote(request.id, request.data);
        return { success: true };
        
      } else if (request.action === "searchNotes") {
        const results = await dataService.searchNotes(request.query);
        return { success: true, data: results };
        
      } else if (request.action === "getStats") {
        const stats = await dataService.getStats();
        return { success: true, data: stats };
        
      } else if (request.action === "exportData") {
        const exportData = await dataService.exportData();
        return { success: true, data: exportData };
        
      } else if (request.action === "importData") {
        const result = await dataService.importData(request.importData);
        return { success: true, data: result };
        
      } else if (request.action === "clearAllData") {
        await Promise.all([
          dataService.db.clear('notes'),
          dataService.db.clear('folders'),
          dataService.db.clear('settings')
        ]);
        return { success: true };
      }
      
      return { success: false, error: "Unknown action" };
      
    } catch (error) {
      console.error('Background script error:', error);
      return { success: false, error: error.message };
    }
  };

  // 对于异步操作，直接调用并处理Promise
  if (DATA_ACTIONS.has(request.action)) {
    
    handleAsync().then(result => {
      sendResponse(result);
    }).catch(error => {
      sendResponse({ success: false, error: error.message });
    });
    
    return true; // 异步响应
  } else {
    // 同步操作
    handleAsync().then(result => {
      sendResponse(result);
    });
    return true;
  }
});

// 初始化存储
chrome.runtime.onInstalled.addListener(async () => {
  try {
    // 初始化数据服务
    await initializeDataService();
    
    // 合并默认配置，避免覆盖用户已有设置
    await ensureDefaultSettings();
    
    // 重新创建右键菜单，避免重复菜单错误
    await ensureContextMenus();

    // 初始化剪贴板监听状态
    loadClipboardMonitorSetting();
    
    console.log('扩展初始化完成，使用IndexedDB存储');
    
  } catch (error) {
    console.error('扩展初始化失败:', error);
  }
});

// 处理右键菜单点击
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  try {
    if (info.menuItemId === 'translate-text') {
      let selectedText = typeof info.selectionText === 'string' ? info.selectionText.trim() : '';
      if (!selectedText && tab && typeof tab.id === 'number') {
        selectedText = await getSelectionTextFromTab(tab.id);
      }

      if (!selectedText) {
        const workbenchState = await resolveTranslateWorkbenchState();
        await openTranslateWorkbenchPage({
          state: 'error',
          originalText: '',
          translation: '',
          sourceLang: workbenchState.sourceLang,
          targetLang: workbenchState.targetLang,
          model: workbenchState.model,
          modelOptions: workbenchState.modelOptions,
          translationStyle: workbenchState.translationStyle,
          sourceUrl: tab?.url,
          sourceTitle: tab?.title,
          error: '未读取到选中文本，请复制文本后粘贴到翻译工具中继续。',
          canOpenOptions: false,
          autoTranslate: false
        });
        return;
      }

      await handleTranslateSelection(selectedText, tab);
      return;
    }

    await initializeDataService();

    if (info.menuItemId === "save-text" && info.selectionText) {
      const noteData = {
        type: "text",
        content: info.selectionText,
        sourceUrl: tab.url,
        sourceTitle: tab.title,
        timestamp: Date.now(),
        tags: [],
        folderId: null
      };
      
      // 通过content script显示保存对话框
      chrome.tabs.sendMessage(tab.id, {
        action: "showSaveDialog",
        data: noteData
      });
      
    } else if (info.menuItemId === "save-image" && info.srcUrl) {
      const noteData = {
        type: "image",
        content: info.srcUrl,
        sourceUrl: tab.url,
        sourceTitle: tab.title,
        timestamp: Date.now(),
        tags: [],
        folderId: null
      };
      
      // 下载图片并保存笔记
      downloadImage(info.srcUrl, tab);
      
      // 通过content script显示保存对话框
      chrome.tabs.sendMessage(tab.id, {
        action: "showSaveDialog",
        data: noteData
      });
    }
    
  } catch (error) {
    console.error('右键菜单处理失败:', error);
  }
});

// 加载剪贴板监听设置
function loadClipboardMonitorSetting() {
  chrome.storage.local.get(['clipboardMonitor'], function(result) {
    updateClipboardMonitoring(result.clipboardMonitor === true).catch((error) => {
      console.log('恢复剪贴板监听状态失败:', error.message);
    });
  });
}

function checkPermission(permissionName) {
  return new Promise((resolve) => {
    if (!chrome.permissions || typeof chrome.permissions.contains !== 'function') {
      resolve(true);
      return;
    }

    chrome.permissions.contains({ permissions: [permissionName] }, (granted) => {
      if (chrome.runtime.lastError) {
        resolve(false);
        return;
      }
      resolve(granted === true);
    });
  });
}

// 更新剪贴板监听状态
async function updateClipboardMonitoring(enabled) {
  const shouldEnable = enabled === true;
  if (shouldEnable) {
    const granted = await checkPermission('clipboardRead');
    if (!granted) {
      clipboardMonitorEnabled = false;
      chrome.alarms.clear(CLIPBOARD_ALARM_NAME);
      await storageSet({ clipboardMonitor: false });
      throw new Error('启用剪贴板监听需要先授予 clipboardRead 权限');
    }
  }

  clipboardMonitorEnabled = shouldEnable;

  if (shouldEnable) {
    chrome.alarms.create(CLIPBOARD_ALARM_NAME, { periodInMinutes: CLIPBOARD_ALARM_PERIOD_MINUTES });
    checkClipboard().catch((error) => {
      console.log('启用后首次检查剪贴板失败:', error.message);
    });
  } else {
    chrome.alarms.clear(CLIPBOARD_ALARM_NAME);
  }
}

function shouldCaptureClipboardContent(content) {
  if (!content) {
    return false;
  }

  if (content.length <= 5 || content.length > 50000) {
    return false;
  }

  if (content === lastClipboardContent) {
    return false;
  }

  if (isUrlOnly(content)) {
    return false;
  }

  return true;
}

function buildClipboardNoteData(content, tab) {
  return {
    type: 'text',
    content,
    sourceUrl: tab.url,
    sourceTitle: tab.title,
    timestamp: Date.now(),
    tags: ['剪贴板'],
    folderId: null
  };
}

async function showClipboardSaveDialog(tabId, noteData) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      action: 'showSaveDialog',
      data: noteData,
      source: 'clipboard'
    });
  } catch (error) {
    console.log('无法在当前页面显示保存对话框，可能是特殊页面');
  }
}

// 检查剪贴板内容（通过活动标签页）
async function checkClipboard(manualTrigger = false) {
  if (!clipboardMonitorEnabled && !manualTrigger) {
    return;
  }

  try {
    // 获取当前活动的标签页
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;

    const activeTab = tabs[0];
    
    // 向活动标签页发送消息以获取剪贴板内容
    const response = await chrome.tabs.sendMessage(activeTab.id, {
      action: "getClipboardContent"
    }).catch(() => null);

    if (!response || !response.content) return;

    const currentContent = String(response.content).trim();
    
    if (shouldCaptureClipboardContent(currentContent)) {
      lastClipboardContent = currentContent;

      const noteData = buildClipboardNoteData(currentContent, activeTab);
      await showClipboardSaveDialog(activeTab.id, noteData);
    }
    
  } catch (error) {
    console.log('剪贴板检查过程中出现错误:', error.message);
  }
}

// 检查是否仅为URL
function isUrlOnly(content) {
  const trimmed = content.trim();
  try {
    new URL(trimmed);
    return trimmed.length < 200; // 短URL可能不是有价值的内容
  } catch {
    return false;
  }
}

// 下载图片到本地
function downloadImage(imageUrl, tab) {
  // 从URL提取图片文件名
  const filename = getImageFilename(imageUrl);
  
  // 获取当前时间戳作为文件名一部分，避免重名
  const timestamp = Date.now();
  const savedFilename = `copykit_${timestamp}_${filename}`;
  
  // 使用Chrome下载API保存图片
  chrome.downloads.download({
    url: imageUrl,
    filename: `CopyKit/images/${savedFilename}`,
    saveAs: false
  }, (downloadId) => {
    if (chrome.runtime.lastError) {
      console.error("下载失败:", chrome.runtime.lastError);
      return;
    }
    
    // 监听下载完成事件
    chrome.downloads.onChanged.addListener(function downloadListener(delta) {
      if (delta.id !== downloadId || !delta.state) {
        return;
      }

      const state = delta.state.current;
      if (state === 'complete' || state === 'interrupted') {
        chrome.downloads.onChanged.removeListener(downloadListener);
      }

      if (state === "complete") {
        // 创建图片笔记并保存到IndexedDB
        const note = {
          type: "image",
          content: imageUrl,  // 原始URL，用于临时显示
          localPath: `CopyKit/images/${savedFilename}`, // 本地存储路径
          sourceUrl: tab.url,
          sourceTitle: tab.title,
          timestamp: Date.now(),
          tags: [],
          folderId: null,
          notes: `从 ${tab.title} 保存的图片`
        };
        
        // 异步保存笔记
        saveNote(note);
        
        console.log(`图片已下载: ${savedFilename}`);
      }
    });
  });
}

// 从URL提取合适的图片文件名
function getImageFilename(imageUrl) {
  try {
    const url = new URL(imageUrl);
    let pathname = url.pathname;
    
    // 获取路径中的最后一部分作为文件名
    let filename = pathname.split('/').pop();
    
    // 如果文件名为空或太短，使用时间戳
    if (!filename || filename.length < 3) {
      filename = `image_${Date.now()}`;
    }
    
    // 移除查询参数（如果存在）
    filename = filename.split('?')[0];
    
    // 检查是否有有效的扩展名，如果没有则添加.jpg
    const hasExtension = /\.(jpg|jpeg|png|gif|webp|svg|bmp)$/i.test(filename);
    if (!hasExtension) {
      filename += ".jpg";
    }
    
    // 如果文件名太长，则截断
    if (filename.length > 50) {
      const ext = filename.split('.').pop();
      filename = filename.substring(0, 46) + "..." + ext;
    }
    
    return filename;
  } catch (e) {
    // 如果解析失败，返回默认名称
    return `image_${Date.now()}.jpg`;
  }
}

// 保存笔记到IndexedDB
async function saveNote(note) {
  try {
    await initializeDataService();
    
    // 确保必要字段存在
    if (!note.id) {
      note.id = generateUUID();
    }
    
    // 保存到IndexedDB
    const noteId = await dataService.addNote(note);
    
    console.log('笔记已保存到IndexedDB:', noteId);
    return noteId;
    
  } catch (error) {
    console.error('保存笔记失败:', error);
    throw error;
  }
}

// 生成唯一ID
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// 在初始化完成后立即检查剪贴板监听设置
chrome.runtime.onStartup.addListener(() => {
  console.log('扩展启动，检查剪贴板监听设置...');
  ensureContextMenus().catch((error) => {
    console.error('启动时重建右键菜单失败:', error);
  });
  loadClipboardMonitorSetting();
});

// 基于闹钟周期检查剪贴板（MV3 service worker 可靠方式）
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === CLIPBOARD_ALARM_NAME) {
    checkClipboard().catch((error) => {
      console.log('闹钟触发检查剪贴板失败:', error.message);
    });
  }
});

// 也在后台脚本加载时检查剪贴板监听设置
ensureContextMenus().catch((error) => {
  console.error('加载时重建右键菜单失败:', error);
});
loadClipboardMonitorSetting();
