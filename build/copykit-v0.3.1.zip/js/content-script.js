// 内容脚本 - 处理网页中的交互 (基于IndexedDB + Dexie.js)

let clipboardMonitorEnabled = false;
let lastCapturedCopy = '';
const LAST_USED_FOLDER_KEY = 'lastUsedFolderId';
const QUICK_TRANSLATE_BUTTON_ID = 'copykit-quick-translate-btn';
const QUICK_TRANSLATE_MIN_CHARS = 2;
const QUICK_TRANSLATE_MAX_CHARS = 12000;
const TRANSLATE_OVERLAY_ID = 'copykit-translate-overlay';
const TRANSLATE_DIALOG_ID = 'copykit-translate-dialog';
const COPYKIT_STYLE_ID = 'copykit-inline-style';
const EXTENSION_CONTEXT_INVALIDATED_HINT = '扩展已更新，请刷新当前页面后重试。';
const IS_TRANSLATE_WORKBENCH_PAGE = location.protocol === 'chrome-extension:'
  && /\/translate-workbench\.html$/i.test(location.pathname || '');
let extensionContextInvalidated = false;
let extensionContextInvalidatedLogged = false;

function isExtensionContextInvalidatedError(error) {
  const message = error && typeof error.message === 'string' ? error.message : '';
  return /Extension context invalidated/i.test(message);
}

function markExtensionContextInvalidated(error) {
  if (!isExtensionContextInvalidatedError(error)) {
    return false;
  }

  extensionContextInvalidated = true;
  if (!extensionContextInvalidatedLogged) {
    extensionContextInvalidatedLogged = true;
    console.warn(EXTENSION_CONTEXT_INVALIDATED_HINT);
  }
  try {
    hideQuickTranslateButton();
  } catch (error) {
    // 忽略初始化早期阶段的 UI 清理异常
  }
  return true;
}

function canUseExtensionRuntime() {
  if (extensionContextInvalidated) {
    return false;
  }

  try {
    return typeof chrome !== 'undefined'
      && !!chrome.runtime
      && typeof chrome.runtime.sendMessage === 'function';
  } catch (error) {
    markExtensionContextInvalidated(error);
    return false;
  }
}

function safeRuntimeSendMessage(message, callback = null) {
  if (!canUseExtensionRuntime()) {
    return false;
  }

  try {
    if (typeof callback === 'function') {
      chrome.runtime.sendMessage(message, callback);
    } else {
      chrome.runtime.sendMessage(message);
    }
    return true;
  } catch (error) {
    markExtensionContextInvalidated(error);
    return false;
  }
}

function safeRuntimeGetURL(path) {
  if (!canUseExtensionRuntime()) {
    return '';
  }

  try {
    return chrome.runtime.getURL(path);
  } catch (error) {
    markExtensionContextInvalidated(error);
    return '';
  }
}

function buildExtensionContextInvalidatedError() {
  return new Error(EXTENSION_CONTEXT_INVALIDATED_HINT);
}
// 初始化时向背景脚本发送消息表示内容脚本已加载
if (!IS_TRANSLATE_WORKBENCH_PAGE) {
  safeRuntimeSendMessage({ action: "contentScriptReady" });
}
let translationDialogKeydownHandler = null;
let translationDialogPinned = false;
let translationDialogMinimized = false;
let translationDialogPosition = null;
let translationDialogDragSession = null;
let translationDialogResizeHandler = null;
let quickTranslateButton = null;
let quickTranslateSelectionText = '';
let quickTranslateSelectionChangeTimer = null;
let quickTranslateButtonBusy = false;
let activeTranslationTraceId = '';
const dismissedTranslationTraceIds = [];
const MAX_DISMISSED_TRANSLATION_TRACE_IDS = 32;
const ENABLE_TRANSLATION_DEBUG = false;
const FALLBACK_TRANSLATE_LANGUAGE_OPTIONS = [
  { value: 'auto', label: '自动检测' },
  { value: 'zh-CN', label: '中文(简体)' },
  { value: 'zh-TW', label: '中文(繁体)' },
  { value: 'en', label: 'English' },
  { value: 'ja', label: '日本語' },
  { value: 'ko', label: '한국어' },
  { value: 'fr', label: 'Français' },
  { value: 'de', label: 'Deutsch' },
  { value: 'es', label: 'Español' },
  { value: 'pt-BR', label: 'Português(BR)' },
  { value: 'ru', label: 'Русский' },
  { value: 'ar', label: 'العربية' },
  { value: 'hi', label: 'हिन्दी' }
];
const TRANSLATE_LANGUAGE_OPTIONS = Array.isArray(globalThis.COPYKIT_TRANSLATE_LANGUAGE_OPTIONS)
  && globalThis.COPYKIT_TRANSLATE_LANGUAGE_OPTIONS.length > 0
  ? globalThis.COPYKIT_TRANSLATE_LANGUAGE_OPTIONS
  : FALLBACK_TRANSLATE_LANGUAGE_OPTIONS;
const TRANSLATE_LANGUAGE_ALIASES = globalThis.COPYKIT_TRANSLATE_LANGUAGE_ALIASES
  && typeof globalThis.COPYKIT_TRANSLATE_LANGUAGE_ALIASES === 'object'
  ? globalThis.COPYKIT_TRANSLATE_LANGUAGE_ALIASES
  : {};
const TRANSLATE_LANGUAGE_VALUE_LOOKUP = new Map(
  TRANSLATE_LANGUAGE_OPTIONS
    .filter((item) => item && typeof item.value === 'string' && item.value.trim())
    .map((item) => [item.value.toLowerCase(), item.value])
);
const TRANSLATION_STAGE_LABELS = {
  request_received: '收到翻译请求',
  validation_failed_text_too_long: '文本长度校验失败',
  settings_load_start: '读取设置',
  settings_load_done: '设置读取完成',
  settings_resolved: '翻译参数确定',
  validation_failed_missing_api_key: 'API_KEY 缺失',
  validation_failed_missing_model: 'MODEL 缺失',
  base_url_validated: 'BASE_URL 校验通过',
  validation_failed_base_url: 'BASE_URL 校验失败',
  dialog_loading_send_start: '发送 loading 弹窗',
  dialog_loading_sent: 'loading 弹窗已送达',
  translate_call_start: '开始调用翻译 API',
  api_prepare: '准备 API 请求参数',
  api_attempt_start: 'API 尝试开始',
  api_attempt_success: 'API 尝试成功',
  api_attempt_error: 'API 尝试失败',
  api_retry_adjust: '参数自适应并重试',
  api_result_empty: 'API 返回为空',
  api_result_invalid: 'API 返回内容无效',
  api_result_ready: 'API 返回译文',
  translate_call_done: '翻译完成',
  translate_call_error: '翻译失败',
  dialog_done_send_start: '发送完成弹窗',
  dialog_done_sent: '完成弹窗已送达',
  dialog_error_send_start: '发送错误弹窗',
  dialog_error_sent: '错误弹窗已送达'
};

if (!IS_TRANSLATE_WORKBENCH_PAGE) {
  initializeClipboardMonitorState();
  initializeQuickTranslateTrigger();
  document.addEventListener('copy', handleClipboardCopyEvent, true);
  document.addEventListener('cut', handleClipboardCopyEvent, true);

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local' || !changes.clipboardMonitor) {
      return;
    }

    clipboardMonitorEnabled = changes.clipboardMonitor.newValue === true;
  });
}

// 监听来自后台脚本的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "showSaveDialog") {
    hideQuickTranslateButton();

    // 如果是从剪贴板监听触发，标题添加提示
    if (request.source === "clipboard") {
      showSaveDialog(request.data, "剪贴板内容检测到");
    } else {
      showSaveDialog(request.data);
    }
    sendResponse({ success: true });
    return true;
    
  } else if (request.action === "showTranslationDialog") {
    hideQuickTranslateButton();
    showTranslationDialog(request);
    sendResponse({ success: true });
    return true;

  } else if (request.action === "getClipboardContent") {
    // 处理获取剪贴板内容的请求
    getClipboardContent()
      .then(content => {
        sendResponse({ success: true, content });
      })
      .catch(error => {
        console.error('获取剪贴板内容失败:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // 异步响应
  } else if (request.action === 'getSelectionTextForTranslate') {
    sendResponse({
      success: true,
      text: getCurrentSelectionTextForTranslate()
    });
    return true;
  } else if (request.action === 'copykitPing') {
    sendResponse({ success: true });
    return true;
  }
  
  return true;
});

function initializeClipboardMonitorState() {
  chrome.storage.local.get(['clipboardMonitor'], (result) => {
    clipboardMonitorEnabled = result.clipboardMonitor === true;
  });
}

function handleClipboardCopyEvent(event) {
  if (!clipboardMonitorEnabled) {
    return;
  }

  const selectedText = window.getSelection ? window.getSelection().toString() : '';
  const inputSelectedText = getSelectedTextFromActiveInput();
  const clipboardText = event?.clipboardData?.getData('text/plain') || '';
  const copiedText = (clipboardText || selectedText || inputSelectedText || '').trim();

  if (!copiedText || copiedText === lastCapturedCopy) {
    return;
  }

  lastCapturedCopy = copiedText;
  const sent = safeRuntimeSendMessage({ action: 'clipboardCaptured', content: copiedText }, () => {
    if (chrome.runtime.lastError) {
      const message = chrome.runtime.lastError.message || '';
      if (/Extension context invalidated/i.test(message)) {
        extensionContextInvalidated = true;
        return;
      }
      console.log('上报复制内容失败:', message);
    }
  });

  if (!sent) {
    extensionContextInvalidated = true;
  }
}

function getSelectedTextFromActiveInput() {
  const activeElement = document.activeElement;
  if (!activeElement) {
    return '';
  }

  const tagName = activeElement.tagName;
  const isTextInput = tagName === 'TEXTAREA' || (tagName === 'INPUT' && typeof activeElement.value === 'string');
  if (!isTextInput) {
    return '';
  }

  const start = activeElement.selectionStart;
  const end = activeElement.selectionEnd;
  if (typeof start !== 'number' || typeof end !== 'number' || start === end) {
    return '';
  }

  return activeElement.value.substring(start, end);
}

function getCurrentSelectionTextForTranslate() {
  const inputText = getSelectedTextFromActiveInput().trim();
  if (inputText) {
    return inputText;
  }

  const selectionText = window.getSelection ? window.getSelection().toString().trim() : '';
  return selectionText;
}

async function getLastUsedFolderId() {
  return new Promise((resolve) => {
    chrome.storage.local.get([LAST_USED_FOLDER_KEY], (result) => {
      const folderId = result[LAST_USED_FOLDER_KEY];
      if (typeof folderId === 'string' && folderId.trim()) {
        resolve(folderId);
      } else {
        resolve('default');
      }
    });
  });
}

async function setLastUsedFolderId(folderId) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [LAST_USED_FOLDER_KEY]: folderId }, resolve);
  });
}

// 获取剪贴板内容
async function getClipboardContent() {
  try {
    if (!navigator.clipboard) {
      throw new Error('剪贴板API不可用');
    }
    
    const text = await navigator.clipboard.readText();
    return text;
    
  } catch (error) {
    console.error('读取剪贴板失败:', error);
    throw new Error('无法访问剪贴板，请检查权限设置');
  }
}

// 发送消息到背景脚本
async function sendMessageToBackground(action, data = {}) {
  return new Promise((resolve, reject) => {
    if (!canUseExtensionRuntime()) {
      reject(buildExtensionContextInvalidatedError());
      return;
    }

    try {
      chrome.runtime.sendMessage({ action, ...data }, (response) => {
        if (chrome.runtime.lastError) {
          const message = chrome.runtime.lastError.message || '';
          if (/Extension context invalidated/i.test(message)) {
            extensionContextInvalidated = true;
            reject(buildExtensionContextInvalidatedError());
            return;
          }
          reject(new Error(message));
        } else if (response && response.success) {
          if (Object.prototype.hasOwnProperty.call(response, 'data')) {
            resolve(response.data);
          } else if (Object.prototype.hasOwnProperty.call(response, 'result')) {
            resolve(response.result);
          } else if (Object.prototype.hasOwnProperty.call(response, 'folderId')) {
            resolve(response.folderId);
          } else if (Object.prototype.hasOwnProperty.call(response, 'noteId')) {
            resolve(response.noteId);
          } else if (Object.prototype.hasOwnProperty.call(response, 'message')) {
            resolve(response.message);
          } else {
            resolve(null);
          }
        } else {
          reject(new Error(response?.error || '操作失败'));
        }
      });
    } catch (error) {
      if (markExtensionContextInvalidated(error)) {
        reject(buildExtensionContextInvalidatedError());
      } else {
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    }
  });
}

function initializeQuickTranslateTrigger() {
  document.addEventListener('selectionchange', handleQuickTranslateSelectionChange, true);
  document.addEventListener('mousedown', handleQuickTranslateDocumentMouseDown, true);
  document.addEventListener('mouseup', handleQuickTranslateDocumentMouseUp, true);
  document.addEventListener('keydown', handleQuickTranslateDocumentKeydown, true);
  document.addEventListener('keyup', handleQuickTranslateDocumentKeyup, true);
  window.addEventListener('resize', hideQuickTranslateButton, true);
  window.addEventListener('scroll', handleQuickTranslateViewportChanged, true);
}

function handleQuickTranslateSelectionChange() {
  scheduleQuickTranslateSelectionRefresh(80);
}

function handleQuickTranslateDocumentMouseDown(event) {
  if (event.target instanceof Element && isInsideCopykitUi(event.target)) {
    return;
  }
  hideQuickTranslateButton();
}

function handleQuickTranslateDocumentMouseUp(event) {
  if (event.target instanceof Element && isInsideCopykitUi(event.target)) {
    return;
  }

  scheduleQuickTranslateSelectionRefresh(10);
}

function handleQuickTranslateDocumentKeydown(event) {
  if (event.key === 'Escape') {
    hideQuickTranslateButton();
  }
}

function handleQuickTranslateDocumentKeyup(event) {
  if (event.key === 'Escape') {
    return;
  }
  scheduleQuickTranslateSelectionRefresh(0);
}

function handleQuickTranslateViewportChanged() {
  if (quickTranslateButton && quickTranslateButton.style.display !== 'none') {
    hideQuickTranslateButton();
  }
}

function scheduleQuickTranslateSelectionRefresh(delayMs) {
  if (quickTranslateSelectionChangeTimer) {
    clearTimeout(quickTranslateSelectionChangeTimer);
  }

  quickTranslateSelectionChangeTimer = setTimeout(() => {
    quickTranslateSelectionChangeTimer = null;
    updateQuickTranslateButtonFromSelection();
  }, delayMs);
}

function isInsideCopykitUi(element) {
  if (!(element instanceof Element)) {
    return false;
  }

  return Boolean(element.closest(
    `#${QUICK_TRANSLATE_BUTTON_ID}, #copykit-dialog, #copykit-overlay, #${TRANSLATE_DIALOG_ID}, #${TRANSLATE_OVERLAY_ID}`
  ));
}

function updateQuickTranslateButtonFromSelection() {
  if (quickTranslateButtonBusy) {
    return;
  }

  if (document.getElementById('copykit-dialog') || document.getElementById(TRANSLATE_DIALOG_ID)) {
    hideQuickTranslateButton();
    return;
  }

  const selectionData = getCurrentTranslateSelectionData();
  if (!selectionData) {
    hideQuickTranslateButton();
    return;
  }

  quickTranslateSelectionText = selectionData.text;
  showQuickTranslateButtonAt(selectionData.rect);
}

function getCurrentTranslateSelectionData() {
  const inputSelection = getSelectedTextFromActiveInput().trim();
  const activeElement = document.activeElement;
  if (inputSelection && activeElement instanceof Element && !isInsideCopykitUi(activeElement)) {
    if (inputSelection.length < QUICK_TRANSLATE_MIN_CHARS || inputSelection.length > QUICK_TRANSLATE_MAX_CHARS) {
      return null;
    }
    return {
      text: inputSelection,
      rect: activeElement.getBoundingClientRect()
    };
  }

  const selection = window.getSelection ? window.getSelection() : null;
  if (!selection || selection.rangeCount === 0 || selection.isCollapsed) {
    return null;
  }

  const text = selection.toString().trim();
  if (!text || text.length < QUICK_TRANSLATE_MIN_CHARS || text.length > QUICK_TRANSLATE_MAX_CHARS) {
    return null;
  }

  const anchorElement = resolveNodeElement(selection.anchorNode);
  const focusElement = resolveNodeElement(selection.focusNode);
  if (isInsideCopykitUi(anchorElement) || isInsideCopykitUi(focusElement)) {
    return null;
  }

  const range = selection.getRangeAt(0);
  const rect = getSelectionReferenceRect(range);
  if (!rect) {
    return null;
  }

  return { text, rect };
}

function resolveNodeElement(node) {
  if (!node) {
    return null;
  }

  if (node.nodeType === Node.ELEMENT_NODE) {
    return node;
  }

  return node.parentElement || null;
}

function getSelectionReferenceRect(range) {
  const rects = Array.from(range.getClientRects()).filter((rect) => rect && (rect.width > 0 || rect.height > 0));
  if (rects.length > 0) {
    return rects[rects.length - 1];
  }

  const rect = range.getBoundingClientRect();
  if (!rect || (rect.width <= 0 && rect.height <= 0)) {
    return null;
  }

  return rect;
}

function ensureQuickTranslateButton() {
  if (quickTranslateButton && quickTranslateButton.isConnected) {
    return quickTranslateButton;
  }

  // 防止重复注入导致多个同 ID 按钮并存（例如页面未刷新时扩展重载）
  const existingButtons = Array.from(document.querySelectorAll(`#${QUICK_TRANSLATE_BUTTON_ID}`));
  if (existingButtons.length > 0) {
    existingButtons.forEach((element) => element.remove());
  }

  const button = document.createElement('button');
  button.id = QUICK_TRANSLATE_BUTTON_ID;
  button.type = 'button';
  button.title = '翻译选中文本';
  button.setAttribute('aria-label', '翻译选中文本');
  button.style.cssText = `
    position: fixed;
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 2147483647;
    width: 20px;
    height: 20px;
    padding: 0;
    border-radius: 0;
    border: none;
    background: transparent;
    color: #1565c0;
    font-size: 12px;
    font-weight: 600;
    line-height: 1;
    cursor: pointer;
    box-shadow: none;
    user-select: none;
    pointer-events: auto;
  `;

  const icon = document.createElement('img');
  const iconUrl = safeRuntimeGetURL('icons/icon16.png');
  if (iconUrl) {
    icon.src = iconUrl;
  }
  icon.alt = '';
  icon.setAttribute('data-role', 'icon');
  icon.style.cssText = `
    display: block;
    width: 16px;
    height: 16px;
    flex: 0 0 auto;
  `;

  const fallbackLabel = document.createElement('span');
  fallbackLabel.setAttribute('data-role', 'fallback-label');
  fallbackLabel.textContent = '翻译';
  fallbackLabel.style.cssText = `
    display: none;
    font-size: 12px;
    font-weight: 600;
    line-height: 1;
    white-space: nowrap;
    padding: 0 10px;
  `;

  const applyIconOnlyVisual = () => {
    button.style.width = '20px';
    button.style.height = '20px';
    button.style.padding = '0';
    button.style.border = 'none';
    button.style.borderRadius = '0';
    button.style.background = 'transparent';
    button.style.boxShadow = 'none';
  };

  const applyFallbackVisual = () => {
    button.style.width = 'auto';
    button.style.height = '28px';
    button.style.padding = '0 8px';
    button.style.border = '1px solid rgba(33, 150, 243, 0.25)';
    button.style.borderRadius = '8px';
    button.style.background = 'rgba(255, 255, 255, 0.96)';
    button.style.boxShadow = '0 6px 14px rgba(0, 0, 0, 0.12)';
  };

  if (!iconUrl) {
    icon.style.display = 'none';
    fallbackLabel.style.display = 'inline-block';
    applyFallbackVisual();
  }

  icon.addEventListener('error', () => {
    icon.style.display = 'none';
    fallbackLabel.style.display = 'inline-block';
    applyFallbackVisual();
  });

  icon.addEventListener('load', () => {
    icon.style.display = 'block';
    fallbackLabel.style.display = 'none';
    applyIconOnlyVisual();
  });

  button.appendChild(icon);
  button.appendChild(fallbackLabel);

  button.addEventListener('mousedown', (event) => {
    event.preventDefault();
    event.stopPropagation();
  });
  button.addEventListener('click', handleQuickTranslateButtonClick);

  (document.body || document.documentElement).appendChild(button);
  quickTranslateButton = button;
  return button;
}

function showQuickTranslateButtonAt(anchorRect) {
  const button = ensureQuickTranslateButton();
  button.style.visibility = 'hidden';
  button.style.display = 'inline-flex';

  positionQuickTranslateButton(button, anchorRect);
  updateQuickTranslateButtonLoadingState(false);
  button.style.visibility = 'visible';
}

function hideQuickTranslateButton() {
  if (!quickTranslateButton) {
    return;
  }

  const fallbackLabel = quickTranslateButton.querySelector('[data-role="fallback-label"]');
  if (fallbackLabel) {
    fallbackLabel.textContent = '翻译';
  }
  quickTranslateButton.title = '翻译选中文本';
  quickTranslateButton.style.display = 'none';
  quickTranslateButton.style.visibility = 'hidden';
  quickTranslateSelectionText = '';
  quickTranslateButtonBusy = false;
}

function updateQuickTranslateButtonLoadingState(isLoading) {
  if (!quickTranslateButton) {
    return;
  }

  const fallbackLabel = quickTranslateButton.querySelector('[data-role="fallback-label"]');
  if (fallbackLabel && fallbackLabel.style.display !== 'none') {
    fallbackLabel.textContent = isLoading ? '翻译中...' : '翻译';
  }

  quickTranslateButton.title = isLoading ? '翻译中...' : '翻译选中文本';
  quickTranslateButton.style.opacity = isLoading ? '0.72' : '1';
  quickTranslateButton.style.cursor = isLoading ? 'wait' : 'pointer';
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function positionQuickTranslateButton(button, anchorRect) {
  const margin = 8;
  const gap = 10;
  const width = button.offsetWidth || 76;
  const height = button.offsetHeight || 32;
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;

  const rawCandidates = [
    { x: anchorRect.right + gap, y: anchorRect.bottom + gap },
    { x: anchorRect.right + gap, y: anchorRect.top - height - gap },
    { x: anchorRect.left - width - gap, y: anchorRect.bottom + gap },
    { x: anchorRect.left - width - gap, y: anchorRect.top - height - gap },
    { x: anchorRect.left + ((anchorRect.width - width) / 2), y: anchorRect.bottom + gap },
    { x: viewportWidth - width - 16, y: viewportHeight - height - 16 }
  ];

  const candidates = rawCandidates.map((candidate) => ({
    x: clamp(candidate.x, margin, Math.max(margin, viewportWidth - width - margin)),
    y: clamp(candidate.y, margin, Math.max(margin, viewportHeight - height - margin))
  }));

  let selected = candidates[candidates.length - 1];
  for (const candidate of candidates) {
    if (!hasFloatingConflictAt(candidate.x, candidate.y, width, height)) {
      selected = candidate;
      break;
    }
  }

  button.style.left = `${selected.x}px`;
  button.style.top = `${selected.y}px`;
}

function hasFloatingConflictAt(x, y, width, height) {
  const points = [
    [x + width / 2, y + height / 2],
    [x + 4, y + 4],
    [x + width - 4, y + 4],
    [x + 4, y + height - 4],
    [x + width - 4, y + height - 4]
  ];

  return points.some((point) => {
    const px = Math.round(point[0]);
    const py = Math.round(point[1]);
    if (px < 0 || py < 0 || px >= window.innerWidth || py >= window.innerHeight) {
      return false;
    }

    const target = document.elementFromPoint(px, py);
    if (!target || !(target instanceof Element)) {
      return false;
    }

    if (isInsideCopykitUi(target) || target.id === QUICK_TRANSLATE_BUTTON_ID) {
      return false;
    }

    return isLikelyFloatingActionElement(target);
  });
}

function isLikelyFloatingActionElement(element) {
  const actionableElement = element.closest('button, a, [role="button"], input, textarea, select, [tabindex]');
  if (!actionableElement || isInsideCopykitUi(actionableElement)) {
    return false;
  }

  const style = window.getComputedStyle(actionableElement);
  const zIndex = Number.parseInt(style.zIndex, 10);
  const hasHighZIndex = !Number.isNaN(zIndex) && zIndex >= 1000;
  const isFloatingPosition = style.position === 'fixed' || style.position === 'sticky';
  return hasHighZIndex || isFloatingPosition;
}

async function handleQuickTranslateButtonClick(event) {
  event.preventDefault();
  event.stopPropagation();

  if (quickTranslateButtonBusy) {
    return;
  }

  const text = quickTranslateSelectionText.trim();
  if (!text) {
    hideQuickTranslateButton();
    return;
  }

  quickTranslateButtonBusy = true;
  updateQuickTranslateButtonLoadingState(true);

  try {
    await sendMessageToBackground('translateSelectedText', { text });
  } catch (error) {
    console.error('启动快捷翻译失败:', error);
    alert(`启动翻译失败: ${error.message}`);
  } finally {
    hideQuickTranslateButton();
  }
}

// 显示保存对话框，增加自定义标题选项
async function showSaveDialog(noteData, customTitle) {
  const lastUsedFolderId = await getLastUsedFolderId();

  // 如果已经有对话框，先关闭
  const existingDialog = document.getElementById('copykit-dialog');
  if (existingDialog) {
    existingDialog.remove();
  }

  // 创建遮罩层
  const overlay = document.createElement('div');
  overlay.id = 'copykit-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 2147483646;
  `;
  document.body.appendChild(overlay);

  // 创建对话框元素
  const dialog = document.createElement('div');
  dialog.id = 'copykit-dialog';
  dialog.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    padding: 20px;
    z-index: 2147483647;
    width: 360px;
    max-width: 90vw;
    max-height: 80vh;
    overflow-y: auto;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  `;
  
  // 标题栏
  const titleBar = document.createElement('div');
  titleBar.style.cssText = `
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
  `;
  
  const title = document.createElement('h3');
  title.textContent = customTitle || (noteData.type === 'text' ? '保存文本笔记' : '保存图片笔记');
  title.style.cssText = 'margin: 0; color: #333; font-size: 16px; font-weight: 600;';
  
  const closeBtn = document.createElement('button');
  closeBtn.textContent = '✕';
  closeBtn.style.cssText = `
    background: none;
    border: none;
    font-size: 18px;
    cursor: pointer;
    color: #999;
    padding: 0;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
  `;
  closeBtn.addEventListener('click', closeDialog);
  
  titleBar.appendChild(title);
  titleBar.appendChild(closeBtn);
  dialog.appendChild(titleBar);
  
  // 内容编辑区域
  const contentContainer = document.createElement('div');
  contentContainer.style.cssText = 'margin-bottom: 16px;';
  
  if (noteData.type === 'text') {
    // 文本内容使用可编辑的textarea
    const contentTextarea = document.createElement('textarea');
    contentTextarea.id = 'content-textarea';
    contentTextarea.value = noteData.content;
    contentTextarea.style.cssText = `
      width: 100%;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      padding: 12px;
      min-height: 120px;
      max-height: 200px;
      overflow-y: auto;
      word-break: break-word;
      font-size: 14px;
      font-family: inherit;
      resize: vertical;
      background: white;
      box-sizing: border-box;
    `;
    contentContainer.appendChild(contentTextarea);
  } else {
    // 图片内容仍使用预览方式
    const preview = document.createElement('div');
    preview.style.cssText = `
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 0;
      max-height: 120px;
      overflow-y: auto;
      word-break: break-word;
      font-size: 14px;
      background: #f9f9f9;
    `;
    
    const img = document.createElement('img');
    img.src = noteData.content;
    img.style.cssText = 'max-width: 100%; max-height: 100px; display: block; border-radius: 4px;';
    img.onerror = () => {
      preview.innerHTML = '<div style="color: #999; text-align: center; padding: 20px;">图片加载失败</div>';
    };
    preview.appendChild(img);
    contentContainer.appendChild(preview);
  }
  dialog.appendChild(contentContainer);

  try {
    // 获取文件夹列表
    const folders = await sendMessageToBackground('getFolders');
    
    // 文件夹选择
    const folderContainer = document.createElement('div');
    folderContainer.style.marginBottom = '16px';
    
    const folderLabel = document.createElement('label');
    folderLabel.textContent = '选择文件夹:';
    folderLabel.style.cssText = 'display: block; margin-bottom: 6px; font-size: 13px; font-weight: 500; color: #555;';
    
    const folderSelect = document.createElement('select');
    folderSelect.id = 'folder-select';
    folderSelect.style.cssText = `
      width: 100%;
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
      background: white;
    `;
    
    // 添加默认选项
    const defaultOption = document.createElement('option');
    defaultOption.value = 'default';
    defaultOption.textContent = '默认文件夹';
    folderSelect.appendChild(defaultOption);
    
    // 添加现有文件夹
    folders.forEach(folder => {
      const option = document.createElement('option');
      option.value = folder.id;
      option.textContent = folder.name;
      folderSelect.appendChild(option);
    });
    
    // 添加创建新文件夹选项
    const newFolderOption = document.createElement('option');
    newFolderOption.value = 'new';
    newFolderOption.textContent = '+ 创建新文件夹';
    folderSelect.appendChild(newFolderOption);

    // 默认优先使用传入的 folderId，其次回退到上次使用的文件夹
    const preferredFolderId = noteData.folderId ? String(noteData.folderId) : lastUsedFolderId;
    const hasPreferredFolder = preferredFolderId !== 'default' && folders.some(folder => folder.id === preferredFolderId);
    folderSelect.value = hasPreferredFolder ? preferredFolderId : 'default';
    
    folderContainer.appendChild(folderLabel);
    folderContainer.appendChild(folderSelect);
    dialog.appendChild(folderContainer);
    
    // 新文件夹名称输入（初始隐藏）
    const newFolderContainer = document.createElement('div');
    newFolderContainer.id = 'new-folder-container';
    newFolderContainer.style.cssText = 'display: none; margin-bottom: 16px;';
    
    const newFolderLabel = document.createElement('label');
    newFolderLabel.textContent = '新文件夹名称:';
    newFolderLabel.style.cssText = 'display: block; margin-bottom: 6px; font-size: 13px; font-weight: 500; color: #555;';
    
    const newFolderInput = document.createElement('input');
    newFolderInput.type = 'text';
    newFolderInput.placeholder = '请输入文件夹名称';
    newFolderInput.style.cssText = `
      width: 100%;
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
      box-sizing: border-box;
    `;
    
    newFolderContainer.appendChild(newFolderLabel);
    newFolderContainer.appendChild(newFolderInput);
    dialog.appendChild(newFolderContainer);
    
    // 文件夹选择变化事件
    folderSelect.addEventListener('change', function() {
      if (this.value === 'new') {
        newFolderContainer.style.display = 'block';
        newFolderInput.focus();
      } else {
        newFolderContainer.style.display = 'none';
      }
    });
    
  } catch (error) {
    console.error('获取文件夹列表失败:', error);
    // 如果获取文件夹失败，使用简单的默认选项
    const folderContainer = document.createElement('div');
    folderContainer.style.marginBottom = '16px';
    
    const folderSelect = document.createElement('select');
    folderSelect.id = 'folder-select';
    folderSelect.style.cssText = `
      width: 100%;
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
    `;
    
    const defaultOption = document.createElement('option');
    defaultOption.value = 'default';
    defaultOption.textContent = '默认文件夹';
    folderSelect.appendChild(defaultOption);
    
    folderContainer.appendChild(folderSelect);
    dialog.appendChild(folderContainer);
  }
  
  // 标签输入
  const tagsContainer = document.createElement('div');
  tagsContainer.style.marginBottom = '16px';
  
  const tagsLabel = document.createElement('label');
  tagsLabel.textContent = '标签 (用逗号分隔):';
  tagsLabel.style.cssText = 'display: block; margin-bottom: 6px; font-size: 13px; font-weight: 500; color: #555;';
  
  const tagsInput = document.createElement('input');
  tagsInput.type = 'text';
  tagsInput.placeholder = '例如: 工作, 重要, 学习';
  tagsInput.value = noteData.tags ? noteData.tags.join(', ') : '';
  tagsInput.style.cssText = `
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    box-sizing: border-box;
  `;
  
  tagsContainer.appendChild(tagsLabel);
  tagsContainer.appendChild(tagsInput);
  dialog.appendChild(tagsContainer);
  
  // 笔记备注
  const notesContainer = document.createElement('div');
  notesContainer.style.marginBottom = '20px';
  
  const notesLabel = document.createElement('label');
  notesLabel.textContent = '备注:';
  notesLabel.style.cssText = 'display: block; margin-bottom: 6px; font-size: 13px; font-weight: 500; color: #555;';
  
  const notesTextarea = document.createElement('textarea');
  notesTextarea.placeholder = '添加备注...';
  notesTextarea.style.cssText = `
    width: 100%;
    height: 60px;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    resize: vertical;
    font-family: inherit;
    box-sizing: border-box;
  `;
  
  notesContainer.appendChild(notesLabel);
  notesContainer.appendChild(notesTextarea);
  dialog.appendChild(notesContainer);
  
  // 按钮区域
  const buttonContainer = document.createElement('div');
  buttonContainer.style.cssText = 'display: flex; gap: 12px; justify-content: flex-end;';
  
  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = '取消';
  cancelBtn.style.cssText = `
    padding: 10px 20px;
    border: 1px solid #ddd;
    border-radius: 6px;
    background: white;
    color: #666;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
  `;
  cancelBtn.addEventListener('click', closeDialog);
  
  const saveBtn = document.createElement('button');
  saveBtn.textContent = '保存';
  saveBtn.style.cssText = `
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    background: #2196f3;
    color: white;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
  `;
  
  // 保存按钮点击事件
  saveBtn.addEventListener('click', async function() {
    try {
      saveBtn.disabled = true;
      saveBtn.textContent = '保存中...';
      saveBtn.style.background = '#ccc';
      
      const folderSelect = document.getElementById('folder-select');
      const newFolderInput = document.querySelector('#new-folder-container input');
      
      let folderId = folderSelect.value;
      
      // 如果选择了新建文件夹
      if (folderId === 'new') {
        const newFolderName = newFolderInput.value.trim();
        if (!newFolderName) {
          alert('请输入文件夹名称');
          saveBtn.disabled = false;
          saveBtn.textContent = '保存';
          saveBtn.style.background = '#2196f3';
          return;
        }
        
        // 创建新文件夹
        const newFolderData = {
          name: newFolderName,
          parentId: null,
          path: `/${newFolderName}`
        };
        
        folderId = await sendMessageToBackground('addFolder', { data: newFolderData });
      }
      
      // 处理标签
      const tagsValue = tagsInput.value.trim();
      const tags = tagsValue ? tagsValue.split(',').map(tag => tag.trim()).filter(tag => tag) : [];
      
      // 获取编辑后的内容
      let editedContent = noteData.content;
      if (noteData.type === 'text') {
        const contentTextarea = document.getElementById('content-textarea');
        if (contentTextarea) {
          editedContent = contentTextarea.value;
        }
      }
      
      // 构建最终的笔记数据
      const finalNoteData = {
        ...noteData,
        content: editedContent,
        folderId: folderId === 'default' ? null : folderId,
        tags,
        notes: notesTextarea.value.trim()
      };
      
      // 保存笔记
      await sendMessageToBackground('saveNote', { data: finalNoteData });
      await setLastUsedFolderId(folderId === 'default' ? 'default' : String(folderId));
      
      // 显示成功提示
      showSuccessMessage('笔记保存成功!');
      
      // 关闭对话框
      closeDialog();
      
    } catch (error) {
      console.error('保存笔记失败:', error);
      alert('保存失败: ' + error.message);
      
      // 恢复按钮状态
      saveBtn.disabled = false;
      saveBtn.textContent = '保存';
      saveBtn.style.background = '#2196f3';
    }
  });
  
  buttonContainer.appendChild(cancelBtn);
  buttonContainer.appendChild(saveBtn);
  dialog.appendChild(buttonContainer);
  
  // 添加到页面
  document.body.appendChild(dialog);
  
  // ESC键关闭
  const handleKeydown = (event) => {
    if (event.key === 'Escape') {
      closeDialog();
    }
  };
  document.addEventListener('keydown', handleKeydown);
  
  // 点击遮罩关闭
  overlay.addEventListener('click', closeDialog);
  
  // 防止对话框内点击冒泡
  dialog.addEventListener('click', (event) => {
    event.stopPropagation();
  });
  
  // 关闭对话框函数
  function closeDialog() {
    const dialog = document.getElementById('copykit-dialog');
    const overlay = document.getElementById('copykit-overlay');
    
    if (dialog) dialog.remove();
    if (overlay) overlay.remove();
    
    document.removeEventListener('keydown', handleKeydown);
  }
  
  // 聚焦到标签输入框
  setTimeout(() => {
    tagsInput.focus();
  }, 100);
}

// 显示成功消息
function showSuccessMessage(message) {
  const successDiv = document.createElement('div');
  successDiv.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #4caf50;
    color: white;
    padding: 12px 16px;
    border-radius: 6px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    z-index: 2147483648;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 14px;
    font-weight: 500;
    opacity: 0;
    transform: translateX(100%);
    transition: all 0.3s ease;
  `;
  successDiv.textContent = message;
  
  document.body.appendChild(successDiv);
  
  // 动画显示
  requestAnimationFrame(() => {
    successDiv.style.opacity = '1';
    successDiv.style.transform = 'translateX(0)';
  });
  
  // 3秒后自动移除
  setTimeout(() => {
    successDiv.style.opacity = '0';
    successDiv.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (successDiv.parentNode) {
        successDiv.remove();
      }
    }, 300);
  }, 3000);
}

function ensureCopykitInlineStyles() {
  if (document.getElementById(COPYKIT_STYLE_ID)) {
    return;
  }

  const style = document.createElement('style');
  style.id = COPYKIT_STYLE_ID;
  style.textContent = `
@keyframes copykit-spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

#${TRANSLATE_OVERLAY_ID} {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.46);
  z-index: 2147483646;
}

#${TRANSLATE_OVERLAY_ID}.copykit-translate-overlay-passive {
  background: transparent;
  pointer-events: none;
}

#${TRANSLATE_DIALOG_ID} {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2147483647;
  width: min(700px, calc(100vw - 24px));
  max-height: min(88vh, calc(100vh - 24px));
  overflow-y: auto;
  border-radius: 14px;
  border: 1px solid #e5e7eb;
  background: #fff;
  box-shadow: 0 14px 44px rgba(15, 23, 42, 0.24);
  color: #1f2937;
  padding: 18px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}

#${TRANSLATE_DIALOG_ID}.copykit-translate-minimized {
  width: min(360px, calc(100vw - 24px));
  max-height: none;
  overflow: hidden;
}

#${TRANSLATE_DIALOG_ID}.copykit-translate-minimized .copykit-translate-controls,
#${TRANSLATE_DIALOG_ID}.copykit-translate-minimized .copykit-translate-debug,
#${TRANSLATE_DIALOG_ID}.copykit-translate-minimized .copykit-translate-content,
#${TRANSLATE_DIALOG_ID}.copykit-translate-minimized .copykit-translate-footer {
  display: none;
}

#${TRANSLATE_DIALOG_ID} * {
  box-sizing: border-box;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-titlebar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
  cursor: move;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-title {
  margin: 0;
  font-size: 17px;
  font-weight: 700;
  line-height: 1.3;
  color: #111827;
  flex: 1 1 auto;
  min-width: 0;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-title-actions {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
  justify-content: flex-end;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-pin-toggle {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #4b5563;
  user-select: none;
  cursor: pointer;
  white-space: nowrap;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-pin-toggle input {
  margin: 0;
  cursor: pointer;
}

#${TRANSLATE_DIALOG_ID} input.copykit-translate-checkbox {
  appearance: auto !important;
  -webkit-appearance: checkbox !important;
  display: inline-block !important;
  width: 14px !important;
  height: 14px !important;
  min-width: 14px !important;
  min-height: 14px !important;
  margin: 0 !important;
  padding: 0 !important;
  border: initial !important;
  background: initial !important;
  position: static !important;
  opacity: 1 !important;
  visibility: visible !important;
  clip: auto !important;
  clip-path: none !important;
  transform: none !important;
  accent-color: #2563eb !important;
  flex: 0 0 auto !important;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-title-btn,
#${TRANSLATE_DIALOG_ID} .copykit-translate-close {
  border: none;
  border-radius: 8px;
  background: transparent;
  min-width: 28px;
  height: 28px;
  padding: 0 8px;
  color: #6b7280;
  cursor: pointer;
  font-size: 12px;
  line-height: 1;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-title-btn {
  font-family: inherit;
  font-weight: 600;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-close {
  width: 28px;
  padding: 0;
  font-size: 18px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-title-btn:hover,
#${TRANSLATE_DIALOG_ID} .copykit-translate-close:hover {
  background: #f3f4f6;
  color: #374151;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-controls {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 12px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-language-row {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  flex-wrap: wrap;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-field {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1 1 170px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-label {
  font-size: 12px;
  color: #6b7280;
  line-height: 1.2;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-select {
  width: 100%;
  min-width: 0;
  padding: 7px 9px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  background: #fff;
  color: #1f2937;
  font-size: 12px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-model-row {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-model-row .copykit-translate-label {
  flex: 0 0 auto;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-model-select {
  flex: 1 1 280px;
  min-width: 180px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-model-tag {
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid #e5e7eb;
  background: #f8fafc;
  color: #475569;
  font-size: 11px;
  line-height: 1.2;
  white-space: nowrap;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-mode-toggle {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  margin-left: auto;
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid #e2e8f0;
  background: #f8fafc;
  color: #334155;
  font-size: 12px;
  line-height: 1.2;
  user-select: none;
  cursor: pointer;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-mode-toggle input {
  margin: 0;
  cursor: pointer;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-content {
  margin-bottom: 14px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-textarea {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 13px;
  font-family: inherit;
  color: #111827;
  background: #fff;
  resize: vertical;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-textarea-source {
  margin-bottom: 12px;
  min-height: 110px;
  max-height: min(34vh, 260px);
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-textarea-translation {
  min-height: 160px;
  max-height: min(42vh, 320px);
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-content-label {
  margin: 0 0 6px;
  font-size: 12px;
  color: #6b7280;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-hint {
  margin-top: 8px;
  font-size: 12px;
  color: #6b7280;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-loading-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 10px 0 4px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-spinner {
  width: 18px;
  height: 18px;
  border: 2px solid #d8d8d8;
  border-top-color: #1d4ed8;
  border-radius: 50%;
  animation: copykit-spin 0.9s linear infinite;
  flex: 0 0 auto;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-loading-tip {
  font-size: 13px;
  color: #4b5563;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-preview {
  margin: 10px 0 0;
  padding: 10px 12px;
  background: #f8fafc;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  font-size: 12px;
  color: #374151;
  white-space: pre-wrap;
  max-height: 220px;
  overflow: auto;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-error {
  background: #fff3f3;
  border: 1px solid #ffd1d1;
  border-radius: 8px;
  padding: 12px;
  color: #b71c1c;
  font-size: 13px;
  white-space: pre-wrap;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug {
  margin: 0 0 12px;
  border: 1px solid #dbe3f1;
  border-radius: 10px;
  background: #f8fbff;
  overflow: hidden;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug > summary {
  list-style: none;
  cursor: pointer;
  padding: 10px 12px;
  font-size: 12px;
  font-weight: 600;
  color: #1f2937;
  user-select: none;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug > summary::-webkit-details-marker {
  display: none;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug > summary::before {
  content: '▸';
  display: inline-block;
  margin-right: 6px;
  color: #64748b;
  transition: transform 0.18s ease;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug[open] > summary::before {
  transform: rotate(90deg);
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-body {
  border-top: 1px solid #dbe3f1;
  padding: 8px 10px 10px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-meta {
  font-size: 11px;
  color: #64748b;
  margin-bottom: 8px;
  line-height: 1.4;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-table-wrap {
  overflow-x: auto;
  border: 1px solid #e6edf7;
  border-radius: 8px;
  background: #fff;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-table {
  width: 100%;
  border-collapse: collapse;
  min-width: 520px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-table th,
#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-table td {
  text-align: left;
  vertical-align: top;
  padding: 6px 8px;
  border-bottom: 1px solid #f1f5f9;
  font-size: 11px;
  line-height: 1.35;
  color: #334155;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-table th {
  position: sticky;
  top: 0;
  background: #f8fafc;
  color: #0f172a;
  font-weight: 600;
  z-index: 1;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-table tbody tr:last-child td {
  border-bottom: none;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-stage {
  white-space: nowrap;
  font-weight: 500;
  color: #0f172a;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-ms {
  white-space: nowrap;
  color: #0369a1;
  font-variant-numeric: tabular-nums;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-debug-detail {
  min-width: 180px;
  white-space: pre-wrap;
  word-break: break-word;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-footer {
  display: flex;
  justify-content: flex-end;
  flex-wrap: wrap;
  gap: 8px;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-btn {
  border-radius: 8px;
  padding: 9px 12px;
  font-size: 13px;
  line-height: 1.2;
  cursor: pointer;
  border: 1px solid #d1d5db;
  background: #fff;
  color: #374151;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-btn:hover {
  background: #f8fafc;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-btn:disabled {
  opacity: 0.55;
  cursor: not-allowed;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-btn-primary {
  border-color: #1d4ed8;
  background: #1d4ed8;
  color: #fff;
  font-weight: 600;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-btn-primary:hover {
  background: #1e40af;
}

#${TRANSLATE_DIALOG_ID} .copykit-translate-swap-btn {
  align-self: end;
  white-space: nowrap;
}

@media (max-width: 680px) {
  #${TRANSLATE_DIALOG_ID} {
    width: calc(100vw - 16px);
    max-height: calc(100vh - 16px);
    border-radius: 12px;
    padding: 14px;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-title {
    font-size: 16px;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-language-row {
    align-items: stretch;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-swap-btn {
    width: 100%;
    order: 3;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-model-row {
    align-items: stretch;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-model-select {
    min-width: 0;
    flex: 1 1 auto;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-mode-toggle {
    margin-left: 0;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-footer {
    justify-content: stretch;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-footer .copykit-translate-btn {
    width: 100%;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-debug > summary {
    padding: 9px 10px;
    font-size: 11px;
  }
}

@media (max-height: 640px) {
  #${TRANSLATE_DIALOG_ID} {
    max-height: calc(100vh - 12px);
    padding: 12px;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-textarea-source {
    min-height: 84px;
  }

  #${TRANSLATE_DIALOG_ID} .copykit-translate-textarea-translation {
    min-height: 108px;
  }
}
  `.trim();

  (document.head || document.documentElement).appendChild(style);
}

function stopTranslationDialogDragging() {
  if (!translationDialogDragSession) {
    return;
  }

  document.removeEventListener('mousemove', translationDialogDragSession.onMove, true);
  document.removeEventListener('mouseup', translationDialogDragSession.onUp, true);
  translationDialogDragSession = null;
}

function clampTranslationDialogPosition(dialog, left, top) {
  const rect = dialog.getBoundingClientRect();
  const viewportWidth = Math.max(window.innerWidth || 0, 320);
  const viewportHeight = Math.max(window.innerHeight || 0, 240);
  const margin = 8;
  const maxLeft = Math.max(margin, viewportWidth - rect.width - margin);
  const maxTop = Math.max(margin, viewportHeight - rect.height - margin);
  const clampedLeft = Math.min(Math.max(left, margin), maxLeft);
  const clampedTop = Math.min(Math.max(top, margin), maxTop);
  return { left: clampedLeft, top: clampedTop };
}

function applyTranslationDialogPlacement(dialog) {
  if (!dialog) {
    return;
  }

  const hasCustomPosition = translationDialogPosition
    && Number.isFinite(translationDialogPosition.left)
    && Number.isFinite(translationDialogPosition.top);

  if (!hasCustomPosition) {
    dialog.style.removeProperty('left');
    dialog.style.removeProperty('top');
    dialog.style.removeProperty('transform');
    return;
  }

  const nextPosition = clampTranslationDialogPosition(
    dialog,
    translationDialogPosition.left,
    translationDialogPosition.top
  );
  translationDialogPosition = nextPosition;
  dialog.style.left = `${nextPosition.left}px`;
  dialog.style.top = `${nextPosition.top}px`;
  dialog.style.transform = 'none';
}

function applyTranslationDialogPinnedState(dialog, overlay) {
  if (!dialog || !overlay) {
    return;
  }

  dialog.classList.toggle('copykit-translate-pinned', translationDialogPinned);
  overlay.classList.toggle('copykit-translate-overlay-passive', translationDialogPinned);
}

function applyTranslationDialogMinimizedState(dialog) {
  if (!dialog) {
    return;
  }

  dialog.classList.toggle('copykit-translate-minimized', translationDialogMinimized);
}

function applyTranslationDialogUiState(dialog, overlay) {
  applyTranslationDialogPlacement(dialog);
  applyTranslationDialogPinnedState(dialog, overlay);
  applyTranslationDialogMinimizedState(dialog);
}

function updateTranslationDialogMinimizeButton(buttonElement) {
  if (!buttonElement) {
    return;
  }

  buttonElement.textContent = translationDialogMinimized ? '还原' : '最小';
  buttonElement.title = translationDialogMinimized ? '还原' : '最小化';
  buttonElement.setAttribute('aria-label', translationDialogMinimized ? '还原翻译窗口' : '最小化翻译窗口');
}

function enableTranslationDialogDragging(titleBar, dialog) {
  if (!titleBar || !dialog) {
    return;
  }

  titleBar.addEventListener('mousedown', (event) => {
    if (event.button !== 0) {
      return;
    }

    const target = event.target;
    if (!(target instanceof Element)) {
      return;
    }
    if (target.closest('button, input, select, textarea, label, a, summary')) {
      return;
    }

    event.preventDefault();
    stopTranslationDialogDragging();

    const rect = dialog.getBoundingClientRect();
    translationDialogPosition = { left: rect.left, top: rect.top };
    applyTranslationDialogPlacement(dialog);

    const startX = event.clientX;
    const startY = event.clientY;
    const baseLeft = translationDialogPosition.left;
    const baseTop = translationDialogPosition.top;

    const onMove = (moveEvent) => {
      const candidateLeft = baseLeft + (moveEvent.clientX - startX);
      const candidateTop = baseTop + (moveEvent.clientY - startY);
      const nextPosition = clampTranslationDialogPosition(dialog, candidateLeft, candidateTop);
      translationDialogPosition = nextPosition;
      dialog.style.left = `${nextPosition.left}px`;
      dialog.style.top = `${nextPosition.top}px`;
      dialog.style.transform = 'none';
    };

    const onUp = () => {
      stopTranslationDialogDragging();
    };

    translationDialogDragSession = { onMove, onUp };
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('mouseup', onUp, true);
  }, true);
}

function closeTranslationDialog(options = {}) {
  const shouldCloseWindow = options.closeWindow !== false;
  const dialog = document.getElementById(TRANSLATE_DIALOG_ID);
  const overlay = document.getElementById(TRANSLATE_OVERLAY_ID);
  rememberDismissedTranslationTrace(activeTranslationTraceId);
  activeTranslationTraceId = '';
  translationDialogPinned = false;
  translationDialogMinimized = false;
  translationDialogPosition = null;
  stopTranslationDialogDragging();
  if (dialog) dialog.remove();
  if (overlay) overlay.remove();

  if (translationDialogKeydownHandler) {
    document.removeEventListener('keydown', translationDialogKeydownHandler);
    translationDialogKeydownHandler = null;
  }

  if (translationDialogResizeHandler) {
    window.removeEventListener('resize', translationDialogResizeHandler);
    translationDialogResizeHandler = null;
  }

  if (IS_TRANSLATE_WORKBENCH_PAGE && shouldCloseWindow) {
    setTimeout(() => {
      window.close();
    }, 0);
  }
}

function normalizeTranslationTraceId(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function isDismissedTranslationTrace(traceId) {
  const normalizedTraceId = normalizeTranslationTraceId(traceId);
  if (!normalizedTraceId) {
    return false;
  }

  return dismissedTranslationTraceIds.includes(normalizedTraceId);
}

function rememberDismissedTranslationTrace(traceId) {
  const normalizedTraceId = normalizeTranslationTraceId(traceId);
  if (!normalizedTraceId) {
    return;
  }

  const existingIndex = dismissedTranslationTraceIds.indexOf(normalizedTraceId);
  if (existingIndex >= 0) {
    dismissedTranslationTraceIds.splice(existingIndex, 1);
  }

  dismissedTranslationTraceIds.push(normalizedTraceId);
  if (dismissedTranslationTraceIds.length > MAX_DISMISSED_TRANSLATION_TRACE_IDS) {
    dismissedTranslationTraceIds.splice(0, dismissedTranslationTraceIds.length - MAX_DISMISSED_TRANSLATION_TRACE_IDS);
  }
}

function clearDismissedTranslationTrace(traceId) {
  const normalizedTraceId = normalizeTranslationTraceId(traceId);
  if (!normalizedTraceId) {
    return;
  }

  const existingIndex = dismissedTranslationTraceIds.indexOf(normalizedTraceId);
  if (existingIndex >= 0) {
    dismissedTranslationTraceIds.splice(existingIndex, 1);
  }
}

function normalizeLanguageCandidate(value) {
  const raw = typeof value === 'string' ? value.trim() : '';
  if (!raw) {
    return '';
  }

  const lowered = raw.toLowerCase();
  if (Object.prototype.hasOwnProperty.call(TRANSLATE_LANGUAGE_ALIASES, lowered)) {
    return TRANSLATE_LANGUAGE_ALIASES[lowered];
  }

  return TRANSLATE_LANGUAGE_VALUE_LOOKUP.get(lowered) || raw;
}

function normalizeLanguageValue(value, fallbackValue, allowAuto) {
  const fallbackCandidate = normalizeLanguageCandidate(fallbackValue);
  const fallback = TRANSLATE_LANGUAGE_VALUE_LOOKUP.get(String(fallbackCandidate || '').toLowerCase())
    || (allowAuto ? 'auto' : 'zh-CN');
  const candidate = normalizeLanguageCandidate(value);
  const normalized = TRANSLATE_LANGUAGE_VALUE_LOOKUP.get(String(candidate || '').toLowerCase()) || '';
  if (!normalized) {
    return fallback;
  }

  if (!allowAuto && normalized === 'auto') {
    return fallback;
  }

  return normalized;
}

function normalizeTranslationStyle(value, fallback = 'literal') {
  const raw = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (!raw) {
    return fallback;
  }

  if (raw === 'paraphrase' || raw === 'free' || raw === 'idiomatic' || raw === '意译') {
    return 'paraphrase';
  }

  return 'literal';
}

async function persistTranslationStylePreference(style) {
  try {
    const normalized = normalizeTranslationStyle(style, 'literal');
    await sendMessageToBackground('setTranslateStylePreference', {
      translationStyle: normalized
    });
  } catch (error) {
    console.log('保存翻译风格偏好失败:', error?.message || String(error));
  }
}

function createLanguageSelect(currentValue, includeAuto) {
  const select = document.createElement('select');
  select.className = 'copykit-translate-select';

  TRANSLATE_LANGUAGE_OPTIONS.forEach((lang) => {
    if (!includeAuto && lang.value === 'auto') {
      return;
    }
    const option = document.createElement('option');
    option.value = lang.value;
    option.textContent = lang.label;
    select.appendChild(option);
  });

  const normalizedCurrent = normalizeLanguageValue(currentValue, includeAuto ? 'auto' : 'zh-CN', includeAuto);
  const hasOption = Array.from(select.options).some((option) => option.value === normalizedCurrent);
  select.value = hasOption ? normalizedCurrent : (select.options[0]?.value || '');
  return select;
}

function formatDebugMs(value) {
  if (!Number.isFinite(value)) {
    return '-';
  }

  const normalized = Math.max(0, Math.round(value));
  return `${normalized} ms`;
}

function buildDebugDetailText(detail) {
  if (!detail || typeof detail !== 'object') {
    return '-';
  }

  const entries = Object.entries(detail)
    .filter(([, value]) => value !== undefined && value !== null && `${value}`.trim() !== '')
    .map(([key, value]) => `${key}: ${String(value)}`);

  if (entries.length === 0) {
    return '-';
  }

  return entries.join(' | ');
}

function getTranslationStageLabel(stage) {
  if (typeof stage !== 'string') {
    return '未知阶段';
  }
  return TRANSLATION_STAGE_LABELS[stage] || stage;
}

function buildTranslationDebugPanel(debugInfo, state) {
  if (!ENABLE_TRANSLATION_DEBUG) {
    return null;
  }

  const events = Array.isArray(debugInfo?.events) ? debugInfo.events : [];
  if (events.length === 0) {
    return null;
  }

  const panel = document.createElement('details');
  panel.className = 'copykit-translate-debug';

  const summary = document.createElement('summary');
  const total = formatDebugMs(debugInfo.totalMs);
  const traceId = typeof debugInfo.traceId === 'string' && debugInfo.traceId.trim()
    ? debugInfo.traceId.trim()
    : '-';
  summary.textContent = `计时：总耗时 ${total}（Trace: ${traceId}）`;
  panel.appendChild(summary);

  const body = document.createElement('div');
  body.className = 'copykit-translate-debug-body';
  panel.appendChild(body);

  const meta = document.createElement('div');
  meta.className = 'copykit-translate-debug-meta';
  const textLength = Number.isFinite(debugInfo.textLength) ? debugInfo.textLength : '-';
  const eventCount = events.length;
  meta.textContent = `状态: ${state} · 文本长度: ${textLength} · 阶段数: ${eventCount}`;
  body.appendChild(meta);

  const tableWrap = document.createElement('div');
  tableWrap.className = 'copykit-translate-debug-table-wrap';
  body.appendChild(tableWrap);

  const table = document.createElement('table');
  table.className = 'copykit-translate-debug-table';
  tableWrap.appendChild(table);

  const thead = document.createElement('thead');
  table.appendChild(thead);
  const headRow = document.createElement('tr');
  thead.appendChild(headRow);
  ['阶段', '阶段耗时', '累计耗时', '详情'].forEach((title) => {
    const th = document.createElement('th');
    th.textContent = title;
    headRow.appendChild(th);
  });

  const tbody = document.createElement('tbody');
  table.appendChild(tbody);

  events.forEach((event) => {
    const row = document.createElement('tr');

    const stageCell = document.createElement('td');
    stageCell.className = 'copykit-translate-debug-stage';
    stageCell.textContent = getTranslationStageLabel(event?.stage);
    row.appendChild(stageCell);

    const deltaCell = document.createElement('td');
    deltaCell.className = 'copykit-translate-debug-ms';
    deltaCell.textContent = formatDebugMs(event?.deltaMs);
    row.appendChild(deltaCell);

    const elapsedCell = document.createElement('td');
    elapsedCell.className = 'copykit-translate-debug-ms';
    elapsedCell.textContent = formatDebugMs(event?.sinceStartMs);
    row.appendChild(elapsedCell);

    const detailCell = document.createElement('td');
    detailCell.className = 'copykit-translate-debug-detail';
    detailCell.textContent = buildDebugDetailText(event?.detail);
    row.appendChild(detailCell);

    tbody.appendChild(row);
  });

  return panel;
}

function showTranslationDialog(payload) {
  const state = payload?.state;
  if (!state) {
    return;
  }

  if (state === 'close') {
    closeTranslationDialog();
    return;
  }

  const payloadTraceId = normalizeTranslationTraceId(payload?.debugInfo?.traceId);
  if (payloadTraceId && isDismissedTranslationTrace(payloadTraceId)) {
    return;
  }
  if (payloadTraceId) {
    activeTranslationTraceId = payloadTraceId;
    clearDismissedTranslationTrace(payloadTraceId);
  } else if (state === 'loading') {
    activeTranslationTraceId = '';
  }

  ensureCopykitInlineStyles();

  // Reuse the same dialog node to keep one-instance behavior.
  let overlay = document.getElementById(TRANSLATE_OVERLAY_ID);
  let dialog = document.getElementById(TRANSLATE_DIALOG_ID);
  const isNewDialog = !dialog;

  if (isNewDialog) {
    translationDialogPinned = false;
    translationDialogMinimized = false;
    translationDialogPosition = null;
  }

  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = TRANSLATE_OVERLAY_ID;
    overlay.addEventListener('click', () => {
      if (translationDialogPinned) {
        return;
      }
      closeTranslationDialog();
    });
    document.body.appendChild(overlay);
  }

  if (!dialog) {
    dialog = document.createElement('div');
    dialog.id = TRANSLATE_DIALOG_ID;
    dialog.addEventListener('click', (event) => event.stopPropagation());
    document.body.appendChild(dialog);
  }

  if (!translationDialogResizeHandler) {
    translationDialogResizeHandler = () => {
      const activeDialog = document.getElementById(TRANSLATE_DIALOG_ID);
      if (!activeDialog) {
        return;
      }
      applyTranslationDialogPlacement(activeDialog);
    };
    window.addEventListener('resize', translationDialogResizeHandler);
  }

  while (dialog.firstChild) {
    dialog.removeChild(dialog.firstChild);
  }
  dialog.scrollTop = 0;

  const titleBar = document.createElement('div');
  titleBar.className = 'copykit-translate-titlebar';

  const title = document.createElement('h3');
  title.className = 'copykit-translate-title';
  title.textContent = state === 'loading'
    ? '正在翻译…'
    : (state === 'error' ? '翻译失败' : (state === 'editor' ? '翻译工具' : '翻译结果'));

  const titleActions = document.createElement('div');
  titleActions.className = 'copykit-translate-title-actions';

  const keepOpenLabel = document.createElement('label');
  keepOpenLabel.className = 'copykit-translate-pin-toggle';

  const keepOpenCheckbox = document.createElement('input');
  keepOpenCheckbox.type = 'checkbox';
  keepOpenCheckbox.className = 'copykit-translate-checkbox';
  keepOpenCheckbox.checked = translationDialogPinned;
  keepOpenLabel.appendChild(keepOpenCheckbox);

  const keepOpenText = document.createElement('span');
  keepOpenText.textContent = '保持打开';
  keepOpenLabel.appendChild(keepOpenText);

  const minimizeBtn = document.createElement('button');
  minimizeBtn.type = 'button';
  minimizeBtn.className = 'copykit-translate-title-btn';
  updateTranslationDialogMinimizeButton(minimizeBtn);

  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = 'copykit-translate-close';
  closeBtn.textContent = '✕';
  closeBtn.setAttribute('aria-label', '关闭翻译窗口');
  closeBtn.addEventListener('click', closeTranslationDialog);

  keepOpenCheckbox.addEventListener('change', () => {
    translationDialogPinned = keepOpenCheckbox.checked;
    applyTranslationDialogPinnedState(dialog, overlay);
  });

  minimizeBtn.addEventListener('click', () => {
    translationDialogMinimized = !translationDialogMinimized;
    applyTranslationDialogMinimizedState(dialog);
    applyTranslationDialogPlacement(dialog);
    updateTranslationDialogMinimizeButton(minimizeBtn);
  });

  titleBar.appendChild(title);
  titleActions.appendChild(keepOpenLabel);
  titleActions.appendChild(minimizeBtn);
  titleActions.appendChild(closeBtn);
  titleBar.appendChild(titleActions);
  dialog.appendChild(titleBar);
  enableTranslationDialogDragging(titleBar, dialog);
  applyTranslationDialogUiState(dialog, overlay);

  const originalText = (payload?.originalText || '').toString();
  const sourceLang = normalizeLanguageValue(payload?.sourceLang, 'auto', true);
  const targetLang = normalizeLanguageValue(payload?.targetLang, 'zh-CN', false);
  const translationStyle = normalizeTranslationStyle(payload?.translationStyle, 'literal');
  const modelName = typeof payload?.model === 'string' ? payload.model.trim() : '';
  const modelOptionsRaw = Array.isArray(payload?.modelOptions) ? payload.modelOptions : [];
  const modelOptions = Array.from(new Set(
    modelOptionsRaw
      .map((item) => (typeof item === 'string' ? item.trim() : ''))
      .filter((item) => item)
  ));
  if (modelName && !modelOptions.includes(modelName)) {
    modelOptions.unshift(modelName);
  }

  const languageControls = document.createElement('div');
  languageControls.className = 'copykit-translate-controls';
  dialog.appendChild(languageControls);

  const sourceSelect = createLanguageSelect(sourceLang, true);
  const targetSelect = createLanguageSelect(targetLang, false);
  const createField = (labelText, controlElement) => {
    const field = document.createElement('label');
    field.className = 'copykit-translate-field';
    const text = document.createElement('span');
    text.className = 'copykit-translate-label';
    text.textContent = labelText;
    field.appendChild(text);
    field.appendChild(controlElement);
    return field;
  };

  const languageRow = document.createElement('div');
  languageRow.className = 'copykit-translate-language-row';
  languageControls.appendChild(languageRow);

  languageRow.appendChild(createField('源语言', sourceSelect));

  const swapButton = document.createElement('button');
  swapButton.type = 'button';
  swapButton.textContent = '↔ 互换';
  swapButton.className = 'copykit-translate-btn copykit-translate-swap-btn';
  languageRow.appendChild(swapButton);

  languageRow.appendChild(createField('目标语言', targetSelect));

  let modelSelect = null;
  let paraphraseCheckbox = null;
  const createTranslationStyleToggle = () => {
    const toggleLabel = document.createElement('label');
    toggleLabel.className = 'copykit-translate-mode-toggle';

    paraphraseCheckbox = document.createElement('input');
    paraphraseCheckbox.type = 'checkbox';
    paraphraseCheckbox.className = 'copykit-translate-checkbox';
    paraphraseCheckbox.checked = translationStyle === 'paraphrase';
    paraphraseCheckbox.addEventListener('change', () => {
      const nextStyle = paraphraseCheckbox.checked ? 'paraphrase' : 'literal';
      persistTranslationStylePreference(nextStyle);
    });
    toggleLabel.appendChild(paraphraseCheckbox);

    const text = document.createElement('span');
    text.textContent = '意译';
    toggleLabel.appendChild(text);
    return toggleLabel;
  };
  if (modelOptions.length > 1) {
    const modelRow = document.createElement('div');
    modelRow.className = 'copykit-translate-model-row';
    languageControls.appendChild(modelRow);

    const modelLabel = document.createElement('span');
    modelLabel.className = 'copykit-translate-label';
    modelLabel.textContent = '模型';
    modelRow.appendChild(modelLabel);

    modelSelect = document.createElement('select');
    modelSelect.className = 'copykit-translate-select copykit-translate-model-select';
    modelOptions.forEach((model) => {
      const option = document.createElement('option');
      option.value = model;
      option.textContent = model;
      modelSelect.appendChild(option);
    });
    modelSelect.value = modelName && modelOptions.includes(modelName) ? modelName : modelOptions[0];
    modelRow.appendChild(modelSelect);
    modelRow.appendChild(createTranslationStyleToggle());

  } else if (modelName) {
    const modelRow = document.createElement('div');
    modelRow.className = 'copykit-translate-model-row';
    languageControls.appendChild(modelRow);

    const modelLabel = document.createElement('span');
    modelLabel.className = 'copykit-translate-label';
    modelLabel.textContent = '模型';
    modelRow.appendChild(modelLabel);

    const modelTag = document.createElement('span');
    modelTag.className = 'copykit-translate-model-tag';
    modelTag.textContent = `模型: ${modelName}`;
    modelRow.appendChild(modelTag);
    modelRow.appendChild(createTranslationStyleToggle());
  } else {
    const styleRow = document.createElement('div');
    styleRow.className = 'copykit-translate-model-row';
    languageControls.appendChild(styleRow);

    const styleLabel = document.createElement('span');
    styleLabel.className = 'copykit-translate-label';
    styleLabel.textContent = '风格';
    styleRow.appendChild(styleLabel);
    styleRow.appendChild(createTranslationStyleToggle());
  }

  swapButton.addEventListener('click', () => {
    if (sourceSelect.value === 'auto') {
      const nextSource = targetSelect.value;
      const fallbackTarget = nextSource === 'zh-CN' ? 'en' : 'zh-CN';
      sourceSelect.value = nextSource;
      if (Array.from(targetSelect.options).some((option) => option.value === fallbackTarget)) {
        targetSelect.value = fallbackTarget;
      }
      showSuccessMessage('已切换翻译方向，请点击“重新翻译”生效');
      return;
    }

    const currentSource = sourceSelect.value;
    sourceSelect.value = targetSelect.value;
    if (Array.from(targetSelect.options).some((option) => option.value === currentSource)) {
      targetSelect.value = currentSource;
    }
  });

  if (state === 'loading') {
    sourceSelect.disabled = true;
    targetSelect.disabled = true;
    if (modelSelect) {
      modelSelect.disabled = true;
    }
    if (paraphraseCheckbox) {
      paraphraseCheckbox.disabled = true;
    }
    swapButton.disabled = true;
  }

  const debugPanel = buildTranslationDebugPanel(payload?.debugInfo, state);
  if (debugPanel) {
    dialog.appendChild(debugPanel);
  }

  const contentContainer = document.createElement('div');
  contentContainer.className = 'copykit-translate-content';
  dialog.appendChild(contentContainer);

  const footer = document.createElement('div');
  footer.className = 'copykit-translate-footer';
  dialog.appendChild(footer);

  const getCurrentSourceText = () => {
    const sourceEditor = dialog.querySelector('[data-role="source-editor"]');
    if (sourceEditor instanceof HTMLTextAreaElement) {
      return sourceEditor.value.trim();
    }
    return originalText.trim();
  };
  const getCurrentTranslationStyle = () => (
    paraphraseCheckbox && paraphraseCheckbox.checked ? 'paraphrase' : 'literal'
  );

  const triggerRetranslate = async () => {
    const selectedText = getCurrentSourceText();
    if (!selectedText) {
      alert('原文为空，无法重新翻译');
      return;
    }

    if (!targetSelect.value) {
      alert('请选择目标语言');
      return;
    }

    try {
      const nextModel = modelSelect ? modelSelect.value.trim() : modelName;
      const requestPayload = {
        text: selectedText,
        sourceLang: sourceSelect.value,
        targetLang: targetSelect.value,
        translationStyle: getCurrentTranslationStyle()
      };

      if (nextModel) {
        requestPayload.model = nextModel;
      }

      const runDirectTranslateFallback = async () => {
        const pendingPayload = {
          state: 'loading',
          originalText: selectedText,
          sourceLang: requestPayload.sourceLang,
          targetLang: requestPayload.targetLang,
          translationStyle: requestPayload.translationStyle,
          model: requestPayload.model || nextModel || modelName,
          modelOptions: modelOptions.length > 0 ? modelOptions : [requestPayload.model || nextModel || modelName].filter(Boolean),
          sourceUrl: payload?.sourceUrl,
          sourceTitle: payload?.sourceTitle
        };
        showTranslationDialog(pendingPayload);

        const directResult = await sendMessageToBackground('translateTextDirect', requestPayload);
        const resolvedPayload = {
          originalText: selectedText,
          sourceLang: directResult?.sourceLang || requestPayload.sourceLang,
          targetLang: directResult?.targetLang || requestPayload.targetLang,
          translationStyle: normalizeTranslationStyle(
            directResult?.translationStyle,
            requestPayload.translationStyle
          ),
          model: directResult?.model || requestPayload.model || nextModel || modelName,
          modelOptions: Array.isArray(directResult?.modelOptions) && directResult.modelOptions.length > 0
            ? directResult.modelOptions
            : pendingPayload.modelOptions,
          sourceUrl: payload?.sourceUrl,
          sourceTitle: payload?.sourceTitle,
          debugInfo: directResult?.debugInfo || null
        };

        if (directResult?.ok) {
          showTranslationDialog({
            ...resolvedPayload,
            state: 'done',
            translation: directResult.translation || ''
          });
          return;
        }

        const message = typeof directResult?.error === 'string' && directResult.error.trim()
          ? directResult.error.trim()
          : '翻译失败';
        showTranslationDialog({
          ...resolvedPayload,
          state: 'error',
          error: message,
          canOpenOptions: /API_KEY|BASE_URL|MODEL|鉴权|网关|令牌|token/i.test(message) || /401|403/.test(message)
        });
      };

      if (IS_TRANSLATE_WORKBENCH_PAGE) {
        await runDirectTranslateFallback();
        return;
      }

      try {
        await sendMessageToBackground('translateSelectedText', requestPayload);
      } catch (error) {
        const message = typeof error?.message === 'string' ? error.message : String(error || '');
        if (/当前标签页不可用|无法翻译/i.test(message)) {
          await runDirectTranslateFallback();
          return;
        }
        throw error;
      }
    } catch (error) {
      console.error('重新翻译失败:', error);
      alert(`重新翻译失败: ${error.message}`);
    }
  };

  const addSecondaryButton = (label, onClick) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'copykit-translate-btn';
    btn.textContent = label;
    btn.addEventListener('click', onClick);
    footer.appendChild(btn);
    return btn;
  };

  const addPrimaryButton = (label, onClick) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'copykit-translate-btn copykit-translate-btn-primary';
    btn.textContent = label;
    btn.addEventListener('click', onClick);
    footer.appendChild(btn);
    return btn;
  };

  if (state === 'loading') {
    const loadingRow = document.createElement('div');
    loadingRow.className = 'copykit-translate-loading-row';

    const spinner = document.createElement('div');
    spinner.className = 'copykit-translate-spinner';
    loadingRow.appendChild(spinner);

    const tip = document.createElement('div');
    tip.className = 'copykit-translate-loading-tip';
    tip.textContent = '正在调用模型翻译，完成后会自动展示结果。';
    loadingRow.appendChild(tip);

    contentContainer.appendChild(loadingRow);

    const snippet = originalText.trim();
    if (snippet) {
      const preview = document.createElement('pre');
      preview.textContent = snippet.length > 800 ? `${snippet.slice(0, 800)}…` : snippet;
      preview.className = 'copykit-translate-preview';
      contentContainer.appendChild(preview);
    }

    addSecondaryButton('关闭', closeTranslationDialog);

  } else if (state === 'error') {
    const errorBox = document.createElement('div');
    errorBox.className = 'copykit-translate-error';
    const msg = (payload?.error || '未知错误').toString();
    errorBox.textContent = msg;
    contentContainer.appendChild(errorBox);

    if (originalText.trim()) {
      addPrimaryButton('重新翻译', triggerRetranslate);
    }

    if (payload?.canOpenOptions) {
      addSecondaryButton('打开设置', () => {
        const sent = safeRuntimeSendMessage({ action: 'openOptionsPage' }, () => {
          if (chrome.runtime.lastError) {
            const message = chrome.runtime.lastError.message || '';
            if (/Extension context invalidated/i.test(message)) {
              extensionContextInvalidated = true;
              return;
            }
            console.log('打开设置页失败:', message);
          }
        });
        if (!sent) {
          console.log('打开设置页失败:', EXTENSION_CONTEXT_INVALIDATED_HINT);
        }
      });
    }

    addSecondaryButton('关闭', closeTranslationDialog);

  } else if (state === 'done' || state === 'editor') {
    const isEditorMode = state === 'editor';

    const originalLabel = document.createElement('div');
    originalLabel.textContent = '原文（可编辑）';
    originalLabel.className = 'copykit-translate-content-label';
    contentContainer.appendChild(originalLabel);

    const originalEditor = document.createElement('textarea');
    originalEditor.className = 'copykit-translate-textarea copykit-translate-textarea-source';
    originalEditor.setAttribute('data-role', 'source-editor');
    originalEditor.value = originalText;
    contentContainer.appendChild(originalEditor);

    const transLabel = document.createElement('div');
    transLabel.textContent = '译文（可编辑）';
    transLabel.className = 'copykit-translate-content-label';
    contentContainer.appendChild(transLabel);

    const translationArea = document.createElement('textarea');
    translationArea.className = 'copykit-translate-textarea copykit-translate-textarea-translation';
    translationArea.setAttribute('data-role', 'translation-editor');
    translationArea.value = isEditorMode ? '' : (payload?.translation || '').toString();
    contentContainer.appendChild(translationArea);

    const editableHint = document.createElement('div');
    editableHint.textContent = isEditorMode
      ? '可直接粘贴或修改原文，设置语言后点击“开始翻译”。勾选“意译”可生成更自然表达。'
      : '可直接修改原文/译文，然后点“重新翻译”继续迭代；勾选“意译”可减少生硬直译。';
    editableHint.className = 'copykit-translate-hint';
    contentContainer.appendChild(editableHint);

    if (!isEditorMode) {
      addSecondaryButton('保存译文', async () => {
        const translationText = translationArea.value.trim();
        if (!translationText) {
          alert('译文为空，无法保存');
          return;
        }

        const tags = ['翻译'];
        const from = sourceSelect.value.trim();
        const to = targetSelect.value.trim();
        if (from && from !== 'auto') tags.push(`from:${from}`);
        if (to) tags.push(`to:${to}`);

        closeTranslationDialog({ closeWindow: false });
        await showSaveDialog({
          type: 'text',
          content: translationText,
          sourceUrl: (payload?.sourceUrl || window.location.href).toString(),
          sourceTitle: (payload?.sourceTitle || document.title).toString(),
          timestamp: Date.now(),
          tags,
          folderId: null
        }, '保存译文');
      });

      addPrimaryButton('复制译文', async () => {
        const translationText = translationArea.value.trim();
        if (!translationText) {
          alert('译文为空，无法复制');
          return;
        }

        try {
          await navigator.clipboard.writeText(translationText);
          showSuccessMessage('译文已复制到剪贴板');
        } catch (error) {
          console.error('复制失败:', error);
          alert('复制失败：请检查剪贴板权限或使用手动复制');
        }
      });
    }

    addSecondaryButton('译文转原文', () => {
      originalEditor.value = translationArea.value;
      showSuccessMessage('已用译文覆盖原文，可点击“重新翻译”');
      originalEditor.focus();
    });

    if (isEditorMode) {
      originalEditor.focus();
      addPrimaryButton('开始翻译', triggerRetranslate);
    } else {
      addSecondaryButton('重新翻译', triggerRetranslate);
    }

    addSecondaryButton('关闭', closeTranslationDialog);
  }

  applyTranslationDialogUiState(dialog, overlay);

  // ESC to close
  if (!translationDialogKeydownHandler) {
    translationDialogKeydownHandler = (event) => {
      if (event.key === 'Escape') {
        closeTranslationDialog();
      }
    };
    document.addEventListener('keydown', translationDialogKeydownHandler);
  }
}
