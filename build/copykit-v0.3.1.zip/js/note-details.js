// 笔记详情页面的JavaScript逻辑

// 获取URL中的笔记ID
const urlParams = new URLSearchParams(window.location.search);
const noteId = urlParams.get('id');

// 当前笔记对象
let currentNote = null;
const LAST_USED_FOLDER_KEY = 'lastUsedFolderId';

function getNoteDisplayTitle(note) {
  const customTitle = typeof note?.customTitle === 'string' ? note.customTitle.trim() : '';
  if (customTitle) {
    return customTitle;
  }

  const sourceTitle = typeof note?.sourceTitle === 'string' ? note.sourceTitle.trim() : '';
  if (sourceTitle) {
    return sourceTitle;
  }

  return '未命名笔记';
}

document.addEventListener('DOMContentLoaded', async () => {
  if (!noteId) {
    showError('未指定笔记ID');
    return;
  }
  
  try {
    // 加载笔记
    await loadNote();
    
    // 设置事件监听器
    document.getElementById('save-btn').addEventListener('click', saveChanges);
    document.getElementById('export-btn').addEventListener('click', exportNote);
    document.getElementById('delete-btn').addEventListener('click', deleteNote);
    document.getElementById('add-tag-btn').addEventListener('click', addTag);
    document.getElementById('new-tag-input').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        addTag();
      }
    });
    
  } catch (error) {
    console.error('页面初始化失败:', error);
    showError('页面加载失败: ' + error.message);
  }
});

// 发送消息到背景脚本
async function sendMessageToBackground(action, data = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action, ...data }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (response && response.success) {
        if (Object.prototype.hasOwnProperty.call(response, 'data')) {
          resolve(response.data);
        } else if (Object.prototype.hasOwnProperty.call(response, 'result')) {
          resolve(response.result);
        } else if (Object.prototype.hasOwnProperty.call(response, 'folderId')) {
          resolve(response.folderId);
        } else if (Object.prototype.hasOwnProperty.call(response, 'noteId')) {
          resolve(response.noteId);
        } else if (Object.prototype.hasOwnProperty.call(response, 'message')) {
          resolve(response.message);
        } else {
          resolve(null);
        }
      } else {
        reject(new Error(response?.error || '操作失败'));
      }
    });
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text == null ? '' : String(text);
  return div.innerHTML;
}

function sanitizeUrl(url) {
  if (!url) return '#';
  try {
    const parsed = new URL(url);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.href;
    }
    return '#';
  } catch (error) {
    return '#';
  }
}

function renderTextWithLinks(container, rawText) {
  const text = rawText == null ? '' : String(rawText);
  const urlRegex = /https?:\/\/[^\s]+/g;
  let lastIndex = 0;
  let match = null;

  while ((match = urlRegex.exec(text)) !== null) {
    const [matchedUrl] = match;
    if (match.index > lastIndex) {
      container.appendChild(document.createTextNode(text.slice(lastIndex, match.index)));
    }

    const anchor = document.createElement('a');
    anchor.href = sanitizeUrl(matchedUrl);
    anchor.target = '_blank';
    anchor.rel = 'noopener noreferrer';
    anchor.textContent = matchedUrl;
    anchor.style.cssText = 'color: #2196f3; text-decoration: none;';
    container.appendChild(anchor);
    lastIndex = match.index + matchedUrl.length;
  }

  if (lastIndex < text.length) {
    container.appendChild(document.createTextNode(text.slice(lastIndex)));
  }
}

async function setLastUsedFolderId(folderId) {
  return new Promise((resolve) => {
    const normalizedFolderId = folderId == null || folderId === '' ? 'default' : String(folderId);
    chrome.storage.local.set({ [LAST_USED_FOLDER_KEY]: normalizedFolderId }, resolve);
  });
}

// 加载笔记
async function loadNote() {
  try {
    showLoading('正在加载笔记...');
    
    // 从背景脚本获取笔记数据
    const notes = await sendMessageToBackground('getNotes');
    const folders = await sendMessageToBackground('getFolders');
    
    // 查找当前笔记
    currentNote = notes.find(note => note.id === noteId);
    
    if (!currentNote) {
      hideLoading();
      showError('找不到指定的笔记');
      return;
    }
    
    hideLoading();
    
    // 显示笔记内容
    document.getElementById('loading-message').style.display = 'none';
    document.getElementById('note-container').style.display = 'block';
    
    // 更新标题
    const title = getNoteDisplayTitle(currentNote);
    document.getElementById('note-title').textContent = title;
    document.title = `${title} - 摘抄猫`;
    
    // 更新元数据
    const date = new Date(currentNote.timestamp);
    const dateOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric', 
      hour: '2-digit', 
      minute: '2-digit' 
    };
    const noteDateElement = document.getElementById('note-date');
    if (noteDateElement) {
      noteDateElement.textContent = date.toLocaleString('zh-CN', dateOptions);
    }
    
    const sourceLinkElement = document.getElementById('source-link');
    if (sourceLinkElement) {
      sourceLinkElement.textContent = currentNote.sourceTitle || '未知来源';
      sourceLinkElement.href = sanitizeUrl(currentNote.sourceUrl);
    }
    
    // 更新文件夹信息
    const folderNameElement = document.getElementById('folder-name');
    if (folderNameElement) {
      if (currentNote.folderId) {
        const folder = folders.find(f => f.id === currentNote.folderId);
        folderNameElement.textContent = folder ? folder.name : '默认文件夹';
      } else {
        folderNameElement.textContent = '默认文件夹';
      }
    }
    
    // 显示内容
    displayNoteContent();
    
    // 显示标签
    displayTags();
    initializeFolderSelector(folders);
    
    // 设置笔记备注
    const notesTextarea = document.getElementById('notes-textarea');
    if (notesTextarea) {
      notesTextarea.value = currentNote.notes || '';
      
      // 监听变化
      notesTextarea.addEventListener('input', () => {
        currentNote.notes = notesTextarea.value;
        markAsModified();
      });
    }
    
  } catch (error) {
    hideLoading();
    console.error('加载笔记失败:', error);
    showError('加载笔记失败: ' + error.message);
  }
}

// 显示笔记内容
function displayNoteContent() {
  const contentContainer = document.getElementById('content-container');
  
  if (!contentContainer) {
    console.error('找不到内容容器元素');
    return;
  }
  
  if (!currentNote) {
    contentContainer.innerHTML = '<p>笔记数据不可用</p>';
    return;
  }

  contentContainer.innerHTML = '';
  
  if (currentNote.type === 'image') {
    // 显示图片
    const img = document.createElement('img');
    img.src = currentNote.content;
    img.style.cssText = `
      max-width: 100%;
      height: auto;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      margin-bottom: 16px;
    `;
    img.onerror = () => {
      contentContainer.innerHTML = '';
      const errorWrap = document.createElement('div');
      errorWrap.style.cssText = `
        text-align: center;
        padding: 40px;
        color: #999;
        background: #f5f5f5;
        border-radius: 8px;
      `;

      const icon = document.createElement('div');
      icon.textContent = '🖼️';
      icon.style.cssText = 'font-size: 48px; margin-bottom: 16px;';

      const title = document.createElement('p');
      title.textContent = '图片加载失败';

      const link = document.createElement('p');
      link.style.cssText = 'font-size: 12px; margin-top: 8px;';
      link.textContent = `原始链接: ${currentNote.content || '未知'}`;

      errorWrap.appendChild(icon);
      errorWrap.appendChild(title);
      errorWrap.appendChild(link);
      contentContainer.appendChild(errorWrap);
    };
    contentContainer.appendChild(img);
    
  } else {
    // 显示文本内容
    const contentDiv = document.createElement('div');
    contentDiv.style.cssText = `
      line-height: 1.6;
      font-size: 16px;
      color: #333;
      white-space: pre-wrap;
      word-wrap: break-word;
    `;

    renderTextWithLinks(contentDiv, currentNote.content);
    contentContainer.appendChild(contentDiv);
  }
  
  // 如果有备注，显示备注
  if (currentNote.notes && currentNote.notes.trim()) {
    const notesDiv = document.createElement('div');
    notesDiv.style.cssText = `
      margin-top: 20px;
      padding: 16px;
      background: #f8f9fa;
      border-radius: 8px;
      border-left: 4px solid #2196f3;
    `;
    
    const notesLabel = document.createElement('div');
    notesLabel.textContent = '备注:';
    notesLabel.style.cssText = 'font-weight: 600; color: #555; margin-bottom: 8px; font-size: 14px;';
    
    const notesContent = document.createElement('div');
    notesContent.textContent = currentNote.notes;
    notesContent.style.cssText = 'color: #666; line-height: 1.5;';
    
    notesDiv.appendChild(notesLabel);
    notesDiv.appendChild(notesContent);
    contentContainer.appendChild(notesDiv);
  }
}

// 显示标签
function displayTags() {
  const tagsContainer = document.getElementById('tags-container');
  
  if (!tagsContainer) {
    console.error('找不到标签容器元素');
    return;
  }
  
  tagsContainer.innerHTML = '';
  
  if (!currentNote || !currentNote.tags || currentNote.tags.length === 0) {
    const emptyText = document.createElement('span');
    emptyText.style.color = '#999';
    emptyText.textContent = '暂无标签';
    tagsContainer.appendChild(emptyText);
    return;
  }
  
  if (currentNote.tags && currentNote.tags.length > 0) {
    currentNote.tags.forEach((tag, index) => {
      const tagElement = document.createElement('span');
      tagElement.className = 'tag';
      tagElement.style.cssText = `
        display: inline-block;
        background: #e3f2fd;
        color: #1976d2;
        padding: 4px 12px;
        border-radius: 16px;
        margin-right: 8px;
        margin-bottom: 8px;
        font-size: 12px;
        font-weight: 500;
        position: relative;
        cursor: pointer;
      `;

      const tagText = document.createElement('span');
      tagText.textContent = tag;

      const removeButton = document.createElement('span');
      removeButton.className = 'tag-remove';
      removeButton.style.cssText = `
        margin-left: 8px;
        color: #1976d2;
        font-weight: bold;
        opacity: 0.7;
      `;
      removeButton.textContent = '×';
      
      // 删除标签事件
      removeButton.addEventListener('click', (e) => {
        e.stopPropagation();
        removeTag(index);
      });

      tagElement.appendChild(tagText);
      tagElement.appendChild(removeButton);
      tagsContainer.appendChild(tagElement);
    });
  }
}

function initializeFolderSelector(folders) {
  const folderSelect = document.getElementById('folder-select');
  const folderNameElement = document.getElementById('folder-name');
  if (!folderSelect) {
    return;
  }

  folderSelect.innerHTML = '';

  const defaultOption = document.createElement('option');
  defaultOption.value = '';
  defaultOption.textContent = '默认文件夹';
  folderSelect.appendChild(defaultOption);

  folders.forEach((folder) => {
    const option = document.createElement('option');
    option.value = folder.id;
    option.textContent = folder.name;
    folderSelect.appendChild(option);
  });

  folderSelect.value = currentNote.folderId || '';
  folderSelect.addEventListener('change', (event) => {
    currentNote.folderId = event.target.value || null;
    setLastUsedFolderId(currentNote.folderId).catch((error) => {
      console.log('记录最近文件夹失败:', error.message);
    });
    if (folderNameElement) {
      if (!currentNote.folderId) {
        folderNameElement.textContent = '默认文件夹';
      } else {
        const matched = folders.find((folder) => folder.id === currentNote.folderId);
        folderNameElement.textContent = matched ? matched.name : '默认文件夹';
      }
    }
    markAsModified();
  });
}

// 添加标签
function addTag() {
  const tagInput = document.getElementById('new-tag-input');
  const typedTag = tagInput ? tagInput.value.trim() : '';
  const fallbackTag = typedTag ? typedTag : prompt('请输入标签名称:');
  if (!fallbackTag || !fallbackTag.trim()) return;
  
  const trimmedTag = fallbackTag.trim();
  
  // 检查标签是否已存在
  if (currentNote.tags && currentNote.tags.includes(trimmedTag)) {
    alert('标签已存在');
    return;
  }
  
  // 添加标签
  if (!currentNote.tags) {
    currentNote.tags = [];
  }
  currentNote.tags.push(trimmedTag);
  
  // 重新显示标签
  displayTags();
  
  // 标记为已修改
  markAsModified();

  if (tagInput) {
    tagInput.value = '';
  }
}

// 移除标签
function removeTag(index) {
  if (confirm('确定要删除这个标签吗？')) {
    currentNote.tags.splice(index, 1);
    displayTags();
    markAsModified();
  }
}

// 标记为已修改
function markAsModified() {
  const saveBtn = document.getElementById('save-btn');
  if (saveBtn) {
    saveBtn.textContent = '保存更改';
    saveBtn.style.background = '#ff9800';
    saveBtn.disabled = false;
  }
}

// 保存更改
async function saveChanges() {
  try {
    showLoading('正在保存...');
    
    // 更新笔记
    await sendMessageToBackground('updateNote', { id: currentNote.id, data: currentNote });
    await setLastUsedFolderId(currentNote.folderId);
    
    hideLoading();
    
    // 更新按钮状态
    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
      saveBtn.textContent = '已保存';
      saveBtn.style.background = '#4caf50';
      saveBtn.disabled = true;
      
      setTimeout(() => {
        saveBtn.textContent = '保存更改';
        saveBtn.style.background = '#2196f3';
      }, 2000);
    }
    
    // 显示成功提示
    showSuccessMessage('更改已保存');
    
  } catch (error) {
    hideLoading();
    console.error('保存失败:', error);
    showError('保存失败: ' + error.message);
  }
}

// 导出笔记
function exportNote() {
  const formats = [
    { id: 'markdown', name: 'Markdown (.md)' },
    { id: 'text', name: 'Plain Text (.txt)' },
    { id: 'html', name: 'HTML (.html)' }
  ];
  
  const formatChoice = prompt(
    '选择导出格式:\n' + 
    formats.map((f, i) => `${i + 1}. ${f.name}`).join('\n') +
    '\n\n请输入数字 (1-3):'
  );
  
  const formatIndex = parseInt(formatChoice) - 1;
  if (formatIndex < 0 || formatIndex >= formats.length) {
    return;
  }
  
  const format = formats[formatIndex];
  let content = '';
  let filename = '';
  
  const title = getNoteDisplayTitle(currentNote);
  const date = new Date(currentNote.timestamp).toLocaleDateString('zh-CN');
  
  switch (format.id) {
    case 'markdown':
      filename = `${title}.md`;
      content = `# ${title}\n\n`;
      content += `**创建时间:** ${date}\n`;
      content += `**来源:** ${currentNote.sourceUrl || '未知'}\n`;
      if (currentNote.tags && currentNote.tags.length > 0) {
        content += `**标签:** ${currentNote.tags.join(', ')}\n`;
      }
      content += `\n---\n\n`;
      content += currentNote.content;
      if (currentNote.notes) {
        content += `\n\n**备注:**\n${currentNote.notes}`;
      }
      break;
      
    case 'text':
      filename = `${title}.txt`;
      content = `${title}\n${'='.repeat(title.length)}\n\n`;
      content += `创建时间: ${date}\n`;
      content += `来源: ${currentNote.sourceUrl || '未知'}\n`;
      if (currentNote.tags && currentNote.tags.length > 0) {
        content += `标签: ${currentNote.tags.join(', ')}\n`;
      }
      content += `\n${'-'.repeat(40)}\n\n`;
      content += currentNote.content;
      if (currentNote.notes) {
        content += `\n\n备注:\n${currentNote.notes}`;
      }
      break;
      
    case 'html':
      {
        const safeTitle = escapeHtml(title);
        const safeDate = escapeHtml(date);
        const safeSourceUrl = sanitizeUrl(currentNote.sourceUrl);
        const safeSourceText = escapeHtml(currentNote.sourceUrl || '未知');
        const safeTags = (currentNote.tags || []).map((tag) => `<span class="tag">${escapeHtml(tag)}</span>`).join('');
        const safeNotes = currentNote.notes ? escapeHtml(currentNote.notes).replace(/\n/g, '<br>') : '';
        const safeContent = escapeHtml(currentNote.content || '');

      filename = `${title}.html`;
      content = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; line-height: 1.6; }
        h1 { color: #333; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .meta { background: #f5f5f5; padding: 15px; border-radius: 8px; margin: 20px 0; }
        .content { background: white; padding: 20px; border: 1px solid #eee; border-radius: 8px; }
        .tag { background: #e3f2fd; color: #1976d2; padding: 4px 8px; border-radius: 12px; font-size: 12px; margin-right: 8px; }
        .notes { background: #f8f9fa; padding: 15px; border-radius: 8px; border-left: 4px solid #2196f3; margin-top: 20px; }
    </style>
</head>
<body>
    <h1>${safeTitle}</h1>
    <div class="meta">
        <p><strong>创建时间:</strong> ${safeDate}</p>
        <p><strong>来源:</strong> <a href="${safeSourceUrl}">${safeSourceText}</a></p>
        ${currentNote.tags && currentNote.tags.length > 0 ? 
          `<p><strong>标签:</strong> ${safeTags}</p>` : ''}
    </div>
    <div class="content">
        ${currentNote.type === 'image' ? 
          `<img src="${sanitizeUrl(currentNote.content)}" alt="${safeTitle}" style="max-width: 100%; height: auto;">` :
          `<pre style="white-space: pre-wrap; word-wrap: break-word;">${safeContent}</pre>`
        }
    </div>
    ${currentNote.notes ? `<div class="notes"><strong>备注:</strong><br>${safeNotes}</div>` : ''}
</body>
</html>`;
      break;
      }
  }
  
  // 下载文件
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  showSuccessMessage(`笔记已导出为 ${format.name}`);
}

// 删除笔记
async function deleteNote() {
  if (!confirm('确定要删除这条笔记吗？删除后无法恢复。')) {
    return;
  }
  
  try {
    showLoading('正在删除...');
    
    await sendMessageToBackground('deleteNote', { id: currentNote.id });
    
    hideLoading();
    showSuccessMessage('笔记已删除');
    
    // 2秒后关闭页面
    setTimeout(() => {
      window.close();
    }, 2000);
    
  } catch (error) {
    hideLoading();
    console.error('删除失败:', error);
    showError('删除失败: ' + error.message);
  }
}

// 显示错误信息
function showError(message) {
  const loadingMessage = document.getElementById('loading-message');
  const noteContainer = document.getElementById('note-container');
  
  if (loadingMessage) {
    loadingMessage.style.display = 'none';
  }
  if (noteContainer) {
    noteContainer.style.display = 'none';
  }
  
  const errorContainer = document.createElement('div');
  errorContainer.style.cssText = `
    text-align: center;
    padding: 60px 20px;
    color: #666;
  `;

  const icon = document.createElement('div');
  icon.textContent = '😕';
  icon.style.cssText = 'font-size: 64px; margin-bottom: 20px; opacity: 0.5;';

  const title = document.createElement('h2');
  title.style.cssText = 'color: #333; margin-bottom: 10px;';
  title.textContent = '出错了';

  const msg = document.createElement('p');
  msg.textContent = message;

  const closeButton = document.createElement('button');
  closeButton.textContent = '关闭页面';
  closeButton.style.cssText = `
    margin-top: 20px;
    padding: 10px 20px;
    background: #2196f3;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
  `;
  closeButton.addEventListener('click', () => window.close());

  errorContainer.appendChild(icon);
  errorContainer.appendChild(title);
  errorContainer.appendChild(msg);
  errorContainer.appendChild(closeButton);
  
  document.body.appendChild(errorContainer);
}

// 显示加载状态
function showLoading(message = '加载中...') {
  let loadingDiv = document.getElementById('loading-overlay');
  
  if (!loadingDiv) {
    loadingDiv = document.createElement('div');
    loadingDiv.id = 'loading-overlay';
    loadingDiv.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, 0.9);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      font-size: 16px;
      color: #666;
    `;
    document.body.appendChild(loadingDiv);
  }
  
  loadingDiv.textContent = message;
  loadingDiv.style.display = 'flex';
}

// 隐藏加载状态
function hideLoading() {
  const loadingDiv = document.getElementById('loading-overlay');
  if (loadingDiv) {
    loadingDiv.style.display = 'none';
  }
}

// 显示成功消息
function showSuccessMessage(message) {
  const successDiv = document.createElement('div');
  successDiv.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #4caf50;
    color: white;
    padding: 12px 16px;
    border-radius: 6px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    z-index: 10000;
    font-size: 14px;
    font-weight: 500;
    opacity: 0;
    transform: translateX(100%);
    transition: all 0.3s ease;
  `;
  successDiv.textContent = message;
  
  document.body.appendChild(successDiv);
  
  // 动画显示
  requestAnimationFrame(() => {
    successDiv.style.opacity = '1';
    successDiv.style.transform = 'translateX(0)';
  });
  
  // 3秒后自动移除
  setTimeout(() => {
    successDiv.style.opacity = '0';
    successDiv.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (successDiv.parentNode) {
        successDiv.remove();
      }
    }, 300);
  }, 3000);
}
